/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Employee {
  id: string;
  name: string;
  email: string;
  role: string;
  department: string;
  avatar?: string;
}

export interface AttendanceRecord {
  id: string;
  date: string; // YYYY-MM-DD
  shift: string;
  clockIn?: string; // HH:MM
  clockOut?: string; // HH:MM
  totalHours?: number;
  status: 'Present' | 'Late' | 'WFH' | 'Half Day' | 'Absent' | 'On Leave';
  regularizationStatus?: 'None' | 'Pending' | 'Approved' | 'Rejected';
}

export interface ShiftType {
  name: string; // General Shift, Morning Shift, etc.
  timing: string; // e.g. 09:00 AM - 06:00 PM
  weeklyOff: string; // e.g. Sunday
  alternateSaturday: string; // e.g. 2nd & 4th Off
}

export interface EmployeeShift {
  employeeId: string;
  employeeName: string;
  department: string;
  shiftName: string;
  timing: string;
  weeklyOff: string;
  alternateSaturdayStatus: string;
}

export interface SaturdayConfig {
  firstThirdWorking: boolean;
  secondFourthOff: boolean;
  teamSchedules: {
    teamName: string;
    description: string;
    supportSaturdays: string; // "1st & 3rd" or "2nd & 4th" or "None"
  }[];
}

export interface LeaveBalance {
  casualLeave: number;
  sickLeave: number;
  privilegeLeave: number;
  lossOfPay: number;
}

export interface LeaveRequest {
  id: string;
  appliedDate: string; // YYYY-MM-DD
  leaveType: 'Casual Leave' | 'Sick Leave' | 'Privilege Leave' | 'Loss of Pay';
  fromDate: string;
  toDate: string;
  days: number;
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  approver: string;
  attachmentName?: string;
}

export interface RegularizationRequest {
  id: string;
  date: string;
  missingInTime: string; // HH:MM
  missingOutTime: string; // HH:MM
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  approverComments?: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  unread: boolean;
  type: 'info' | 'success' | 'warning';
}

export interface CompanyHoliday {
  id: string;
  name: string;
  date: string; // YYYY-MM-DD
  type: 'Public' | 'National' | 'Company' | 'Restricted';
  dayOfWeek: string;
  description?: string;
  policy?: string;
}
