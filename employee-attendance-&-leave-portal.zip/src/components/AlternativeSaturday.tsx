/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CalendarRange, Info, ToggleLeft, ToggleRight, CheckSquare, Square, ShieldCheck, Users } from 'lucide-react';
import { INITIAL_SATURDAY_CONFIG } from '../data';

interface AlternativeSaturdayProps {
  isDark: boolean;
}

export default function AlternativeSaturday({ isDark }: AlternativeSaturdayProps) {
  const [config, setConfig] = useState(INITIAL_SATURDAY_CONFIG);
  const [activeTab, setActiveTab] = useState<'visualizer' | 'configs'>('visualizer');

  // Interactive configurations update simulation
  const handleToggleFirstThird = () => {
    setConfig(prev => ({ ...prev, firstThirdWorking: !prev.firstThirdWorking }));
  };

  const handleToggleSecondFourth = () => {
    setConfig(prev => ({ ...prev, secondFourthsOff: !prev.secondFourthOff, secondFourthOff: !prev.secondFourthOff }));
  };

  const handleSupportAssignmentChange = (teamIndex: number, supportType: string) => {
    const updatedSchedules = [...config.teamSchedules];
    updatedSchedules[teamIndex].supportSaturdays = supportType;
    setConfig(prev => ({ ...prev, teamSchedules: updatedSchedules }));
  };

  // Static list of May 2026 Saturdays for visual rendering
  const saturdaysOfMay = [
    { num: 1, date: '2026-05-02', desc: '1st Saturday of Month', defaultType: '1st & 3rd Support team on duty', highlightColor: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/25 border-emerald-150', team: 'Core Engineering / Cloud & System' },
    { num: 2, date: '2026-05-09', desc: '2nd Saturday of Month', defaultType: '2nd & 4th Support team on duty', highlightColor: 'text-violet-500 bg-violet-50 dark:bg-violet-950/25 border-violet-150', team: 'Support & Escalation' },
    { num: 3, date: '2026-05-16', desc: '3rd Saturday of Month', defaultType: '1st & 3rd Support team on duty', highlightColor: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/25 border-emerald-150', team: 'Core Engineering / Cloud & System' },
    { num: 4, date: '2026-05-23', desc: '4th Saturday of Month', defaultType: '2nd & 4th Support team on duty', highlightColor: 'text-violet-500 bg-violet-50 dark:bg-violet-950/25 border-violet-150', team: 'Support & Escalation' },
    { num: 5, date: '2026-05-30', desc: '5th Saturday (Ad-hoc Off)', defaultType: 'Universal Corporate Off', highlightColor: 'text-slate-400 bg-slate-50 dark:bg-slate-900 border-slate-150', team: 'None (Company-wide Holiday)' }
  ];

  return (
    <div className="space-y-6" id="alternate-saturday-tab">
      
      {/* Title */}
      <div>
        <h2 className="text-xl md:text-2xl font-bold tracking-tight">Alternative Saturday & Roster Rules</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Define corporate alternate Saturday working regimes and assign team schedules dynamically.</p>
      </div>

      {/* Main interactive cards split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left Side: Rule Settings Configurator */}
        <div className={`lg:col-span-1 p-6 rounded-xl border flex flex-col justify-between shadow-md ${
          isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'
        }`}>
          
          <div className="space-y-6">
            <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider flex items-center gap-2">
              <CalendarRange className="text-blue-500" size={16} /> Saturday Rule Configs
            </h3>

            {/* Config Toggles */}
            <div className="space-y-4">
              
              <div className="flex items-center justify-between p-3.5 rounded-xl border border-dashed dark:border-slate-700">
                <div className="space-y-0.5 max-w-[75%]">
                  <span className="text-xs font-bold block text-slate-700 dark:text-slate-300">1st & 3rd Saturday Working</span>
                  <p className="text-[10px] text-slate-400 leading-normal">Mandate 1st and 3rd Saturdays of the month as support duty hours (except holidays).</p>
                </div>
                <button onClick={handleToggleFirstThird} className="cursor-pointer">
                  {config.firstThirdWorking ? (
                    <span className="text-emerald-500 hover:opacity-85"><ToggleRight size={38} /></span>
                  ) : (
                    <span className="text-slate-400 hover:opacity-85"><ToggleLeft size={38} /></span>
                  )}
                </button>
              </div>

              <div className="flex items-center justify-between p-3.5 rounded-xl border border-dashed dark:border-slate-700">
                <div className="space-y-0.5 max-w-[75%]">
                  <span className="text-xs font-bold block text-slate-700 dark:text-slate-300">2nd & 4th Saturday Off Policy</span>
                  <p className="text-[10px] text-slate-400 leading-normal">System-enforced biometric blockade and off-office days for general employees.</p>
                </div>
                <button onClick={handleToggleSecondFourth} className="cursor-pointer">
                  {config.secondFourthOff ? (
                    <span className="text-emerald-500 hover:opacity-85"><ToggleRight size={38} /></span>
                  ) : (
                    <span className="text-slate-400 hover:opacity-85"><ToggleLeft size={38} /></span>
                  )}
                </button>
              </div>

            </div>

            <div className="p-4 rounded-xl bg-blue-50/40 dark:bg-blue-950/20 border border-blue-100/50 flex gap-3">
              <Info className="text-blue-600 flex-shrink-0 mt-0.5" size={16} />
              <div className="text-[10px] text-slate-500 dark:text-slate-400 leading-relaxed">
                <span className="font-bold text-blue-800 dark:text-blue-400 block mb-0.5">HR policy details</span>
                Employees belonging to Teams assigned to support schedules on alternate Saturdays are eligible for compensatory off (comp-off) claims.
              </div>
            </div>

          </div>

          <div className="pt-6 border-t dark:border-slate-700 mt-6 md:mt-2 text-[10px] text-slate-400 flex items-center gap-1.5 font-medium">
            <ShieldCheck className="text-emerald-500" size={14} /> Policies validated by Compliance HR Team
          </div>

        </div>

        {/* Right Side: Visualizers (Schedules list & calendar style schedule visualizer) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Visual Saturday Calendar breakdown */}
          <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
            <div className="flex items-center justify-between mb-4 border-b pb-3 dark:border-slate-700">
              <div>
                <h3 className="font-bold text-sm">Visual Duty Calendar — May 2026 Saturdays</h3>
                <p className="text-[10px] text-slate-400 mt-0.5">Chronological layout of upcoming Saturdays and active deployment coverages.</p>
              </div>
              <span className="text-[10px] font-bold text-blue-600 dark:text-blue-400 uppercase">Interactive simulation</span>
            </div>

            {/* List of Saturdays */}
            <div className="space-y-3.5">
              {saturdaysOfMay.map((sat) => {
                // Determine actual config checks
                let isActive = false;
                if (sat.num === 1 || sat.num === 3) {
                  isActive = config.firstThirdWorking;
                } else if (sat.num === 2 || sat.num === 4) {
                  isActive = !config.secondFourthOff; // Since second/fourth are typically off
                }

                // Check active rosters
                const finalLabel = isActive ? sat.defaultType : 'Excused Off (No Coverage)';
                const finalTeamGroup = isActive ? sat.team : 'All Departments (Universal Off)';

                const finalHighlight = isActive ? sat.highlightColor : 'bg-slate-50 dark:bg-slate-900 border-slate-150 text-slate-400';

                return (
                  <div key={sat.date} className={`p-4 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-4 transition-colors ${finalHighlight}`}>
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs font-mono">{new Date(sat.date).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
                        <span className="px-1.5 py-0.5 rounded bg-white/50 dark:bg-slate-800 text-[9px] font-bold uppercase tracking-wider">{sat.desc}</span>
                      </div>
                      <p className="text-[10px] font-medium text-slate-600 dark:text-slate-400 mt-1">{finalLabel}</p>
                    </div>

                    <div className="flex items-center gap-2 mt-2 md:mt-0 bg-white/30 dark:bg-slate-800/20 px-3 py-1.5 rounded-lg border border-inherit">
                      <Users size={12} className="text-slate-400" />
                      <div className="text-xs text-left">
                        <span className="text-[9px] font-mono text-slate-400 block uppercase font-bold">Duty Group</span>
                        <span className="font-bold tracking-tight text-slate-700 dark:text-slate-300 text-[10px] truncate block max-w-44">{finalTeamGroup}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Team Wise Assignments Setup Card list */}
          <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
            <h3 className="font-bold text-sm mb-3">Team Support Assignment Control</h3>
            <p className="text-[10px] text-slate-400 mb-4 pb-2 border-b dark:border-slate-700">Change which alternate Saturday cycle specific teams support during crisis or deployments.</p>

            <div className="space-y-3.5">
              {config.teamSchedules.map((schedule, idx) => (
                <div key={schedule.teamName} className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 bg-slate-50/50 dark:bg-slate-900/40 rounded-xl border border-dashed border-slate-150 dark:border-slate-850">
                  <div className="text-xs">
                    <span className="font-bold text-slate-800 dark:text-slate-200">{schedule.teamName}</span>
                    <p className="text-[10px] text-slate-500">{schedule.description}</p>
                  </div>

                  {/* Options select */}
                  <div className="flex items-center gap-1">
                    {['1st & 3rd', '2nd & 4th', 'None'].map((type) => {
                      const isActive = schedule.supportSaturdays === type;
                      return (
                        <button
                          key={type}
                          onClick={() => handleSupportAssignmentChange(idx, type)}
                          className={`px-2.5 py-1 rounded text-[10px] font-bold transition-all border cursor-pointer ${
                            isActive
                              ? 'bg-blue-600 border-blue-600 text-white shadow-sm'
                              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-750 text-slate-550 hover:bg-slate-55'
                          }`}
                        >
                          {type}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
