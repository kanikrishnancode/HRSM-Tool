/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Lock, Mail, ShieldAlert, KeyRound, Building, UserCheck, User, Briefcase, PlusCircle, CheckCircle } from 'lucide-react';
import { Employee } from '../types';

interface LoginProps {
  onLoginSuccess: (user: Employee) => void;
}

const LOCAL_USERS_KEY = 'hero_enterprise_users';

const getRegisteredUsers = (): (Employee & { password?: string })[] => {
  try {
    const stored = localStorage.getItem(LOCAL_USERS_KEY);
    if (stored) {
      return JSON.parse(stored);
    }
  } catch (e) {
    console.error("Failed to parse stored users", e);
  }
  // Default Seed
  return [
    {
      id: 'EMP-2026-1045',
      name: 'Kavitha Mohan',
      email: 'kavithamohanofficial@gmail.com',
      role: 'Tech Lead - Core Engineering',
      department: 'Software Engineering',
      avatar: 'KM',
      password: 'admin123'
    }
  ];
};

export default function Login({ onLoginSuccess }: LoginProps) {
  const [activeTab, setActiveTab] = useState<'signin' | 'signup'>('signin');
  
  // Sign In States
  const [email, setEmail] = useState('kavithamohanofficial@gmail.com');
  const [password, setPassword] = useState('admin123');
  
  // Sign Up States
  const [signupName, setSignupName] = useState('');
  const [signupEmail, setSignupEmail] = useState('');
  const [signupRole, setSignupRole] = useState('');
  const [signupDepartment, setSignupDepartment] = useState('Software Engineering');
  const [signupPassword, setSignupPassword] = useState('');
  const [signupConfirmPassword, setSignupConfirmPassword] = useState('');

  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const [forgotPasswordActive, setForgotPasswordActive] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSuccess, setForgotSuccess] = useState(false);

  // Local users state
  const [registeredUsers, setRegisteredUsers] = useState<(Employee & { password?: string })[]>(() => getRegisteredUsers());

  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!email.trim() || !password.trim()) {
      setErrorMsg("Please enter both email and password.");
      return;
    }

    // Lookup user in state
    const matchedUser = registeredUsers.find(
      u => u.email.toLowerCase() === email.trim().toLowerCase() && u.password === password
    );

    if (matchedUser) {
      const employeeProfile: Employee = {
        id: matchedUser.id,
        name: matchedUser.name,
        email: matchedUser.email,
        role: matchedUser.role,
        department: matchedUser.department,
        avatar: matchedUser.avatar
      };
      onLoginSuccess(employeeProfile);
    } else {
      setErrorMsg("Invalid email or password. Hint: Use 'kavithamohanofficial@gmail.com' to login or register an account.");
    }
  };

  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    // Form validations
    if (!signupName.trim() || !signupEmail.trim() || !signupRole.trim() || !signupPassword.trim()) {
      setErrorMsg("Please fill in all the registration fields.");
      return;
    }

    if (signupPassword !== signupConfirmPassword) {
      setErrorMsg("Passwords do not match. Please verify.");
      return;
    }

    if (signupPassword.length < 5) {
      setErrorMsg("Password should be at least 5 characters long for security.");
      return;
    }

    const emailLower = signupEmail.trim().toLowerCase();
    const isEmailTaken = registeredUsers.some(u => u.email.toLowerCase() === emailLower);

    if (isEmailTaken) {
      setErrorMsg("This corporate email is already registered.");
      return;
    }

    // Generate unique corporate metadata
    const randomIdSuffix = Math.floor(Math.random() * 9000) + 1000;
    const generatedEmployeeId = `EMP-2026-${randomIdSuffix}`;
    const initials = signupName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase();

    const newUser: Employee & { password?: string } = {
      id: generatedEmployeeId,
      name: signupName.trim(),
      email: emailLower,
      role: signupRole.trim(),
      department: signupDepartment,
      avatar: initials || 'EE',
      password: signupPassword
    };

    const updatedList = [...registeredUsers, newUser];
    setRegisteredUsers(updatedList);
    
    try {
      localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(updatedList));
    } catch (err) {
      console.error("Local storage sync error", err);
    }

    // Set interactive success feedback and switch to sign in view with preset
    setSuccessMsg(`Welcome, ${newUser.name}! ID generated: ${generatedEmployeeId}. Please sign in to authenticate.`);
    
    // Auto populate credential fields
    setEmail(newUser.email);
    setPassword(signupPassword);
    
    // Clear inputs
    setSignupName('');
    setSignupEmail('');
    setSignupRole('');
    setSignupPassword('');
    setSignupConfirmPassword('');
    
    // Swap back to login tab
    setActiveTab('signin');
  };

  const handleForgotSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!forgotEmail) return;
    setForgotSuccess(true);
    setTimeout(() => {
      setForgotSuccess(false);
      setForgotPasswordActive(false);
      setForgotEmail('');
    }, 4000);
  };

  return (
    <div className="min-h-screen bg-slate-50 flex items-center justify-center p-4 relative overflow-hidden font-sans" id="login-screen">
      {/* Decorative corporate ambient background circles */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-blue-400/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-slate-100 p-8 z-10 space-y-6 relative">
        
        {/* Company Branding Logo */}
        <div className="text-center space-y-2">
          <div className="h-12 w-12 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-2xl mx-auto shadow-md">
            H
          </div>
          <div>
            <h1 className="text-xl font-extrabold tracking-tight text-slate-850">HERO Enterprise</h1>
            <p className="text-xs text-slate-400">Employee Attendance & Leave Management Portal</p>
          </div>
        </div>

        {/* Tab Selection (Sign In and Sign Up) if not in Forgot Password view */}
        {!forgotPasswordActive && (
          <div className="flex bg-slate-100/80 p-1 rounded-xl" id="auth-tabs">
            <button
              onClick={() => {
                setActiveTab('signin');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === 'signin' 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700 hover:bg-white/30'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => {
                setActiveTab('signup');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`flex-1 py-2 text-xs font-bold rounded-lg transition-all cursor-pointer ${
                activeTab === 'signup' 
                  ? 'bg-white text-blue-600 shadow-sm' 
                  : 'text-slate-500 hover:text-slate-700 hover:bg-white/30'
              }`}
            >
              Create Account (Sign Up)
            </button>
          </div>
        )}

        {errorMsg && (
          <div className="p-3 bg-rose-50 border border-rose-100 rounded-lg text-rose-600 text-[11px] font-medium flex gap-2">
            <ShieldAlert size={16} className="flex-shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {successMsg && (
          <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-600 text-[11px] font-medium flex gap-2">
            <CheckCircle size={16} className="text-emerald-500 flex-shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Auth view switcher */}
        {forgotPasswordActive ? (
          <form onSubmit={handleForgotSubmit} className="space-y-4">
            <div className="space-y-2 text-center pb-2">
              <h2 className="text-sm font-bold text-slate-750">Reset your HRMS password</h2>
              <p className="text-[10px] text-slate-400">Enter your corporate email address below and we will send you restruction tokens.</p>
            </div>

            {forgotSuccess && (
              <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-600 text-[10px] font-semibold">
                Reset code has been sent to your email. Redirecting...
              </div>
            )}

            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-400 uppercase">Corporate Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="email"
                  required
                  placeholder="username@company.com"
                  value={forgotEmail}
                  onChange={(e) => setForgotEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>
            </div>

            <div className="flex gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setForgotPasswordActive(false)}
                className="w-1/2 bg-slate-100 hover:bg-slate-205 text-slate-600 font-bold py-2 rounded-lg text-xs transition-colors cursor-pointer"
              >
                Back To Login
              </button>
              <button
                type="submit"
                className="w-1/2 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 rounded-lg text-xs shadow transition-colors cursor-pointer"
              >
                Send Code
              </button>
            </div>
          </form>
        ) : activeTab === 'signin' ? (
          <form onSubmit={handleSignInSubmit} className="space-y-4">
            
            {/* Employee Email field */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Employee Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  id="login-email-input"
                />
              </div>
            </div>

            {/* Password field */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Secure Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  id="login-password-input"
                />
              </div>
            </div>

            {/* Quick action triggers */}
            <div className="flex items-center justify-between text-[11px]">
              <div className="flex items-center gap-1.5 text-slate-400 font-medium">
                <input type="checkbox" id="remember-me" defaultChecked className="rounded border-slate-350 cursor-pointer" />
                <label htmlFor="remember-me" className="cursor-pointer">Keep me logged in</label>
              </div>
              <button
                type="button"
                onClick={() => setForgotPasswordActive(true)}
                className="text-blue-600 hover:underline font-bold bg-transparent border-0 cursor-pointer text-xs"
              >
                Forgot Password?
              </button>
            </div>

            {/* Submit button */}
            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 rounded-lg text-xs shadow-md hover:shadow-lg transition-all cursor-pointer"
              id="btn-login-submit"
            >
              Sign In to HRMS
            </button>

            {/* Corporate credentials tip box */}
            <div className="p-3 bg-blue-50/60 border border-blue-100 rounded-lg space-y-1">
              <p className="text-[10px] font-bold text-blue-800 flex items-center gap-1">
                <UserCheck size={12} /> Live Demo Login Access
              </p>
              <p className="text-[9px] text-slate-500 leading-normal">
                Credentials have been pre-filled for Kavitha Mohan (<code className="font-semibold text-blue-750 font-mono">kavithamohanofficial@gmail.com</code>). Select the Sign Up tab to register a new account!
              </p>
            </div>

          </form>
        ) : (
          <form onSubmit={handleSignUpSubmit} className="space-y-4">
            
            {/* Full Name field */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="text"
                  required
                  value={signupName}
                  onChange={(e) => setSignupName(e.target.value)}
                  placeholder="e.g. Kavitha Mohan"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  id="signup-name-input"
                />
              </div>
            </div>

            {/* Corporate Email field */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Corporate Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="email"
                  required
                  value={signupEmail}
                  onChange={(e) => setSignupEmail(e.target.value)}
                  placeholder="name@company.com"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  id="signup-email-input"
                />
              </div>
            </div>

            {/* Department field */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Department</label>
              <div className="relative">
                <Building className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <select
                  value={signupDepartment}
                  onChange={(e) => setSignupDepartment(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  id="signup-dept-select"
                >
                  <option value="Software Engineering">Software Engineering</option>
                  <option value="Design & Product">Design & Product</option>
                  <option value="Quality Assurance">Quality Assurance</option>
                  <option value="Cloud Operations">Cloud Operations</option>
                  <option value="Human Resources">Human Resources</option>
                  <option value="Administration">Administration</option>
                </select>
              </div>
            </div>

            {/* Role Title field */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Role / Job Title</label>
              <div className="relative">
                <Briefcase className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="text"
                  required
                  value={signupRole}
                  onChange={(e) => setSignupRole(e.target.value)}
                  placeholder="e.g. Senior Frontend Dev"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  id="signup-role-input"
                />
              </div>
            </div>

            {/* Password field */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Enter Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="password"
                  required
                  value={signupPassword}
                  onChange={(e) => setSignupPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  id="signup-password-input"
                />
              </div>
            </div>

            {/* Confirm Password field */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Confirm Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
                <input
                  type="password"
                  required
                  value={signupConfirmPassword}
                  onChange={(e) => setSignupConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                  id="signup-confirm-password-input"
                />
              </div>
            </div>

            {/* Submit sign up button */}
            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 rounded-lg text-xs shadow-md hover:shadow-lg transition-all cursor-pointer flex items-center justify-center gap-1.5"
              id="btn-signup-submit"
            >
              <PlusCircle size={15} /> Save & Register Account
            </button>

          </form>
        )}

      </div>
    </div>
  );
}
