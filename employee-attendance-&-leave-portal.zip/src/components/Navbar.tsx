/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { Bell, Sun, Moon, Search, User, ChevronDown, Check, Trash2, Menu } from 'lucide-react';
import { Employee, Notification } from '../types';

interface NavbarProps {
  user: Employee;
  notifications: Notification[];
  onMarkNotificationRead: (id: string) => void;
  onClearNotifications: () => void;
  isDark: boolean;
  setIsDark: (dark: boolean) => void;
  onLogout: () => void;
  currentTime: Date;
  onToggleMobileSidebar: () => void;
}

export default function Navbar({
  user,
  notifications,
  onMarkNotificationRead,
  onClearNotifications,
  isDark,
  setIsDark,
  onLogout,
  currentTime,
  onToggleMobileSidebar
}: NavbarProps) {
  const [showNotificationMenu, setShowNotificationMenu] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter(n => n.unread).length;

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotificationMenu(false);
      }
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setShowProfileMenu(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Format date elegantly e.g. "Saturday, May 30, 2026"
  const formattedDate = currentTime.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });

  const formattedTime = currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: true
  });

  return (
    <header className={`h-16 px-6 border-b flex items-center justify-between sticky top-0 z-40 transition-colors backdrop-blur-md ${
      isDark ? 'bg-slate-900/95 border-slate-800 text-slate-100' : 'bg-white/95 border-slate-200 text-slate-800'
    }`} id="app-navbar">
      
      {/* Current live time & date visualization for site relevance */}
      <div className="flex items-center gap-4">
        <button
          onClick={onToggleMobileSidebar}
          className="md:hidden p-2 -ml-2 rounded-lg text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-slate-100 transition-colors cursor-pointer"
          title="Open Side Menu"
          id="btn-mobile-menu-toggle"
        >
          <Menu size={20} />
        </button>

        <div className="hidden md:flex flex-col">
          <span className="text-xs font-medium text-slate-400 dark:text-slate-500 uppercase tracking-wider">{formattedDate}</span>
          <span className="text-sm font-bold text-slate-700 dark:text-slate-300 font-mono tracking-tight">{formattedTime}</span>
        </div>
      </div>

      {/* Global search and action buttons */}
      <div className="flex items-center gap-4">
        
        {/* Toggle dark / light mode */}
        <button
          onClick={() => setIsDark(!isDark)}
          className={`p-2 rounded-lg transition-colors ${
            isDark ? 'bg-slate-800 text-amber-400 hover:bg-slate-700' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
          }`}
          title={isDark ? "Switch to Light Mode" : "Switch to Dark Mode"}
          id="btn-theme-toggle"
        >
          {isDark ? <Sun size={18} /> : <Moon size={18} />}
        </button>

        {/* Notification Bell Panel */}
        <div className="relative" ref={notificationRef}>
          <button
            onClick={() => setShowNotificationMenu(!showNotificationMenu)}
            className={`p-2 rounded-lg transition-colors relative ${
              isDark ? 'bg-slate-800 hover:bg-slate-700' : 'bg-slate-100 hover:bg-slate-200'
            }`}
            id="btn-notifications"
          >
            <Bell size={18} className={unreadCount > 0 ? "animate-pulse" : ""} />
            {unreadCount > 0 && (
              <span className="absolute top-1.5 right-1.5 h-2.5 w-2.5 rounded-full bg-rose-500 border-2 dark:border-slate-800 border-white" />
            )}
          </button>

          {showNotificationMenu && (
            <div className={`absolute right-0 mt-2 w-80 rounded-xl shadow-xl border overflow-hidden transition-all text-xs z-50 ${
              isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
            }`}>
              <div className="p-3 border-b border-inherit flex items-center justify-between font-semibold">
                <span>Notifications ({unreadCount} new)</span>
                {notifications.length > 0 && (
                  <button
                    onClick={onClearNotifications}
                    className="text-rose-500 hover:text-rose-600 flex items-center gap-1 font-normal cursor-pointer"
                  >
                    <Trash2 size={12} /> Clear all
                  </button>
                )}
              </div>
              <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700">
                {notifications.length === 0 ? (
                  <div className="p-4 text-center text-slate-400">
                    No notifications
                  </div>
                ) : (
                  notifications.map((n) => (
                    <div
                      key={n.id}
                      onClick={() => onMarkNotificationRead(n.id)}
                      className={`p-3 transition-colors cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-750 flex items-start gap-2.5 ${
                        n.unread ? 'bg-blue-50/40 dark:bg-blue-950/20 font-medium' : ''
                      }`}
                    >
                      <span className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${
                        n.type === 'success' ? 'bg-emerald-500' : n.type === 'warning' ? 'bg-amber-500' : 'bg-blue-500'
                      }`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-slate-700 dark:text-slate-300 line-clamp-2">{n.message}</p>
                        <span className="text-[10px] text-slate-400 dark:text-slate-500 block mt-1">{n.time}</span>
                      </div>
                      {n.unread && (
                        <span className="text-[10px] text-blue-500 hover:underline flex-shrink-0">
                          Mark read
                        </span>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* User profile dropdown selection */}
        <div className="relative" ref={profileRef}>
          <button
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center gap-2 p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors text-left"
            id="btn-profile-dropdown"
          >
            <div className="h-8 w-8 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-xs shadow-md">
              {user.avatar || 'U'}
            </div>
            <div className="hidden sm:flex flex-col">
              <span className="text-xs font-semibold leading-3">{user.name}</span>
              <span className="text-[10px] text-slate-400 leading-2 mt-0.5">{user.role}</span>
            </div>
            <ChevronDown size={14} className="text-slate-400" />
          </button>

          {showProfileMenu && (
            <div className={`absolute right-0 mt-2 w-48 rounded-xl shadow-xl border overflow-hidden z-50 text-xs ${
              isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
            }`}>
              <div className="p-3 border-b border-inherit bg-slate-50/50 dark:bg-slate-900/40">
                <p className="font-semibold text-slate-800 dark:text-slate-200">{user.name}</p>
                <p className="text-[10px] text-slate-400 truncate mt-0.5">{user.email}</p>
              </div>
              <div className="p-1">
                <button
                  onClick={() => setShowProfileMenu(false)}
                  className="w-full text-left px-3 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700/60 transition-colors"
                >
                  My Profile
                </button>
                <button
                  onClick={onLogout}
                  className="w-full text-left px-3 py-2 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/25 transition-colors font-medium mt-0.5"
                >
                  Logout
                </button>
              </div>
            </div>
          )}
        </div>

      </div>

    </header>
  );
}
