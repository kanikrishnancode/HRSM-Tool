/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from 'recharts';
import { Calendar, Sliders, BarChart3, TrendingUp, Users, Laptop, Clock } from 'lucide-react';
import {
  ATTENDANCE_MOCK_STATS,
  MONTHLY_TREND_DATA,
  LEAVE_UTILIZATION_DATA,
  WFH_TREND_DATA,
  LATE_TREND_DATA,
  TEAM_MEMBERS
} from '../data';

interface ReportsProps {
  isDark: boolean;
}

export default function Reports({ isDark }: ReportsProps) {
  // Filters State
  const [selectedMonth, setSelectedMonth] = useState('May');
  const [selectedDepartment, setSelectedDepartment] = useState('All');
  const [selectedEmployee, setSelectedEmployee] = useState('All');

  const departments = ['All', 'Software Engineering', 'Design & Product', 'Quality Assurance', 'Cloud Operations'];

  // Color Palettes for Charts
  const COLORS = ['#2563eb', '#8b5cf6', '#f59e0b', '#f97316', '#ef4444'];
  const PIE_COLORS = ['#10b981', '#ef4444', '#f59e0b'];

  const simplePresentAbsentData = [
    { name: 'Present', value: 94.6 },
    { name: 'Absent / Unpaid', value: 2.1 },
    { name: 'Paid Leaves', value: 3.3 }
  ];

  // Dynamic mapped datasets based on selectedDepartment
  const departmentKPIStats: Record<string, {
    attendancePercentage: number;
    wfhSessions: number;
    lateArrivals: number;
    lopDays: number;
  }> = {
    All: {
      attendancePercentage: 94.6,
      wfhSessions: 12,
      lateArrivals: 2,
      lopDays: 0
    },
    'Software Engineering': {
      attendancePercentage: 95.8,
      wfhSessions: 7,
      lateArrivals: 1,
      lopDays: 0
    },
    'Design & Product': {
      attendancePercentage: 96.2,
      wfhSessions: 3,
      lateArrivals: 0,
      lopDays: 0
    },
    'Quality Assurance': {
      attendancePercentage: 91.5,
      wfhSessions: 1,
      lateArrivals: 1,
      lopDays: 0
    },
    'Cloud Operations': {
      attendancePercentage: 98.0,
      wfhSessions: 1,
      lateArrivals: 0,
      lopDays: 0
    }
  };

  const trendMap: Record<string, typeof MONTHLY_TREND_DATA> = {
    All: MONTHLY_TREND_DATA,
    'Software Engineering': [
      { month: 'Jan', percentage: 96.2 },
      { month: 'Feb', percentage: 93.5 },
      { month: 'Mar', percentage: 97.1 },
      { month: 'Apr', percentage: 94.0 },
      { month: 'May', percentage: 95.8 }
    ],
    'Design & Product': [
      { month: 'Jan', percentage: 94.0 },
      { month: 'Feb', percentage: 95.1 },
      { month: 'Mar', percentage: 96.5 },
      { month: 'Apr', percentage: 95.8 },
      { month: 'May', percentage: 96.2 }
    ],
    'Quality Assurance': [
      { month: 'Jan', percentage: 91.0 },
      { month: 'Feb', percentage: 89.5 },
      { month: 'Mar', percentage: 92.4 },
      { month: 'Apr', percentage: 90.1 },
      { month: 'May', percentage: 91.5 }
    ],
    'Cloud Operations': [
      { month: 'Jan', percentage: 97.5 },
      { month: 'Feb', percentage: 96.0 },
      { month: 'Mar', percentage: 98.2 },
      { month: 'Apr', percentage: 97.7 },
      { month: 'May', percentage: 98.0 }
    ]
  };

  const leaveMap: Record<string, typeof LEAVE_UTILIZATION_DATA> = {
    All: LEAVE_UTILIZATION_DATA,
    'Software Engineering': [
      { name: 'Sick Leave', allocated: 12, used: 2, remaining: 10 },
      { name: 'Casual Leave', allocated: 8, used: 1, remaining: 7 },
      { name: 'Privilege Leave', allocated: 15, used: 6, remaining: 9 }
    ],
    'Design & Product': [
      { name: 'Sick Leave', allocated: 12, used: 0, remaining: 12 },
      { name: 'Casual Leave', allocated: 8, used: 2, remaining: 6 },
      { name: 'Privilege Leave', allocated: 15, used: 4, remaining: 11 }
    ],
    'Quality Assurance': [
      { name: 'Sick Leave', allocated: 12, used: 3, remaining: 9 },
      { name: 'Casual Leave', allocated: 8, used: 1, remaining: 7 },
      { name: 'Privilege Leave', allocated: 15, used: 3, remaining: 12 }
    ],
    'Cloud Operations': [
      { name: 'Sick Leave', allocated: 12, used: 1, remaining: 11 },
      { name: 'Casual Leave', allocated: 8, used: 0, remaining: 8 },
      { name: 'Privilege Leave', allocated: 15, used: 2, remaining: 13 }
    ]
  };

  const wfhMap: Record<string, typeof WFH_TREND_DATA> = {
    All: WFH_TREND_DATA,
    'Software Engineering': [
      { name: 'Week 1', Office: 5, WFH: 0 },
      { name: 'Week 2', Office: 4, WFH: 1 },
      { name: 'Week 3', Office: 3, WFH: 2 },
      { name: 'Week 4', Office: 5, WFH: 0 }
    ],
    'Design & Product': [
      { name: 'Week 1', Office: 2, WFH: 3 },
      { name: 'Week 2', Office: 3, WFH: 2 },
      { name: 'Week 3', Office: 2, WFH: 3 },
      { name: 'Week 4', Office: 4, WFH: 1 }
    ],
    'Quality Assurance': [
      { name: 'Week 1', Office: 4, WFH: 1 },
      { name: 'Week 2', Office: 5, WFH: 0 },
      { name: 'Week 3', Office: 4, WFH: 1 },
      { name: 'Week 4', Office: 4, WFH: 1 }
    ],
    'Cloud Operations': [
      { name: 'Week 1', Office: 4, WFH: 1 },
      { name: 'Week 2', Office: 5, WFH: 0 },
      { name: 'Week 3', Office: 5, WFH: 0 },
      { name: 'Week 4', Office: 4, WFH: 1 }
    ]
  };

  const lateMap: Record<string, typeof LATE_TREND_DATA> = {
    All: LATE_TREND_DATA,
    'Software Engineering': [
      { week: 'Week 1', count: 1 },
      { week: 'Week 2', count: 0 },
      { week: 'Week 3', count: 1 },
      { week: 'Week 4', count: 0 }
    ],
    'Design & Product': [
      { week: 'Week 1', count: 0 },
      { week: 'Week 2', count: 0 },
      { week: 'Week 3', count: 0 },
      { week: 'Week 4', count: 0 }
    ],
    'Quality Assurance': [
      { week: 'Week 1', count: 0 },
      { week: 'Week 2', count: 0 },
      { week: 'Week 3', count: 1 },
      { week: 'Week 4', count: 0 }
    ],
    'Cloud Operations': [
      { week: 'Week 1', count: 0 },
      { week: 'Week 2', count: 0 },
      { week: 'Week 3', count: 0 },
      { week: 'Week 4', count: 0 }
    ]
  };

  const deptToTeamDistribution: Record<string, string[]> = {
    'Software Engineering': ['Core Eng', 'Support'],
    'Design & Product': ['Product'],
    'Quality Assurance': ['QA Team'],
    'Cloud Operations': ['Cloud Ops']
  };

  const presencePieMap: Record<string, typeof simplePresentAbsentData> = {
    All: simplePresentAbsentData,
    'Software Engineering': [
      { name: 'Present', value: 95.8 },
      { name: 'Absent / Unpaid', value: 1.2 },
      { name: 'Paid Leaves', value: 3.0 }
    ],
    'Design & Product': [
      { name: 'Present', value: 96.2 },
      { name: 'Absent / Unpaid', value: 0.8 },
      { name: 'Paid Leaves', value: 3.0 }
    ],
    'Quality Assurance': [
      { name: 'Present', value: 91.5 },
      { name: 'Absent / Unpaid', value: 3.5 },
      { name: 'Paid Leaves', value: 5.0 }
    ],
    'Cloud Operations': [
      { name: 'Present', value: 98.0 },
      { name: 'Absent / Unpaid', value: 0.0 },
      { name: 'Paid Leaves', value: 2.0 }
    ]
  };

  // Select stats/data based on selectedDepartment
  const currentKPI = departmentKPIStats[selectedDepartment] || departmentKPIStats['All'];
  const currentMonthlyTrend = trendMap[selectedDepartment] || trendMap['All'];
  const currentLeaveUtilization = leaveMap[selectedDepartment] || leaveMap['All'];
  const currentWFHAllocation = wfhMap[selectedDepartment] || wfhMap['All'];
  const currentLateArrivals = lateMap[selectedDepartment] || lateMap['All'];
  const currentPresencePie = presencePieMap[selectedDepartment] || presencePieMap['All'];

  const filteredTeamDistribution = selectedDepartment === 'All'
    ? ATTENDANCE_MOCK_STATS.teamDistribution
    : ATTENDANCE_MOCK_STATS.teamDistribution.filter(item =>
        (deptToTeamDistribution[selectedDepartment] || []).includes(item.name)
      );

  return (
    <div className="space-y-6" id="reports-analytics-tab">
      
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">Interactive Analytics & HR Dashboard</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Visually track team attendance efficiency, remote work trends, and sick leave utilizations.</p>
        </div>
        
        {/* Simple visual metadata */}
        <span className="text-xs bg-emerald-500/10 border border-emerald-500/25 text-emerald-600 dark:text-emerald-400 px-3 py-1.5 rounded-lg font-semibold font-mono self-start md:self-auto">
          Operational efficiency: 97.4%
        </span>
      </div>

      {/* Analytics Dropdown Filters Panel */}
      <div className={`p-4 rounded-xl border flex flex-col sm:flex-row flex-wrap items-center gap-4 shadow-sm ${
        isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'
      }`}>
        <div className="flex items-center gap-2 mr-2">
          <Sliders size={16} className="text-slate-400" />
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">Analytics Filter:</span>
        </div>

        {/* Month Dropdown */}
        <div className="relative w-full sm:w-auto flex-1 sm:flex-none">
          <select
            value={selectedMonth}
            onChange={(e) => setSelectedMonth(e.target.value)}
            className="w-full sm:w-36 px-2.5 py-1.5 border rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
          >
            <option value="May">May 2026 (Live)</option>
            <option value="April">April 2026</option>
            <option value="March">March 2026</option>
          </select>
        </div>

        {/* Department Dropdown */}
        <div className="relative w-full sm:w-auto flex-1 sm:flex-none">
          <select
            value={selectedDepartment}
            onChange={(e) => {
              setSelectedDepartment(e.target.value);
              setSelectedEmployee('All'); // Reset selected employee when department changes
            }}
            className="w-full sm:w-48 px-2.5 py-1.5 border rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
            id="department-filter-select"
          >
            <option value="All">All Departments</option>
            {departments.slice(1).map(d => (
              <option key={d} value={d}>{d}</option>
            ))}
          </select>
        </div>

        {/* Employee Dropdown */}
        <div className="relative w-full sm:w-auto flex-1 sm:flex-none">
          <select
            value={selectedEmployee}
            onChange={(e) => setSelectedEmployee(e.target.value)}
            className="w-full sm:w-44 px-2.5 py-1.5 border rounded-lg text-xs font-semibold focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
          >
            <option value="All">All Group Personnel</option>
            {TEAM_MEMBERS.filter(emp => selectedDepartment === 'All' || emp.department === selectedDepartment).map(emp => (
              <option key={emp.id} value={emp.name}>{emp.name}</option>
            ))}
          </select>
        </div>
      </div>

      {/* KPI stats for reports specifically */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className={`p-4 rounded-xl border flex items-center gap-4 ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
          <div className="h-10 w-10 rounded-lg bg-blue-500/10 text-blue-600 flex items-center justify-center flex-shrink-0">
            <TrendingUp size={20} />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase">Monthly Attendance Ratio</span>
            <span className="text-lg font-extrabold font-mono text-slate-800 dark:text-slate-100">
              {currentKPI.attendancePercentage}%
            </span>
          </div>
        </div>

        <div className={`p-4 rounded-xl border flex items-center gap-4 ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
          <div className="h-10 w-10 rounded-lg bg-violet-500/10 text-violet-600 flex items-center justify-center flex-shrink-0">
            <Laptop size={20} />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase">Remote Work Utilization</span>
            <span className="text-lg font-extrabold font-mono text-slate-800 dark:text-slate-100">
              {currentKPI.wfhSessions} Sessions
            </span>
          </div>
        </div>

        <div className={`p-4 rounded-xl border flex items-center gap-4 ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
          <div className="h-10 w-10 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center flex-shrink-0">
            <Clock size={20} />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase">Late Swipes Registered</span>
            <span className="text-lg font-extrabold font-mono text-slate-800 dark:text-slate-100">
              {currentKPI.lateArrivals} Occurrences
            </span>
          </div>
        </div>

        <div className={`p-4 rounded-xl border flex items-center gap-4 ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
          <div className="h-10 w-10 rounded-lg bg-rose-500/10 text-rose-500 flex items-center justify-center flex-shrink-0">
            <Users size={20} />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 block font-bold uppercase">Unapproved Leaves (LOP)</span>
            <span className="text-lg font-extrabold font-mono text-slate-800 dark:text-slate-100">
              {currentKPI.lopDays} Days
            </span>
          </div>
        </div>

      </div>

      {/* Grid of Graphs */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pb-6">
        
        {/* Chart 1: Monthly Attendance % Trend */}
        <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
          <div className="mb-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-0.5">Monthly Attendance Trend</h3>
            <p className="text-[10px] text-slate-400">Historical corporate attendance percentages over last 5 months.</p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={currentMonthlyTrend} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorPercentage" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#2563eb" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} />
                <XAxis dataKey="month" stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <YAxis domain={[80, 100]} stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: isDark ? '#1e293b' : '#ffffff', borderColor: isDark ? '#334155' : '#cbd5e1' }} />
                <Area type="monotone" dataKey="percentage" stroke="#2563eb" strokeWidth={2} fillOpacity={1} fill="url(#colorPercentage)" name="Attendance %" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Leave Utilization Comparison (Allocated vs Used vs Remaining) */}
        <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
          <div className="mb-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-0.5">Leave Utilization Profile</h3>
            <p className="text-[10px] text-slate-400">Compare allocated leave cycles, actual leaves taken, and balances.</p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={currentLeaveUtilization} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} />
                <XAxis dataKey="name" stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <YAxis stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: isDark ? '#1e293b' : '#ffffff', borderColor: isDark ? '#334155' : '#cbd5e1' }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 10, marginTop: 10 }} />
                <Bar dataKey="allocated" fill="#94a3b8" name="Allocated Quota" radius={[4, 4, 0, 0]} />
                <Bar dataKey="used" fill="#2563eb" name="Days Consumed" radius={[4, 4, 0, 0]} />
                <Bar dataKey="remaining" fill="#10b981" name="Unused Remainder" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 3: Live WFH Trend (Office vs WFH) */}
        <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
          <div className="mb-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-0.5">WFH Trend (Weekly Distribution)</h3>
            <p className="text-[10px] text-slate-400">Assess work from home versus in-office volumes this Month.</p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={currentWFHAllocation} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} />
                <XAxis dataKey="name" stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <YAxis stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: isDark ? '#1e293b' : '#ffffff', borderColor: isDark ? '#334155' : '#cbd5e1' }} />
                <Legend wrapperStyle={{ fontSize: 10 }} />
                <Bar dataKey="Office" fill="#2563eb" stackId="a" name="In-Office" />
                <Bar dataKey="WFH" fill="#8b5cf6" stackId="a" name="Work From Home (WFH)" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 4: Late Arrival frequency occurrences */}
        <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
          <div className="mb-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-0.5">Late Swipes registered Arrivals</h3>
            <p className="text-[10px] text-slate-400">Weekly tracking of late metrics in current active month.</p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={currentLateArrivals} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} />
                <XAxis dataKey="week" stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <YAxis stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: isDark ? '#1e293b' : '#ffffff', borderColor: isDark ? '#334155' : '#cbd5e1' }} />
                <Line type="monotone" dataKey="count" stroke="#f59e0b" strokeWidth={3} activeDot={{ r: 8 }} name="Late Arrivals" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 5: Team Attendance Summary (Multi bar chart for squads present/absent) */}
        <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
          <div className="mb-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-0.5">Operational Team Attendance Summary</h3>
            <p className="text-[10px] text-slate-400">Coverage metrics of direct teams this month.</p>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={filteredTeamDistribution} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#334155' : '#e2e8f0'} />
                <XAxis dataKey="name" stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <YAxis stroke={isDark ? '#94a3b8' : '#64748b'} style={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ backgroundColor: isDark ? '#1e293b' : '#ffffff', borderColor: isDark ? '#334155' : '#cbd5e1' }} />
                <Legend iconType="circle" wrapperStyle={{ fontSize: 9 }} />
                <Bar dataKey="present" fill="#10b981" name="Office Presence" radius={[2, 2, 0, 0]} />
                <Bar dataKey="wfh" fill="#8b5cf6" name="WFH Presence" radius={[2, 2, 0, 0]} />
                <Bar dataKey="late" fill="#f59e0b" name="Late Logs" radius={[2, 2, 0, 0]} />
                <Bar dataKey="absent" fill="#ef4444" name="Leaves / Absent" radius={[2, 2, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 6: Present vs Absent (Aggregated PieChart) */}
        <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-755' : 'bg-white border-slate-100'}`}>
          <div className="mb-4">
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-0.5">Aggregated Operations Ratio</h3>
            <p className="text-[10px] text-slate-400">Total present vs absent vs leave utilization profile breakdown.</p>
          </div>
          <div className="h-64 flex flex-col sm:flex-row items-center justify-between">
            <div className="h-44 w-44 flex-shrink-0">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={currentPresencePie}
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={65}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {currentPresencePie.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `${value}%`} />
                </PieChart>
              </ResponsiveContainer>
            </div>

            {/* Visual Legend checklist */}
            <div className="text-xs space-y-2 mt-4 sm:mt-0 w-full sm:w-1/2">
              {currentPresencePie.map((d, index) => (
                <div key={d.name} className="flex justify-between items-center border-b pb-1 dark:border-slate-850">
                  <div className="flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full flex-shrink-0" style={{ backgroundColor: PIE_COLORS[index] }} />
                    <span className="font-semibold text-slate-650 truncate">{d.name}</span>
                  </div>
                  <span className="font-mono font-bold text-[10px]">{d.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
