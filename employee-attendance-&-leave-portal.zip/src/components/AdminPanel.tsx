/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Users,
  CheckCircle,
  XCircle,
  Clock,
  Briefcase,
  AlertTriangle,
  Search,
  Plus,
  Edit,
  Trash2,
  MailCheck,
  Building,
  UserCheck,
  Calendar,
  Layers,
  Sparkles,
  ChevronDown,
  Download,
  Check,
  Sliders,
  BellRing,
  Award,
  BookOpen,
  ArrowRight,
  ShieldCheck,
  Zap,
  Coffee,
  HeartCrack
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  AreaChart,
  Area,
  PieChart,
  Pie,
  Cell
} from 'recharts';

import { Employee, AttendanceRecord, LeaveRequest, RegularizationRequest } from '../types';

interface AdminPanelProps {
  employees: Employee[];
  setEmployees: React.Dispatch<React.SetStateAction<Employee[]>>;
  attendanceData: AttendanceRecord[];
  setAttendanceData: React.Dispatch<React.SetStateAction<AttendanceRecord[]>>;
  leaveHistory: LeaveRequest[];
  setLeaveHistory: React.Dispatch<React.SetStateAction<LeaveRequest[]>>;
  regularizationHistory: RegularizationRequest[];
  setRegularizationHistory: React.Dispatch<React.SetStateAction<RegularizationRequest[]>>;
  isDark: boolean;
  onSendNotification: (title: string, message: string, type: 'info' | 'success' | 'warning') => void;
}

export default function AdminPanel({
  employees,
  setEmployees,
  attendanceData,
  setAttendanceData,
  leaveHistory,
  setLeaveHistory,
  regularizationHistory,
  setRegularizationHistory,
  isDark,
  onSendNotification
}: AdminPanelProps) {
  // Tabs: 'dashboard', 'employees', 'attendance', 'leaves', 'rosters', 'reports', 'settings'
  const [activeTab, setActiveTab] = useState<'dashboard' | 'employees' | 'attendance' | 'leaves' | 'rosters' | 'reports' | 'settings'>('dashboard');

  // Interactive Search & Filtering
  const [employeeSearchQuery, setEmployeeSearchQuery] = useState('');
  const [selectedDeptFilter, setSelectedDeptFilter] = useState('All');
  const [selectedManagerFilter, setSelectedManagerFilter] = useState('All');

  // Onboard New Joiner Modal States
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingEmployeeId, setEditingEmployeeId] = useState<string | null>(null);

  // New Employee Form State
  const [empName, setEmpName] = useState('');
  const [empEmail, setEmpEmail] = useState('');
  const [empPhone, setEmpPhone] = useState('');
  const [empDept, setEmpDept] = useState('Software Engineering');
  const [empDesg, setEmpDesg] = useState('');
  const [empDoj, setEmpDoj] = useState('2026-06-01');
  const [empManager, setEmpManager] = useState('Shalini Murthy');
  const [empShift, setEmpShift] = useState('General Shift (12:00 PM - 09:00 PM)');

  // Onboarding Workflow triggers
  const [sendITEmail, setSendITEmail] = useState(true);
  const [sendTeamAnnouncement, setSendTeamAnnouncement] = useState(true);
  const [isProcessingOnboarding, setIsProcessingOnboarding] = useState(false);
  const [onboardingSuccessMessage, setOnboardingSuccessMessage] = useState<string | null>(null);

  // Manual Punch Correction form
  const [showCorrectionModal, setShowCorrectionModal] = useState(false);
  const [selectedDateForCorrection, setSelectedDateForCorrection] = useState('');
  const [selectedEmployeeForCorrection, setSelectedEmployeeForCorrection] = useState('');
  const [manualClockIn, setManualClockIn] = useState('12:00');
  const [manualClockOut, setManualClockOut] = useState('21:00');
  const [correctionSuccessMsg, setCorrectionSuccessMsg] = useState<string | null>(null);

  // Settings states
  const [officeTimingIn, setOfficeTimingIn] = useState('12:00');
  const [officeTimingOut, setOfficeTimingOut] = useState('21:00');
  const [gracePeriod, setGracePeriod] = useState(15); // minutes
  const [sandwichRuleActive, setSandwichRuleActive] = useState(true);
  const [monthlyAccrualCL, setMonthlyAccrualCL] = useState(1.5);
  const [weekendPolicy, setWeekendPolicy] = useState('Sunday Standard Off, Alternating Saturdays');

  // Reports filters
  const [reportType, setReportType] = useState('Monthly Attendance');
  const [reportMonth, setReportMonth] = useState('May');
  const [reportSuccessMsg, setReportSuccessMsg] = useState<string | null>(null);

  // Notification Banner State
  const [adminToast, setAdminToast] = useState<{ message: string; type: 'success' | 'info' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'error') => {
    setAdminToast({ message, type });
    setTimeout(() => setAdminToast(null), 4000);
  };

  // Safe calculated metrics for Summary Cards (mocking entire project scope values dynamically)
  const totalEmployeesCount = employees.length;
  const presentTodayCount = Math.round(totalEmployeesCount * 0.82);
  const wfhTodayCount = Math.round(totalEmployeesCount * 0.12);
  const absentTodayCount = totalEmployeesCount - (presentTodayCount + wfhTodayCount);
  const lateTodayCount = 1; 
  const onLeaveTodayCount = leaveHistory.filter(l => l.status === 'Approved').length;

  // Pie chart variables
  const departmentData = [
    { name: 'Software Eng', value: employees.filter(e => e.department === 'Software Engineering').length },
    { name: 'Design/Product', value: employees.filter(e => e.department === 'Design & Product').length },
    { name: 'QA Team', value: employees.filter(e => e.department === 'Quality Assurance').length || 1 },
    { name: 'Cloud Ops', value: employees.filter(e => e.department === 'Cloud Operations').length || 1 },
    { name: 'HR/Admin', value: employees.filter(e => e.department === 'Human Resources' || e.department === 'Administration').length || 1 }
  ];

  // Colors for charts
  const COLORS = ['#2563eb', '#3b82f6', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

  // Leave risk prediction category calculator
  const getLeaveRisk = (employeeName: string) => {
    // Look at employee leave requests count
    const totalDaysTaken = leaveHistory
      .filter(l => l.reason && l.status === 'Approved')
      .reduce((sum, current) => sum + current.days, 0);

    if (totalDaysTaken <= 4) return { label: 'Low Risk', color: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/20 dark:text-emerald-400', percentage: '15%' };
    if (totalDaysTaken <= 8) return { label: 'Medium Risk', color: 'bg-amber-50 text-amber-700 dark:bg-amber-950/20 dark:text-amber-400', percentage: '45%' };
    return { label: 'High Risk', color: 'bg-rose-50 text-rose-700 dark:bg-rose-950/20 dark:text-rose-400', percentage: '88%' };
  };

  // Form submission handler
  const handleSaveEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!empName.trim() || !empEmail.trim()) {
      showToast("Employee Name and Email are mandatory fields.", "error");
      return;
    }

    setIsProcessingOnboarding(true);

    setTimeout(() => {
      if (editingEmployeeId) {
        // Edit flow
        setEmployees(prev => prev.map(emp => {
          if (emp.id === editingEmployeeId) {
            return {
              ...emp,
              name: empName,
              email: empEmail,
              department: empDept,
              role: empDesg
            };
          }
          return emp;
        }));
        showToast(`Employee ${empName} metadata successfully revised.`, 'success');
        onSendNotification('Employee Details Modifed', `The HR Administrator revised details for employee ${empName}.`, 'info');
      } else {
        // Create onboard workflow
        const randomId = `EMP-2026-${Math.floor(Math.random() * 9000) + 1000}`;
        const newEmp: Employee = {
          id: randomId,
          name: empName,
          email: empEmail,
          department: empDept,
          role: empDesg || 'Associate Engineer',
          avatar: empName.split(' ').map(n => n[0]).join('').substring(0, 2).toUpperCase()
        };

        setEmployees(prev => [...prev, newEmp]);
        
        let subLogs = "";
        if (sendITEmail) subLogs += "• Triggered IT provisioning pipeline email. Outlook mailbox generated. \n";
        if (sendTeamAnnouncement) subLogs += "• Standard new joiner broadcast published to corporate announcements. \n";

        setOnboardingSuccessMessage(`Onboarding complete! New credentials issued.\nID: ${randomId}\n${subLogs}`);
        showToast(`Successfully onboarded ${empName}!`, 'success');
        onSendNotification('New Team Member Onboarded', `${empName} has officially joined the ${empDept} division.`, 'success');
      }

      setIsProcessingOnboarding(false);
      resetEmployeeForm();
      if (editingEmployeeId) {
        setShowAddModal(false);
      }
    }, 1200);
  };

  const handleDeactivateEmployee = (id: string, name: string) => {
    if (confirm(`Are you sure you want to suspend/deactivate the biometric and HR records for ${name}?`)) {
      setEmployees(prev => prev.filter(e => e.id !== id));
      showToast(`Employee ${name} database access suspended.`, 'info');
      onSendNotification('Employee Deactivated', `Biometric access for ${name} has been revoked by HR admin.`, 'warning');
    }
  };

  const handleEditEmployeeLaunch = (emp: Employee) => {
    setEditingEmployeeId(emp.id);
    setEmpName(emp.name);
    setEmpEmail(emp.email);
    setEmpDept(emp.department);
    setEmpDesg(emp.role);
    setEmpDoj('2026-05-30');
    setShowAddModal(true);
    setOnboardingSuccessMessage(null);
  };

  const resetEmployeeForm = () => {
    setEmpName('');
    setEmpEmail('');
    setEmpPhone('');
    setEmpDesg('');
    setEditingEmployeeId(null);
  };

  // Regularization review actions
  const handleRegReview = (id: string, action: 'Approved' | 'Rejected', date: string) => {
    const comments = prompt(`Enter brief administrator review feedback for the ${action.toLowerCase()} decision:`);
    
    // Update regularization record
    setRegularizationHistory(prev => prev.map(item => {
      if (item.id === id) {
        return {
          ...item,
          status: action,
          approverComments: comments || `Verified against auxiliary access swipe. Request ${action.toLowerCase()}.`
        };
      }
      return item;
    }));

    // Update attendance record matching this date
    setAttendanceData(prev => prev.map(rec => {
      if (rec.date === date) {
        return {
          ...rec,
          status: action === 'Approved' ? 'Present' : 'Late',
          regularizationStatus: action
        };
      }
      return rec;
    }));

    showToast(`Correction ticket #${id} evaluated as: ${action}`, action === 'Approved' ? 'success' : 'info');
    onSendNotification(
      `Regularization ${action}`,
      `Your timesheet adjustment request for ${date} has been ${action.toLowerCase()} by admin.`,
      action === 'Approved' ? 'success' : 'warning'
    );
  };

  // Leave queue review actions
  const handleLeaveReview = (id: string, action: 'Approved' | 'Rejected', employeeName: string) => {
    setLeaveHistory(prev => prev.map(item => {
      if (item.id === id) {
        return {
          ...item,
          status: action,
          approver: `HR Admin (Decided)`
        };
      }
      return item;
    }));

    showToast(`Leave application #${id} has been ${action.toLowerCase()}`, action === 'Approved' ? 'success' : 'info');
    onSendNotification(
      `Leave Claim ${action}`,
      `Your request for leave id #${id} has been ${action.toLowerCase()} by HR Operations.`,
      action === 'Approved' ? 'success' : 'warning'
    );
  };

  // Manual Punch Overrule
  const handleManualPunchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEmployeeForCorrection || !selectedDateForCorrection) {
      showToast("Please choose employee and select punch date.", "error");
      return;
    }

    const matchedEmpName = employees.find(e => e.id === selectedEmployeeForCorrection)?.name || 'Employee';

    const newPunch: AttendanceRecord = {
      id: `A-ADMIN-${Date.now()}`,
      date: selectedDateForCorrection,
      shift: 'General Shift (12:00 PM - 09:00 PM)',
      clockIn: manualClockIn,
      clockOut: manualClockOut,
      totalHours: 9.0,
      status: 'Present',
      regularizationStatus: 'Approved'
    };

    // Replace if date exists, otherwise append
    setAttendanceData(prev => {
      const exists = prev.some(r => r.date === selectedDateForCorrection);
      if (exists) {
        return prev.map(r => r.date === selectedDateForCorrection ? newPunch : r);
      }
      return [newPunch, ...prev];
    });

    setCorrectionSuccessMsg(`Biometric override verified for ${matchedEmpName} on ${selectedDateForCorrection}.`);
    showToast(`biometric patch applied for ${matchedEmpName}`, 'success');
    onSendNotification(`Biometric Logs Corrected`, `Administrator adjusted your clock logs for ${selectedDateForCorrection}. Check your portal.`, 'info');
    
    setTimeout(() => {
      setShowCorrectionModal(false);
      setCorrectionSuccessMsg(null);
    }, 2500);
  };

  // Report extraction builder
  const triggerDownloadReport = () => {
    if (!reportMonth) return;
    setReportSuccessMsg(`Generating highly indexed ${reportType} CSV payload for ${reportMonth} 2026...`);
    
    setTimeout(() => {
      setReportSuccessMsg(`Download initiated: HR_NexusLink_${reportType.replace(/ /g, '_')}_${reportMonth}_2026.csv`);
      showToast(`CSV Report generated & downloaded successfully.`, 'success');
    }, 1800);
  };

  return (
    <div className="space-y-6" id="admin-panel-module">
      
      {/* Toast Alert popup banner */}
      {adminToast && (
        <div className={`fixed bottom-5 right-5 z-50 p-4 rounded-xl shadow-2xl flex items-center gap-2 border text-xs font-semibold animate-bounce ${
          adminToast.type === 'success' 
            ? 'bg-emerald-50 border-emerald-200 text-emerald-800 dark:bg-emerald-950/90 dark:text-emerald-300' 
            : adminToast.type === 'error'
              ? 'bg-rose-50 border-rose-200 text-rose-800 dark:bg-rose-950/90 dark:text-rose-300'
              : 'bg-blue-50 border-blue-200 text-blue-800 dark:bg-blue-950/90 dark:text-blue-300'
        }`}>
          {adminToast.type === 'success' ? <CheckCircle size={16} /> : <AlertTriangle size={16} />}
          <span>{adminToast.message}</span>
        </div>
      )}

      {/* Header Panel with HR Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl p-6 text-white shadow-lg relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-white/5 rounded-full blur-3xl p-4 pointer-events-none" />
        <div className="space-y-1 z-10">
          <div className="flex items-center gap-2 bg-white/10 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider w-fit">
            <ShieldCheck size={12} fill="currentColor" className="text-blue-200" /> Admin Command Level
          </div>
          <h2 className="text-xl font-extrabold tracking-tight">Enterprise HR Management console</h2>
          <p className="text-xs text-blue-100">Maintain corporate policies, review approvals, assign shifts, and manage compliance rosters.</p>
        </div>
        
        {/* Quick action buttons */}
        <div className="flex flex-wrap gap-2 z-10">
          <button
            onClick={() => {
              setEditingEmployeeId(null);
              resetEmployeeForm();
              setShowAddModal(true);
              setOnboardingSuccessMessage(null);
            }}
            className="px-4 py-2 bg-white text-blue-700 rounded-lg text-xs font-bold shadow hover:bg-slate-50 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Plus size={14} /> Onboard New Employee
          </button>
          <button
            onClick={() => setShowCorrectionModal(true)}
            className="px-4 py-2 bg-blue-500/30 text-white rounded-lg text-xs font-bold border border-white/20 hover:bg-white/10 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Sliders size={14} /> Overrule Biometrics
          </button>
        </div>
      </div>

      {/* Sub tabs Navigation Bar */}
      <div className="flex flex-wrap border-b border-slate-200 dark:border-slate-800 gap-1.5" id="admin-tabs">
        {[
          { id: 'dashboard', label: 'Summary Desk', icon: Users },
          { id: 'employees', label: 'Employee Directory', icon: UserCheck },
          { id: 'attendance', label: 'Biometrics Override', icon: Clock },
          { id: 'leaves', label: 'Leave Reviews', icon: ShieldCheck },
          { id: 'rosters', label: 'Shift Scheduler', icon: Calendar },
          { id: 'reports', label: 'Analytical Reports', icon: Download },
          { id: 'settings', label: 'Global Configurations', icon: Sliders }
        ].map((tab) => {
          const IconComponent = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 text-xs font-semibold rounded-t-lg border-b-2 transition-all flex items-center gap-1.5 cursor-pointer ${
                isActive 
                  ? 'border-blue-600 text-blue-600 dark:text-blue-400 bg-blue-50/20 dark:bg-blue-900/10'
                  : 'border-transparent text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-900/40'
              }`}
            >
              <IconComponent size={14} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Active Sub View Switcher */}
      <div className="min-h-[400px]">
        
        {/* Sub-tab 1: ADMIN DASHBOARD SUMMARY */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6 animate-fade-in" id="admin-subtab-dashboard">
            
            {/* KPI Summary Cards */}
            <div className="grid grid-cols-2 lg:grid-cols-6 gap-4">
              
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Total Registered</span>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-slate-800 dark:text-white">{totalEmployeesCount}</span>
                  <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-950/20 text-blue-500"><Users size={16} /></div>
                </div>
                <span className="text-[9px] text-slate-400 block">Active HR biometric IDs</span>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Present Today</span>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-emerald-600 dark:text-emerald-400">{presentTodayCount}</span>
                  <div className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/20 text-emerald-500"><CheckCircle size={16} /></div>
                </div>
                <span className="text-[9px] text-emerald-600 block">● Site attendance live</span>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">WFH Today</span>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-sky-500">{wfhTodayCount}</span>
                  <div className="p-2 rounded-lg bg-sky-50 dark:bg-sky-950/20 text-sky-500"><Briefcase size={16} /></div>
                </div>
                <span className="text-[9px] text-sky-500 block">Remote VPN active</span>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Absent Today</span>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-rose-500">{absentTodayCount}</span>
                  <div className="p-2 rounded-lg bg-rose-50 dark:bg-rose-950/20 text-rose-500"><XCircle size={16} /></div>
                </div>
                <span className="text-[9px] text-rose-500 block">No biometric logs yet</span>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">Late Arrivals</span>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-amber-500">{lateTodayCount}</span>
                  <div className="p-2 rounded-lg bg-amber-50 dark:bg-amber-950/20 text-amber-500"><Clock size={16} /></div>
                </div>
                <span className="text-[9px] text-warning block">Arrived past grace limits</span>
              </div>

              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 space-y-2">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">On Approval Leave</span>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-black text-purple-500">{onLeaveTodayCount}</span>
                  <div className="p-2 rounded-lg bg-purple-50 dark:bg-purple-950/20 text-purple-550"><Calendar size={16} /></div>
                </div>
                <span className="text-[9px] text-purple-400 block">Pre-scheduled leave models</span>
              </div>

            </div>

            {/* Visual Analytics Charts Grid */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Chart Line: Live Attendance Percentage trend */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Monthly Attendance Trend</h3>
                  <span className="text-xs font-semibold text-slate-600 bg-slate-100 px-2 py-0.5 rounded-md dark:bg-slate-800 dark:text-slate-300">Target: &gt;95%</span>
                </div>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={[
                      { month: 'Jan', percentage: 95 },
                      { month: 'Feb', percentage: 92 },
                      { month: 'Mar', percentage: 96 },
                      { month: 'Apr', percentage: 93 },
                      { month: 'May', percentage: 94.6 }
                    ]}>
                      <defs>
                        <linearGradient id="colorTrend" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#2563eb" stopOpacity={0.2} />
                          <stop offset="95%" stopColor="#2563eb" stopOpacity={0.0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="month" stroke="#94a3b8" fontSize={11} tickLine={false} />
                      <YAxis domain={[80, 100]} stroke="#94a3b8" fontSize={11} tickLine={false} />
                      <Tooltip formatter={(value) => [`${value}% Attendance`]} />
                      <Area type="monotone" dataKey="percentage" stroke="#2563eb" strokeWidth={2} fillOpacity={1} fill="url(#colorTrend)" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Chart Bar: Department-wise headcount distribution */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Department Distribution Index</h3>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={departmentData}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                      <YAxis stroke="#94a3b8" fontSize={11} tickLine={false} />
                      <Tooltip />
                      <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]}>
                        {departmentData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Chart Area: Attrition Dashboard & Leave utilization heatmap (Simulated visually) */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Leave Utilization Analytics</h3>
                  <span className="text-[10px] text-slate-400">Accrued vs Availed logs</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center py-2">
                  <div className="p-3 bg-blue-50/50 dark:bg-blue-950/20 rounded-lg">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase">Casual Leves</span>
                    <p className="text-lg font-bold text-blue-600 block mt-1">CL: 83% Used</p>
                  </div>
                  <div className="p-3 bg-indigo-50/50 dark:bg-indigo-950/20 rounded-lg">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase">Sick Leaves</span>
                    <p className="text-lg font-bold text-indigo-600 block mt-1">SL: 22% Used</p>
                  </div>
                  <div className="p-3 bg-emerald-50/50 dark:bg-emerald-950/20 rounded-lg">
                    <span className="text-[10px] font-semibold text-slate-400 uppercase">Privilege Leave</span>
                    <p className="text-lg font-bold text-emerald-600 block mt-1">PL: 40% Used</p>
                  </div>
                </div>
                
                {/* Visual Attrition Risk Alert meter */}
                <div className="border border-slate-100 dark:border-slate-800 p-3 rounded-lg flex items-center justify-between">
                  <div className="space-y-0.5 text-left">
                    <span className="text-xs font-bold text-slate-700 dark:text-slate-350 block">Predictive Team Attrition Risk</span>
                    <p className="text-[10px] text-slate-400 leading-normal">Evaluated across current extreme leave utilizations, overtime hours, and late logins.</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <span className="px-2.5 py-1 text-[11px] font-bold uppercase rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-400">
                      LOW RISK (2.5%)
                    </span>
                  </div>
                </div>
              </div>

              {/* Heatmap Visual Representer: Attendance Heatmap for entire corporation */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Weekly Attendance Heatmap</h3>
                  <div className="flex gap-2 text-[9px]">
                    <span className="flex items-center gap-1 font-semibold text-slate-500"><span className="w-2 h-2 bg-rose-400 rounded-sm" /> 0-50%</span>
                    <span className="flex items-center gap-1 font-semibold text-slate-500"><span className="w-2 h-2 bg-amber-400 rounded-sm" /> 50-80%</span>
                    <span className="flex items-center gap-1 font-semibold text-slate-500"><span className="w-2 h-2 bg-emerald-500 rounded-sm" /> 90%+</span>
                  </div>
                </div>

                <div className="grid grid-cols-5 gap-3 text-center py-2.5 font-mono text-xs">
                  {['Mon', 'Tue', 'Wed', 'Thu', 'Fri'].map((day, dIdx) => {
                    const statusColor = (dIdx === 1) ? 'bg-amber-400' : (dIdx === 4) ? 'bg-emerald-405 text-white bg-blue-600' : 'bg-emerald-500 text-white';
                    return (
                      <div key={day} className="space-y-1">
                        <span className="text-[10px] text-slate-400 block font-bold uppercase">{day}</span>
                        <div className={`p-4 rounded-lg font-bold text-white leading-none ${statusColor}`}>
                          {(dIdx === 1) ? '84%' : (dIdx === 4) ? '98%' : '94%'}
                        </div>
                      </div>
                    );
                  })}
                </div>
                <p className="text-[9px] text-slate-400 font-sans italic text-center">Heat value represents total team biometric coverage percentage relative to standard rosters.</p>
              </div>

            </div>

          </div>
        )}

        {/* Sub-tab 2: EMPLOYEE DIRECTORY */}
        {activeTab === 'employees' && (
          <div className="space-y-4 animate-fade-in" id="admin-subtab-employees">
            
            {/* Filter controls */}
            <div className="flex flex-col md:flex-row gap-3 items-center justify-between bg-white dark:bg-slate-900 p-4 border border-slate-200 dark:border-slate-800 rounded-xl">
              
              <div className="relative w-full md:max-w-xs">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={15} />
                <input
                  type="text"
                  placeholder="Search by name, ID or role..."
                  value={employeeSearchQuery}
                  onChange={(e) => setEmployeeSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-4 py-1.5 bg-slate-50 dark:bg-slate-950 border border-slate-250 dark:border-slate-850 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500"
                />
              </div>

              <div className="flex flex-wrap gap-2.5 w-full md:w-auto overflow-x-auto justify-end">
                
                {/* Filter department dropdown */}
                <select
                  value={selectedDeptFilter}
                  onChange={(e) => setSelectedDeptFilter(e.target.value)}
                  className="px-2.5 py-1.5 border rounded-lg text-xs dark:bg-slate-950 border-slate-250 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="All">All Departments</option>
                  <option value="Software Engineering">Software Engineering</option>
                  <option value="Design & Product">Design & Product</option>
                  <option value="Quality Assurance">Quality Assurance</option>
                  <option value="Cloud Operations">Cloud Operations</option>
                </select>

                {/* Risk Level filter indicator */}
                <div className="p-1 px-3.5 border rounded-lg text-xs flex items-center justify-center font-bold text-blue-600 bg-blue-50/10">
                  Real-time Risk Analytics Active
                </div>

              </div>

            </div>

            {/* Employee Form Success onboarding banner */}
            {onboardingSuccessMessage && (
              <div className="p-4 bg-emerald-50 border border-emerald-100 rounded-xl space-y-2">
                <h4 className="text-xs font-bold text-emerald-800 flex items-center gap-1.5">
                  <UserCheck size={16} /> Automated Onboarding Pipeline Succeeded
                </h4>
                <pre className="text-[11px] font-mono text-emerald-700 whitespace-pre-wrap leading-relaxed">{onboardingSuccessMessage}</pre>
                <button
                  onClick={() => setOnboardingSuccessMessage(null)}
                  className="text-[10px] font-bold text-emerald-800 hover:underline cursor-pointer"
                >
                  Dismiss complete logs
                </button>
              </div>
            )}

            {/* Employees Grid / Table */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-sm" id="directory-table">
              <table className="w-full text-xs text-left text-slate-650">
                <thead className="bg-slate-50 dark:bg-slate-850/50 text-slate-500 border-b border-inherit font-bold">
                  <tr>
                    <th className="p-3">Employee ID</th>
                    <th className="p-3">Staff Member</th>
                    <th className="p-3">Division</th>
                    <th className="p-3">Role / job Title</th>
                    <th className="p-3">Leave Risk Analytics</th>
                    <th className="p-3 text-right">Biometric Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {employees
                    .filter(emp => {
                      const queryMatch = emp.name.toLowerCase().includes(employeeSearchQuery.toLowerCase()) ||
                        emp.id.toLowerCase().includes(employeeSearchQuery.toLowerCase()) ||
                        emp.role.toLowerCase().includes(employeeSearchQuery.toLowerCase());
                      const deptMatch = selectedDeptFilter === 'All' || emp.department === selectedDeptFilter;
                      return queryMatch && deptMatch;
                    })
                    .map(emp => {
                      const risk = getLeaveRisk(emp.name);
                      return (
                        <tr key={emp.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/60 transition-colors">
                          <td className="p-3 font-mono text-slate-400 font-bold">{emp.id}</td>
                          <td className="p-3 font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                            <span className="h-7 w-7 rounded-lg bg-blue-100 dark:bg-slate-800 text-blue-600 dark:text-blue-400 font-bold flex items-center justify-center text-[10px] shadow-sm">
                              {emp.avatar || emp.name.split(' ').map(n=>n[0]).join('')}
                            </span>
                            <div className="flex flex-col">
                              <span>{emp.name}</span>
                              <span className="text-[9px] text-slate-400 dark:text-slate-500 font-medium">{emp.email}</span>
                            </div>
                          </td>
                          <td className="p-3 font-medium">{emp.department}</td>
                          <td className="p-3 font-medium text-slate-500">{emp.role}</td>
                          <td className="p-3">
                            <div className="flex items-center gap-1.5">
                              <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold ${risk.color}`}>
                                {risk.label}
                              </span>
                              <span className="text-[9px] text-slate-400 font-mono">({risk.percentage})</span>
                            </div>
                          </td>
                          <td className="p-3 text-right space-x-1.5">
                            <button
                              onClick={() => handleEditEmployeeLaunch(emp)}
                              className="p-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/20 rounded cursor-pointer"
                              title="Modify Employee Records"
                            >
                              <Edit size={14} />
                            </button>
                            <button
                              onClick={() => handleDeactivateEmployee(emp.id, emp.name)}
                              className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-955/20 rounded cursor-pointer"
                              title="Revoke Biometric Access"
                            >
                              <Trash2 size={14} />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {/* Sub-tab 3: BIOMETRIC OVERRIDES & CORRECTIONS */}
        {activeTab === 'attendance' && (
          <div className="space-y-6 animate-fade-in" id="admin-subtab-attendance">
            
            {/* Regularization Approvals Queue */}
            <div className="space-y-3 bg-white dark:bg-slate-900 p-5 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Awaiting Regularization Approvals Queue</h3>
                  <p className="text-[10px] text-slate-400">Claims submitted by employees to repair biometric exceptions.</p>
                </div>
                <span className="px-2.5 py-1 text-[10px] font-bold rounded-lg bg-orange-100 text-orange-700 dark:bg-orange-950/20 dark:text-orange-400">
                  {regularizationHistory.filter(r => r.status === 'Pending').length} Request(s) Pending
                </span>
              </div>

              {regularizationHistory.filter(r => r.status === 'Pending').length === 0 ? (
                <div className="p-6 text-center text-slate-400 italic">
                  All employee regularization tickets fully cleared. Standard biometric synchronization active.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800 space-y-3">
                  {regularizationHistory
                    .filter(r => r.status === 'Pending')
                    .map(item => (
                      <div key={item.id} className="pt-3 flex flex-col md:flex-row justify-between gap-4 first:pt-0">
                        <div className="space-y-1 text-left">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-bold text-slate-800 dark:text-slate-200 text-xs">Kavitha Mohan</span>
                            <span className="text-[10px] font-mono text-slate-400 font-bold">({item.id})</span>
                            <span className="bg-blue-50 text-blue-600 px-1.5 py-0.5 rounded text-[9px] font-bold">{item.date}</span>
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-400 leading-normal font-sans italic">
                            &quot;{item.reason}&quot;
                          </p>
                          <div className="flex gap-4 text-[10px] text-slate-400 font-mono mt-1">
                            <span>Correction Request Punch In: <strong className="text-blue-600 font-bold">{item.missingInTime}</strong></span>
                            <span>Punch Out: <strong className="text-indigo-600 font-bold">{item.missingOutTime}</strong></span>
                            {/* Simulated Attachment link */}
                            <span className="text-blue-500 underline cursor-pointer">📎 View Biometric_Exception.pdf</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1.5 flex-shrink-0">
                          <button
                            onClick={() => handleRegReview(item.id, 'Approved', item.date)}
                            className="p-1 px-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-[10px] font-bold shadow flex items-center gap-1 cursor-pointer"
                          >
                            <Check size={11} /> Approve
                          </button>
                          <button
                            onClick={() => handleRegReview(item.id, 'Rejected', item.date)}
                            className="p-1 px-3 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-[10px] font-bold border cursor-pointer"
                          >
                            Reject
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>

            {/* Attendance database Logs Viewer */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-3">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Global Master Attendance Record</h3>
                <div className="text-[10px] text-blue-600 font-bold uppercase tracking-wider">
                  Biometric Logs Syncing Live (5m frequency)
                </div>
              </div>

              {/* Attendance Data Table */}
              <div className="overflow-x-auto border rounded-xl">
                <table className="w-full text-xs text-left text-slate-600">
                  <thead className="bg-slate-50 dark:bg-slate-850/50 text-slate-500 border-b border-slate-200 dark:border-slate-850">
                    <tr>
                      <th className="p-3">Staff Member</th>
                      <th className="p-3">Roster Date</th>
                      <th className="p-3">In Stamp</th>
                      <th className="p-3">Out Stamp</th>
                      <th className="p-3">Worked Hours</th>
                      <th className="p-3">System Evaluated Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-900/40">
                      <td className="p-3 font-bold text-slate-800 dark:text-slate-300">Kavitha Mohan</td>
                      <td className="p-3 font-mono">2026-05-29</td>
                      <td className="p-3 font-mono font-medium text-emerald-600">11:52</td>
                      <td className="p-3 font-mono font-medium text-indigo-600">21:04</td>
                      <td className="p-3 font-mono font-semibold">9.2 Hrs</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-50 text-emerald-700">Present</span></td>
                    </tr>
                    <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-900/40">
                      <td className="p-3 font-bold text-slate-800 dark:text-slate-300">Arjun Sharma</td>
                      <td className="p-3 font-mono">2026-05-29</td>
                      <td className="p-3 font-mono font-medium text-emerald-600">12:03</td>
                      <td className="p-3 font-mono font-medium text-indigo-600">21:01</td>
                      <td className="p-3 font-mono font-semibold">9.0 Hrs</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-emerald-50 text-emerald-700">Present</span></td>
                    </tr>
                    <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-900/40">
                      <td className="p-3 font-bold text-slate-800 dark:text-slate-300">Priya Patel</td>
                      <td className="p-3 font-mono">2026-05-29</td>
                      <td className="p-3 font-mono text-slate-400">--:--</td>
                      <td className="p-3 font-mono text-slate-400">--:--</td>
                      <td className="p-3 font-mono font-semibold">0.0 Hrs</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-rose-50 text-rose-700">Absent</span></td>
                    </tr>
                    <tr className="hover:bg-slate-50/50 dark:hover:bg-slate-900/40">
                      <td className="p-3 font-bold text-slate-800 dark:text-slate-300">Rohan Deshmukh</td>
                      <td className="p-3 font-mono">2026-05-29</td>
                      <td className="p-3 font-mono font-medium text-emerald-600">12:47</td>
                      <td className="p-3 font-mono font-medium text-indigo-600">21:00</td>
                      <td className="p-3 font-mono font-semibold">8.2 Hrs</td>
                      <td className="p-3"><span className="px-2 py-0.5 rounded-full text-[9px] font-bold bg-amber-50 text-amber-600">Late Login</span></td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}

        {/* Sub-tab 4: LEAVE REVIEWS & POLICY VETTING */}
        {activeTab === 'leaves' && (
          <div className="space-y-6 animate-fade-in" id="admin-subtab-leaves">
            
            {/* Leaves Vetting List */}
            <div className="space-y-3 bg-white dark:bg-slate-900 p-5 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Active Claims Leave Vetting queue</h3>
                  <p className="text-[10px] text-slate-400">Applied leave configurations awaiting HR validation and signature.</p>
                </div>
                <span className="px-2 py-0.5 rounded bg-blue-100 text-blue-700 text-[10px] font-bold">
                  {leaveHistory.filter(l => l.status === 'Pending').length} Pending Review
                </span>
              </div>

              {leaveHistory.filter(l => l.status === 'Pending').length === 0 ? (
                <div className="p-6 text-center text-slate-400 italic">
                  All employee leave applications evaluated and verified properly.
                </div>
              ) : (
                <div className="divide-y divide-slate-100 dark:divide-slate-850 space-y-4">
                  {leaveHistory
                    .filter(l => l.status === 'Pending')
                    .map(item => (
                      <div key={item.id} className="pt-4 flex flex-col md:flex-row justify-between gap-4 first:pt-0">
                        <div className="space-y-1 text-left">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-sm font-bold text-slate-800 dark:text-slate-200">Kavitha Mohan</span>
                            <span className="text-[10px] text-slate-400 font-mono font-bold">({item.id})</span>
                            <span className="px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 text-[9px] font-bold">{item.leaveType}</span>
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-400 leading-normal font-sans italic">
                            &quot;{item.reason}&quot;
                          </p>
                          <div className="flex gap-4 text-[10px] text-slate-400 font-mono mt-1">
                            <span>From: <strong className="font-bold text-slate-600 dark:text-slate-350">{item.fromDate}</strong></span>
                            <span>To: <strong className="font-bold text-slate-600 dark:text-slate-350">{item.toDate}</strong></span>
                            <span>Requested Span: <strong className="font-bold text-blue-600">{item.days} Business Day(s)</strong></span>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <button
                            onClick={() => handleLeaveReview(item.id, 'Approved', 'Kavitha Mohan')}
                            className="px-3.5 py-1 text-[11px] font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded shadow cursor-pointer flex items-center gap-1"
                          >
                            <UserCheck size={12} /> Approve Claim
                          </button>
                          <button
                            onClick={() => handleLeaveReview(item.id, 'Rejected', 'Kavitha Mohan')}
                            className="px-3.5 py-1 text-[11px] font-bold bg-slate-100 hover:bg-slate-200 text-slate-600 rounded border cursor-pointer"
                          >
                            Decline
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>

            {/* Sandwich rules compliance tracker */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 space-y-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Sandwich Policy Compliance Rules</h4>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div className="border border-slate-100 dark:border-slate-800 p-4 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-300">Sandwich Weekend Rule</span>
                    <span className={`px-2 py-0.5 font-bold uppercase rounded text-[9px] ${sandwichRuleActive ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'}`}>
                      {sandwichRuleActive ? 'ENABLED Compliance' : 'DISABLED'}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400 leading-normal">
                    When active, consecutive holidays sandwiched between applied leave dates (e.g. Friday and following Monday applied) are counted as Loss of Pay/Leave deduction (inclusive of Saturday and Sunday).
                  </p>
                  <button
                    onClick={() => setSandwichRuleActive(!sandwichRuleActive)}
                    className="text-[10px] font-bold text-blue-600 hover:underline cursor-pointer"
                  >
                    Toggle sandwich compliance
                  </button>
                </div>

                <div className="border border-slate-100 dark:border-slate-800 p-4 rounded-xl space-y-2">
                  <span className="text-xs font-bold text-slate-800 dark:text-slate-300">Bi-Monthly Automatic Leave Accrual policy</span>
                  <div className="flex items-center gap-3">
                    <span className="text-xl font-mono text-indigo-600 font-extrabold">+1.5 CL</span>
                    <span className="text-[10px] text-slate-400">Credited on 1st of every calendar month.</span>
                  </div>
                  <p className="text-[10px] text-slate-400 leading-normal">
                    Current policy accrues general allowance balance levels automatically. Manual override is restricted to HR Director levels.
                  </p>
                </div>

              </div>
            </div>

          </div>
        )}

        {/* Sub-tab 5: SHIFT PLANNER & ROSTERS */}
        {activeTab === 'rosters' && (
          <div className="space-y-6 animate-fade-in" id="admin-subtab-rosters">
            
            {/* Shift Roster configuration Desk */}
            <div className="bg-white dark:bg-slate-900 p-5 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-sm">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Global Roster Compliance</h3>
                  <p className="text-[10px] text-slate-400">Specify operational rosters and view staff alignments.</p>
                </div>
                <div className="flex gap-2 text-xs font-mono font-bold text-emerald-600">
                  <span>General Support: 12:00 PM - 09:00 PM</span>
                </div>
              </div>

              {/* Roster Calendar List */}
              <div className="border rounded-xl p-4 bg-slate-50/50 dark:bg-slate-900/40 space-y-2">
                <span className="text-[10px] font-bold text-slate-400 uppercase">Interactive Shift Allocations by Division</span>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
                  <div className="bg-white dark:bg-slate-950 p-3 border rounded-lg space-y-1">
                    <span className="text-[11px] font-bold text-slate-700 dark:text-slate-350 block">Core Engineering</span>
                    <span className="text-[10px] text-slate-400 block">6 Members</span>
                    <span className="inline-block bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded text-[9px] uppercase mt-1">General Shift</span>
                  </div>

                  <div className="bg-white dark:bg-slate-950 p-3 border rounded-lg space-y-1">
                    <span className="text-[11px] font-bold text-slate-700 dark:text-slate-350 block">UI / UX Division</span>
                    <span className="text-[10px] text-slate-400 block">3 Members</span>
                    <span className="inline-block bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded text-[9px] uppercase mt-1">General Shift</span>
                  </div>

                  <div className="bg-white dark:bg-slate-950 p-3 border rounded-lg space-y-1">
                    <span className="text-[11px] font-bold text-slate-700 dark:text-slate-350 block">SysOps & Backup team</span>
                    <span className="text-[10px] text-slate-400 block">4 Members</span>
                    <span className="inline-block bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded text-[9px] uppercase mt-1">General Shift</span>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

        {/* Sub-tab 6: ANALYTICAL REPORTS ENGINE */}
        {activeTab === 'reports' && (
          <div className="space-y-6 animate-fade-in" id="admin-subtab-reports">
            
            <div className="bg-white dark:bg-slate-900 p-5 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-sm">
              <div>
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">HR Analytical Reports Engine</h3>
                <p className="text-[10px] text-slate-400">Generate, evaluate and export high fidelity compliance and analytics payloads.</p>
              </div>

              {reportSuccessMessage() && (
                <div className="p-3 bg-blue-50 border border-blue-100 rounded-lg text-blue-700 text-xs font-medium">
                  {reportSuccessMessage()}
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                
                {/* Select Report type */}
                <div className="space-y-1 text-left">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Report Payload Type</label>
                  <select
                    value={reportType}
                    onChange={(e) => setReportType(e.target.value)}
                    className="w-full px-2.5 py-1.5 border rounded-lg text-xs dark:bg-slate-950 border-slate-250 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="Monthly Attendance">Monthly Attendance Report</option>
                    <option value="Late Coming Analytics">Late Coming Report</option>
                    <option value="Overtime Summary">Overtime Report (Inbound hours)</option>
                    <option value="Leave Utilization Audit">Leave Utilization Audit</option>
                    <option value="Team Compliance">Team-wise Compliance Coverage</option>
                  </select>
                </div>

                {/* Scope Month limit */}
                <div className="space-y-1 text-left">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Scope Month Filter</label>
                  <select
                    value={reportMonth}
                    onChange={(e) => setReportMonth(e.target.value)}
                    className="w-full px-2.5 py-1.5 border rounded-lg text-xs dark:bg-slate-950 border-slate-250 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="May">May 2026 (Live)</option>
                    <option value="April">April 2026 (Historical)</option>
                    <option value="March">March 2026 (Historical)</option>
                  </select>
                </div>

              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={triggerDownloadReport}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Download size={14} /> Export Report Payload (CSV / Excel)
                </button>
              </div>

            </div>

          </div>
        )}

        {/* Sub-tab 7: GLOBAL OFFICE CONFIGURATIONS */}
        {activeTab === 'settings' && (
          <div className="space-y-6 animate-fade-in" id="admin-subtab-settings">
            
            <div className="bg-white dark:bg-slate-900 p-5 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-sm">
              <div>
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Corporate Working Configurations</h3>
                <p className="text-[10px] text-slate-400 font-medium">Verify standard operating office rules applied to attendance evaluation engines.</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                
                <div className="space-y-1 text-left">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Shift In Stamp (Grace Target)</label>
                  <input
                    type="time"
                    value={officeTimingIn}
                    onChange={(e) => setOfficeTimingIn(e.target.value)}
                    className="w-full px-2.5 py-1.5 border rounded-lg text-xs dark:bg-slate-950 border-slate-250 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                  />
                </div>

                <div className="space-y-1 text-left">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Shift Out Stamp</label>
                  <input
                    type="time"
                    value={officeTimingOut}
                    onChange={(e) => setOfficeTimingOut(e.target.value)}
                    className="w-full px-2.5 py-1.5 border rounded-lg text-xs dark:bg-slate-950 border-slate-250 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500 font-mono"
                  />
                </div>

                <div className="space-y-1 text-left">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Biometric Grace limits (Minutes)</label>
                  <input
                    type="number"
                    value={gracePeriod}
                    onChange={(e) => setGracePeriod(Number(e.target.value))}
                    className="w-full px-2.5 py-1.5 border rounded-lg text-xs dark:bg-slate-950 border-slate-250 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-1 text-left">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Weekend Compliance Model</label>
                  <input
                    type="text"
                    value={weekendPolicy}
                    onChange={(e) => setWeekendPolicy(e.target.value)}
                    className="w-full px-2.5 py-1.5 border rounded-lg text-xs dark:bg-slate-950 border-slate-250 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

              </div>

              <div className="flex justify-end pt-2">
                <button
                  onClick={() => showToast("Office configuration synced successfully.", 'success')}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-bold shadow transition-colors cursor-pointer"
                >
                  Apply Office Controls
                </button>
              </div>

            </div>

          </div>
        )}

      </div>

      {/* MODAL: Add / Edit Employee Onboard */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 animate-fade-in" id="employee-onboarding-modal">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-lg w-full p-6 border border-slate-200 dark:border-slate-800 space-y-4 max-h-[90vh] overflow-y-auto">
            
            <div className="flex items-center justify-between border-b pb-2.5">
              <h3 className="text-sm font-extrabold text-slate-850 dark:text-white">
                {editingEmployeeId ? 'Modify Staff Record' : 'Onboard New Corporate Employee'}
              </h3>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold bg-transparent border-0 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveEmployee} className="space-y-3.5 text-xs text-left">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Employee Name</label>
                  <input
                    type="text"
                    required
                    value={empName}
                    onChange={(e) => setEmpName(e.target.value)}
                    placeholder="e.g. Shalini Sharma"
                    className="w-full pl-3 pr-4 py-2 bg-slate-50 dark:bg-slate-955 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Corporate Email</label>
                  <input
                    type="email"
                    required
                    value={empEmail}
                    onChange={(e) => setEmpEmail(e.target.value)}
                    placeholder="e.g. shalini@company.com"
                    className="w-full pl-3 pr-4 py-2 bg-slate-50 dark:bg-slate-955 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Designation / Role Title</label>
                  <input
                    type="text"
                    required
                    value={empDesg}
                    onChange={(e) => setEmpDesg(e.target.value)}
                    placeholder="e.g. Senior Frontend Engineer"
                    className="w-full pl-3 pr-4 py-2 bg-slate-50 dark:bg-slate-955 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Department</label>
                  <select
                    value={empDept}
                    onChange={(e) => setEmpDept(e.target.value)}
                    className="w-full pl-3 pr-4 py-2 bg-slate-50 dark:bg-slate-955 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="Software Engineering">Software Engineering</option>
                    <option value="Design & Product">Design & Product</option>
                    <option value="Quality Assurance">Quality Assurance</option>
                    <option value="Cloud Operations">Cloud Operations</option>
                    <option value="Human Resources">Human Resources</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Designated Shift Timing</label>
                  <select
                    value={empShift}
                    onChange={(e) => setEmpShift(e.target.value)}
                    className="w-full pl-3 pr-4 py-2 bg-slate-50 dark:bg-slate-955 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  >
                    <option value="General Shift (12:00 PM - 09:00 PM)">General Shift (12:00 PM - 09:00 PM)</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Reporting Executive / Manager</label>
                  <input
                    type="text"
                    value={empManager}
                    onChange={(e) => setEmpManager(e.target.value)}
                    className="w-full pl-3 pr-4 py-2 bg-slate-50 dark:bg-slate-955 border border-slate-200 dark:border-slate-800 rounded-lg focus:outline-none focus:ring-1 focus:ring-blue-500"
                  />
                </div>

              </div>

              {/* Automation switches (Only on a brand new Onboarding setup) */}
              {!editingEmployeeId && (
                <div className="border border-slate-100 dark:border-slate-800 p-3.5 rounded-xl space-y-2 bg-slate-50/50 dark:bg-slate-950/40">
                  <span className="text-[10px] font-bold uppercase text-slate-400 block tracking-wider mb-1">
                    Automated Onboarding pipeline triggers
                  </span>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-left">
                      <span className="font-bold text-slate-700 dark:text-slate-350 block">Provision IT mailbox</span>
                      <p className="text-[9px] text-slate-400 font-medium">Auto issues Outlook credentials and corporate directory log.</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={sendITEmail}
                      onChange={(e) => setSendITEmail(e.target.checked)}
                      className="rounded text-blue-600 focus:ring-blue-500"
                    />
                  </div>

                  <div className="flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-800">
                    <div className="text-left">
                      <span className="font-bold text-slate-700 dark:text-slate-350 block">Team Introduction Broadcaster</span>
                      <p className="text-[9px] text-slate-400 font-medium">Publishes automated introduction email and announcement trigger.</p>
                    </div>
                    <input
                      type="checkbox"
                      checked={sendTeamAnnouncement}
                      onChange={(e) => setSendTeamAnnouncement(e.target.checked)}
                      className="rounded text-blue-600 focus:ring-blue-500"
                    />
                  </div>

                </div>
              )}

              <div className="flex gap-2.5 pt-3 border-t">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="w-1/2 py-2 bg-slate-100 hover:bg-slate-201 text-slate-600 rounded-lg font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isProcessingOnboarding}
                  className="w-1/2 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold shadow transition-all cursor-pointer flex items-center justify-center gap-1.5 disabled:opacity-50"
                >
                  {isProcessingOnboarding ? 'Executing...' : (editingEmployeeId ? 'Save Changes' : 'Execute Onboarding')}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* MODAL: Overrule Biometrics Correction */}
      {showCorrectionModal && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center p-4 z-50 animate-fade-in" id="biometrics-correction-modal">
          <div className="bg-white dark:bg-slate-900 rounded-2xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 space-y-4">
            
            <div className="flex items-center justify-between border-b pb-2.5">
              <h3 className="text-sm font-extrabold text-slate-850 dark:text-white">Admin Biometric Logs Override</h3>
              <button
                onClick={() => setShowCorrectionModal(false)}
                className="text-slate-400 hover:text-slate-600 font-bold bg-transparent border-0 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {correctionSuccessMsg && (
              <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-lg text-emerald-800 text-[11px] font-semibold">
                {correctionSuccessMsg}
              </div>
            )}

            <form onSubmit={handleManualPunchSubmit} className="space-y-3.5 text-xs text-left">
              
              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase text-slate-400">Select Employee</label>
                <select
                  required
                  value={selectedEmployeeForCorrection}
                  onChange={(e) => setSelectedEmployeeForCorrection(e.target.value)}
                  className="w-full px-2.5 py-2 border rounded-lg text-xs dark:bg-slate-950 border-slate-250 dark:border-slate-800 focus:outline-none focus:ring-1 focus:ring-blue-500"
                >
                  <option value="">-- Select Crew Member --</option>
                  {employees.map(u => (
                    <option key={u.id} value={u.id}>{u.name} ({u.id})</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold uppercase text-slate-400">Punch Override Date</label>
                <input
                  type="date"
                  required
                  value={selectedDateForCorrection}
                  onChange={(e) => setSelectedDateForCorrection(e.target.value)}
                  className="w-full px-2.5 py-2 border rounded-lg text-xs dark:bg-slate-950 border-slate-200 dark:border-slate-800 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                
                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Override In Stamp</label>
                  <input
                    type="time"
                    required
                    value={manualClockIn}
                    onChange={(e) => setManualClockIn(e.target.value)}
                    className="w-full px-2.5 py-2 border rounded-lg text-xs dark:bg-slate-950 border-slate-200 dark:border-slate-800 focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-bold uppercase text-slate-400">Override Out Stamp</label>
                  <input
                    type="time"
                    required
                    value={manualClockOut}
                    onChange={(e) => setManualClockOut(e.target.value)}
                    className="w-full px-2.5 py-2 border rounded-lg text-xs dark:bg-slate-950 border-slate-200 dark:border-slate-800 focus:outline-none"
                  />
                </div>

              </div>

              <div className="flex gap-2.5 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCorrectionModal(false)}
                  className="w-1/2 py-2 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg font-bold transition-all cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="w-1/2 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold shadow transition-all cursor-pointer"
                >
                  Apply Override
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );

  // Quick reporting subtext generator
  function reportSuccessMessage() {
    return reportSuccessMsg;
  }
}
