/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Clock,
  Clock3,
  CalendarCheck2,
  PlaneTakeoff,
  UserCheck,
  Zap,
  Play,
  Square,
  FilePlus2,
  PenTool,
  TrendingUp,
  MapPin,
  Laptop,
  Gift,
  Sparkles,
  X,
  CalendarDays,
  Building
} from 'lucide-react';
import { Employee, AttendanceRecord, LeaveBalance, CompanyHoliday } from '../types';
import { HOLIDAYS_2026 } from '../data';

interface DashboardProps {
  user: Employee;
  attendanceData: AttendanceRecord[];
  leaveBalances: LeaveBalance;
  currentClockedState: {
    isClockedIn: boolean;
    clockInTime?: string;
    elapsedSeconds: number;
    wfh: boolean;
  };
  onClockIn: (wfh: boolean) => void;
  onClockOut: () => void;
  setActiveTab: (tab: string) => void;
  isDark: boolean;
}

export default function Dashboard({
  user,
  attendanceData,
  leaveBalances,
  currentClockedState,
  onClockIn,
  onClockOut,
  setActiveTab,
  isDark
}: DashboardProps) {
  const [showAllHolidays, setShowAllHolidays] = React.useState(false);
  const [selectedHoliday, setSelectedHoliday] = React.useState<CompanyHoliday | null>(null);
  
  // Anchor date: Company current timeline May 30, 2026
  const anchorDateStr = "2026-05-30";
  const upcomingHolidays = HOLIDAYS_2026.filter(h => h.date >= anchorDateStr);
  const passedHolidays = HOLIDAYS_2026.filter(h => h.date < anchorDateStr);

  // Live hours calculations
  const totalSeconds = currentClockedState.elapsedSeconds;
  const hours = Math.floor(totalSeconds / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);

  const formatElapsedTime = () => {
    return `${hours.toString().padStart(2, '0')}h ${minutes.toString().padStart(2, '0')}m`;
  };

  const getRemainingHours = () => {
    const minRequired = 8 * 3600; // 8 hours in seconds
    if (!currentClockedState.isClockedIn) {
      return "08h 00m";
    }
    if (totalSeconds >= minRequired) {
      return "Completed! 🎉";
    }
    const remSeconds = minRequired - totalSeconds;
    const remHours = Math.floor(remSeconds / 3600);
    const remMinutes = Math.floor((remSeconds % 3600) / 60);
    return `${remHours.toString().padStart(2, '0')}h ${remMinutes.toString().padStart(2, '0')}m`;
  };

  // Get today's attendance status
  const getTodayStatus = () => {
    if (currentClockedState.isClockedIn) {
      return currentClockedState.wfh ? 'Present (WFH)' : 'Present (Office)';
    }
    // Check if recorded in attendanceData
    const todayStr = new Date().toISOString().split('T')[0];
    const todayRecord = attendanceData.find(r => r.date === todayStr);
    if (todayRecord) {
      return todayRecord.status;
    }
    return 'Not Clocked In';
  };

  // Monthly statistics
  const presentCount = attendanceData.filter(d => d.status === 'Present').length;
  const wfhCount = attendanceData.filter(d => d.status === 'WFH').length;
  const lateCount = attendanceData.filter(d => d.status === 'Late').length;
  const halfCount = attendanceData.filter(d => d.status === 'Half Day').length;
  const leaveCount = attendanceData.filter(d => d.status === 'On Leave').length;
  const totalWorkdays = presentCount + wfhCount + lateCount + halfCount + leaveCount;
  
  const totalLeaveBalance = leaveBalances.casualLeave;

  // Tiny calendar logic for May 2026
  const daysInMay = 31;
  const startOffset = 5; // May 1st 2026 was a Friday (5th day of the week, 0-indexed: Mon is 0, Fri is 4)
  // Let's use calendar grid helper
  const renderMiniCalendar = () => {
    const days = [];
    // Blank days
    for (let i = 0; i < 5; i++) {
      days.push(<div key={`empty-${i}`} className="h-7 w-7" />);
    }

    // Days in Month
    for (let day = 1; day <= 31; day++) {
      const dateStr = `2026-05-${day.toString().padStart(2, '0')}`;
      const record = attendanceData.find(r => r.date === dateStr);
      let dayColor = 'bg-slate-100 dark:bg-slate-800 text-slate-500';
      let titleStr = `May ${day}, 2026: No record`;

      // Determine day status
      const dateObj = new Date(dateStr);
      const isWeekend = dateObj.getDay() === 0 || dateObj.getDay() === 6;

      if (isWeekend) {
        dayColor = 'bg-slate-150 dark:bg-slate-900/60 text-slate-400';
        titleStr = `May ${day}, 2026: Weekend`;
      }

      if (record) {
        if (record.status === 'Present') {
          dayColor = 'bg-emerald-500 text-white font-medium';
          titleStr = `May ${day}: Present (Office)`;
        } else if (record.status === 'WFH') {
          dayColor = 'bg-violet-500 text-white font-medium';
          titleStr = `May ${day}: Present (WFH)`;
        } else if (record.status === 'Late') {
          dayColor = 'bg-amber-500 text-white font-medium';
          titleStr = `May ${day}: Present (Late Inbound)`;
        } else if (record.status === 'Half Day') {
          dayColor = 'bg-orange-400 text-white font-medium';
          titleStr = `May ${day}: Half-Day Work`;
        } else if (record.status === 'On Leave') {
          dayColor = 'bg-blue-500 text-white font-medium';
          titleStr = `May ${day}: On Approved Leave`;
        }
      }

      days.push(
        <div
          key={day}
          className={`h-7 w-7 rounded-md flex items-center justify-center text-[10px] cursor-pointer hover:opacity-85 shadow-sm transition-opacity relative ${dayColor}`}
          title={titleStr}
        >
          {day}
        </div>
      );
    }
    return days;
  };

  const recentHistory = attendanceData.slice(0, 5);

  return (
    <div className="space-y-6" id="dashboard-tab">
      
      {/* Upper Welcoming Banner */}
      <div className={`p-6 rounded-2xl border flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-colors ${
        isDark ? 'bg-gradient-to-r from-slate-900 to-slate-800 border-slate-800' : 'bg-gradient-to-r from-blue-50 to-slate-50 border-slate-200'
      }`}>
        <div className="space-y-1">
          <h2 className="text-xl md:text-2xl font-bold tracking-tight">
            Welcome back, {user.name}! 🌟
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            {user.role}  {user.department} Team
          </p>
        </div>
        
        {/* Simple visual metrics */}
        <div className="flex flex-wrap gap-4 text-xs font-mono font-medium">
          <div className="px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400">
            Shift: General 12:00 PM - 9:00 PM
          </div>
          <div className="px-3 py-1.5 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-600 dark:text-indigo-400">
            Role: Tech Lead
          </div>
        </div>
      </div>

      {/* Top HR KPI Dashboard Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        
        <div className={`p-4 rounded-xl border flex flex-col justify-between shadow-sm ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Today Attendance</span>
            <UserCheck size={18} className="text-blue-500" />
          </div>
          <div className="mt-2.5">
            <span className="text-sm font-bold block truncate">{getTodayStatus()}</span>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Biometric / Web Checkin</span>
          </div>
        </div>

        <div className={`p-4 rounded-xl border flex flex-col justify-between shadow-sm ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Working Hours</span>
            <Clock size={18} className="text-emerald-500" />
          </div>
          <div className="mt-2.5">
            <span className="text-2xl font-bold block font-mono">
              {currentClockedState.isClockedIn ? formatElapsedTime() : '00h 00m'}
            </span>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Active tracking session</span>
          </div>
        </div>

        <div className={`p-4 rounded-xl border flex flex-col justify-between shadow-sm ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Remaining (to 8h)</span>
            <Clock3 size={18} className="text-amber-500" />
          </div>
          <div className="mt-2.5 font-mono">
            <span className="text-2xl font-bold block">{getRemainingHours()}</span>
            <span className="text-[10px] text-slate-400 mt-0.5 block">Standard minimum day</span>
          </div>
        </div>

        <div className={`p-4 rounded-xl border flex flex-col justify-between shadow-sm ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Leave Balance (CL)</span>
            <PlaneTakeoff size={18} className="text-violet-500" />
          </div>
          <div className="mt-2.5">
            <span className="text-2xl font-bold block">{totalLeaveBalance} Days</span>
            <span className="text-[10px] text-slate-400 mt-0.5 block">CL: {leaveBalances.casualLeave} | LOP: {leaveBalances.lossOfPay} Days</span>
          </div>
        </div>

        <div className={`p-4 rounded-xl border flex flex-col justify-between shadow-sm ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Shift Timing</span>
            <MapPin size={18} className="text-indigo-500" />
          </div>
          <div className="mt-2.5">
            <span className="text-xs font-bold block">12:00 PM - 09:00 PM</span>
            <span className="text-[10px] text-slate-400 mt-0.5 block">General Shift (Sunday Off)</span>
          </div>
        </div>

      </div>

      {/* Main Grid: Left Widgets & Action Triggers, Right Attendance Calendar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left columns (span 2) */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Quick Action Controllers */}
          <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
            <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-4">Quick Operations</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              
              {!currentClockedState.isClockedIn ? (
                <>
                  <button
                    onClick={() => onClockIn(false)}
                    className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-medium shadow-md transition-all cursor-pointer hover:shadow-lg hover:-translate-y-0.5 h-28"
                    id="btn-clockin-office"
                  >
                    <Play size={20} />
                    <span className="text-xs">Clock In (Office)</span>
                  </button>
                  <button
                    onClick={() => onClockIn(true)}
                    className="flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-violet-600 hover:bg-violet-700 text-white font-medium shadow-md transition-all cursor-pointer hover:shadow-lg hover:-translate-y-0.5 h-28"
                    id="btn-clockin-wfh"
                  >
                    <Laptop size={20} />
                    <span className="text-xs">Clock In (WFH)</span>
                  </button>
                </>
              ) : (
                <button
                  onClick={onClockOut}
                  className="col-span-2 flex flex-col items-center justify-center gap-2 p-4 rounded-xl bg-rose-600 hover:bg-rose-700 text-white font-medium shadow-md transition-all cursor-pointer hover:shadow-lg hover:-translate-y-0.5 h-28"
                  id="btn-clockout"
                >
                  <Square size={20} />
                  <span className="text-xs">Clock Out Session</span>
                </button>
              )}

              <button
                onClick={() => setActiveTab('leaves')}
                className={`flex flex-col items-center justify-center gap-2 p-4 rounded-xl border font-medium shadow-sm transition-all cursor-pointer hover:-translate-y-0.5 h-28 ${
                  isDark ? 'bg-slate-750 border-slate-700 hover:bg-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
                id="btn-quick-leave"
              >
                <FilePlus2 size={20} className="text-emerald-500" />
                <span className="text-xs">Apply Leave</span>
              </button>

              <button
                onClick={() => setActiveTab('regularization')}
                className={`flex flex-col items-center justify-center gap-2 p-4 rounded-xl border font-medium shadow-sm transition-all cursor-pointer hover:-translate-y-0.5 h-28 ${
                  isDark ? 'bg-slate-750 border-slate-700 hover:bg-slate-700 text-slate-100' : 'bg-slate-50 border-slate-200 hover:bg-slate-100 text-slate-700'
                }`}
                id="btn-quick-regularize"
              >
                <PenTool size={20} className="text-amber-500" />
                <span className="text-xs">Regularization</span>
              </button>

            </div>
          </div>

          {/* Monthly Attendance Summary Metrics */}
          <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider mb-4">Monthly attendance Summary</h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              <div className="p-3 bg-slate-50 dark:bg-slate-900/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                <span className="text-2xl font-bold text-emerald-500">{presentCount}</span>
                <span className="text-[10px] text-slate-400 block mt-1 font-semibold uppercase">Present</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-900/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                <span className="text-2xl font-bold text-violet-500">{wfhCount}</span>
                <span className="text-[10px] text-slate-400 block mt-1 font-semibold uppercase">WFH</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-900/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                <span className="text-2xl font-bold text-amber-500">{lateCount}</span>
                <span className="text-[10px] text-slate-400 block mt-1 font-semibold uppercase">Late</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-900/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                <span className="text-2xl font-bold text-orange-400">{halfCount}</span>
                <span className="text-[10px] text-slate-400 block mt-1 font-semibold uppercase">Half Day</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-900/40 rounded-xl border border-dashed border-slate-200 dark:border-slate-800 text-center">
                <span className="text-2xl font-bold text-blue-500">{leaveCount}</span>
                <span className="text-[10px] text-slate-400 block mt-1 font-semibold uppercase">Leaves</span>
              </div>
            </div>
          </div>

          {/* Recent Attendance Activity Feed */}
          <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Recent Activity Feed</h3>
              <button
                onClick={() => setActiveTab('attendance')}
                className="text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline"
              >
                View Tracker Table
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 uppercase tracking-wider">
                    <th className="pb-2 font-medium">Date</th>
                    <th className="pb-2 font-medium">Shift</th>
                    <th className="pb-2 font-medium">Clock In / Out</th>
                    <th className="pb-2 font-medium">Total Duration</th>
                    <th className="pb-2 font-medium text-right">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-150 dark:divide-slate-800">
                  {recentHistory.map((rec) => (
                    <tr key={rec.id} className="hover:bg-slate-50/55 dark:hover:bg-slate-800/30">
                      <td className="py-2.5 font-medium">{new Date(rec.date).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}</td>
                      <td className="py-2.5 text-slate-500">{rec.shift.split('(')[0]}</td>
                      <td className="py-2.5 font-mono">
                        {rec.clockIn ? (
                          <span>{rec.clockIn} - {rec.clockOut || '--:--'}</span>
                        ) : (
                          <span className="text-slate-400">-- : --</span>
                        )}
                      </td>
                      <td className="py-2.5 font-mono">
                        {rec.totalHours ? `${rec.totalHours.toFixed(2)} Hrs` : (rec.status === 'On Leave' ? 'Leave Action' : 'Absent')}
                      </td>
                      <td className="py-2.5 text-right">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold leading-4 ${
                          rec.status === 'Present' ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400' :
                          rec.status === 'WFH' ? 'bg-violet-50 dark:bg-violet-950/30 text-violet-600 dark:text-violet-400' :
                          rec.status === 'Late' ? 'bg-amber-50 dark:bg-amber-950/30 text-amber-600' :
                          rec.status === 'Half Day' ? 'bg-orange-50 dark:bg-orange-950/30 text-orange-600' :
                          'bg-blue-50 dark:bg-blue-950/30 text-blue-600 dark:text-blue-400'
                        }`}>
                          {rec.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right column Attendance Calendar Widget */}
        <div className="space-y-6">
               <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Attendance Calendar</h3>
              <span className="text-xs font-bold text-blue-600 dark:text-blue-400">May 2026</span>
            </div>

            {/* Calendar grid headers */}
            <div className="grid grid-cols-7 gap-1 text-center font-semibold text-[10px] text-slate-400 uppercase mb-2">
              <div>Mon</div>
              <div>Tue</div>
              <div>Wed</div>
              <div>Thu</div>
              <div>Fri</div>
              <div className="text-rose-400">Sat</div>
              <div className="text-rose-400">Sun</div>
            </div>

            {/* Render actual days */}
            <div className="grid grid-cols-7 gap-1.5 justify-items-center">
              {renderMiniCalendar()}
            </div>

            {/* Simple Legend indicator for the Calendar */}
            <div className="mt-5 border-t border-slate-200 dark:border-slate-800 pt-4 space-y-2 text-[10px]">
              <p className="font-semibold text-slate-400 uppercase mb-1.5">Color Key Legend</p>
              <div className="grid grid-cols-2 gap-2 text-slate-500 dark:text-slate-400">
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 flex-shrink-0" />
                  <span>Present (Office)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-violet-500 flex-shrink-0" />
                  <span>Present (WFH)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-amber-500 flex-shrink-0" />
                  <span>Late Arrival</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-orange-400 flex-shrink-0" />
                  <span>Half Day Shift</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-blue-500 flex-shrink-0" />
                  <span>Approved Leave</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-slate-200 dark:bg-slate-800 flex-shrink-0" />
                  <span>Weekend / Off</span>
                </div>
              </div>
            </div>

          </div>

          {/* Shift info snippet */}
          <div className={`p-5 rounded-xl border border-dashed ${
            isDark ? 'bg-slate-900/50 border-slate-800' : 'bg-slate-50/50 border-slate-200'
          }`}>
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2.5">Weekly Shift Schedule</h4>
            <div className="space-y-2">
              <div className="flex justify-between text-xs">
                <span className="text-slate-500">Scheduled Shifts</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">5 Days a Week</span>
              </div>
              <div className="flex justify-between text-xs">
                <span className="text-slate-500">Alternating Saturdays</span>
                <span className="font-semibold text-blue-600 dark:text-blue-400">Support roster assigned</span>
              </div>
              <div className="flex justify-between text-xs font-sans">
                <span className="text-slate-500">Weekend policy</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">Sunday mandatory Rest</span>
              </div>
            </div>
          </div>

          {/* Company Holidays Widget */}
          <div className={`p-5 rounded-xl border shadow-sm ${
            isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
          }`} id="company-holidays-widget">
            <div className="flex items-center justify-between mb-3 border-b border-slate-150 dark:border-slate-800 pb-2.5">
              <div className="flex items-center gap-2">
                <Gift className="text-pink-500" size={15} />
                <h3 className="text-xs font-extrabold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Company Holidays</h3>
              </div>
              <button
                onClick={() => setShowAllHolidays(!showAllHolidays)}
                className="text-[10px] font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer bg-slate-50 dark:bg-slate-800/80 px-2.5 py-1 rounded-lg border border-slate-150 dark:border-slate-700"
              >
                {showAllHolidays ? "Show Upcoming" : "Show All"}
              </button>
            </div>

            <p className="text-[10px] text-slate-400 mb-3 font-medium">
              {showAllHolidays 
                ? "All public, national and company corporate holidays for 2026." 
                : `${upcomingHolidays.length} upcoming holidays remaining in 2026.`
              }
            </p>

            <div className="space-y-2 max-h-72 overflow-y-auto pr-0.5 scrollbar-thin scrollbar-thumb-slate-300 dark:scrollbar-thumb-slate-700">
              {(showAllHolidays ? HOLIDAYS_2026 : upcomingHolidays).map((h) => {
                const isPassed = h.date < anchorDateStr;
                const isNext = !isPassed && h.id === upcomingHolidays[0]?.id;
                
                const typeColors = 
                  h.type === 'National' ? 'bg-orange-50 dark:bg-orange-950/20 text-orange-600 dark:text-orange-400 border border-orange-100 dark:border-orange-900/30' :
                  h.type === 'Public' ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30' :
                  h.type === 'Company' ? 'bg-violet-50 dark:bg-violet-950/20 text-violet-600 dark:text-violet-400 border border-violet-100 dark:border-violet-900/30' :
                  'bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700/50';

                const holidayDateObj = new Date(h.date);
                const monthName = holidayDateObj.toLocaleDateString('en-US', { month: 'short' });
                const dayNum = holidayDateObj.toLocaleDateString('en-US', { day: 'numeric' });

                return (
                  <div 
                    key={h.id} 
                    onClick={() => setSelectedHoliday(h)}
                    className={`p-2.5 rounded-xl border transition-all flex items-center justify-between gap-3 cursor-pointer hover:shadow-sm hover:translate-x-0.5 active:scale-[0.99] ${
                      isPassed ? 'opacity-55 bg-slate-50/40 dark:bg-slate-900/20 border-slate-100 dark:border-slate-800/40 hover:opacity-90 hover:border-slate-250 dark:hover:border-slate-700' :
                      isNext ? 'bg-blue-50/45 dark:bg-blue-950/15 border-blue-200 dark:border-blue-900 shadow-sm hover:bg-blue-50/70 dark:hover:bg-blue-950/25' :
                      'bg-slate-50/50 dark:bg-slate-900/40 border-slate-150 dark:border-slate-850 hover:bg-slate-50 dark:hover:bg-slate-900/60 hover:border-blue-300 dark:hover:border-blue-800'
                    }`}
                    title="Click to view holiday significance & corporate policy"
                  >
                    <div className="flex gap-2.5 items-center min-w-0">
                      <div className={`h-10 w-10 flex flex-col items-center justify-center rounded-lg flex-shrink-0 ${
                        isPassed ? 'bg-slate-200/50 dark:bg-slate-800 text-slate-400' :
                        isNext ? 'bg-blue-600 text-white font-medium' :
                        'bg-slate-150 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}>
                        <span className="text-[9px] uppercase font-bold tracking-tight leading-none">
                          {monthName}
                        </span>
                        <span className="text-xs font-bold leading-none mt-1">
                          {dayNum}
                        </span>
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <span className={`text-[11px] font-bold truncate ${
                            isPassed ? 'text-slate-400 line-through dark:text-slate-500' : 'text-slate-750'
                          }`}>
                            {h.name}
                          </span>
                          {isNext && (
                            <span className="inline-flex items-center gap-0.5 px-1 py-0.5 bg-rose-500 text-white font-extrabold text-[8px] uppercase tracking-wider rounded">
                              <Sparkles size={8} /> Next
                            </span>
                          )}
                        </div>
                        <span className="text-[9px] text-slate-400 block font-mono mt-0.5">
                          {h.dayOfWeek}
                        </span>
                      </div>
                    </div>

                    <div className="flex flex-col items-end flex-shrink-0 gap-1">
                      <span className={`px-1.5 py-0.5 rounded text-[8px] font-extrabold uppercase tracking-wide border ${typeColors}`}>
                        {h.type}
                      </span>
                      {isPassed && (
                        <span className="text-[9px] text-slate-400 font-medium italic">
                          Passed
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

      </div>

      {/* Holiday Details Modal popup */}
      {selectedHoliday && (() => {
        const isPassed = selectedHoliday.date < anchorDateStr;
        const holidayDateObj = new Date(selectedHoliday.date);
        const formattedDate = holidayDateObj.toLocaleDateString('en-US', {
          weekday: 'long',
          month: 'long',
          day: 'numeric',
          year: 'numeric'
        });

        const typeColors = 
          selectedHoliday.type === 'National' ? 'bg-orange-50 dark:bg-orange-950/25 text-orange-600 dark:text-orange-400 border border-orange-100 dark:border-orange-900/30' :
          selectedHoliday.type === 'Public' ? 'bg-emerald-50 dark:bg-emerald-950/25 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/30' :
          selectedHoliday.type === 'Company' ? 'bg-violet-50 dark:bg-violet-950/25 text-violet-600 dark:text-violet-400 border border-violet-100 dark:border-violet-900/30' :
          'bg-slate-100 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700/50';

        return (
          <div 
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity"
            id="holiday-details-modal-overlay"
            onClick={() => setSelectedHoliday(null)}
          >
            <div 
              className={`w-full max-w-md p-6 rounded-2xl border shadow-xl flex flex-col gap-5 transition-all transform scale-100 ${
                isDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-800'
              }`}
              id="holiday-details-modal-box"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded text-[10px] font-extrabold uppercase tracking-widest border mb-2 ${typeColors}`}>
                    {selectedHoliday.type} Holiday
                  </span>
                  <h2 className="text-sm font-extrabold tracking-tight">
                    {selectedHoliday.name}
                  </h2>
                </div>
                <button 
                  onClick={() => setSelectedHoliday(null)}
                  className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-slate-600 transition-colors cursor-pointer"
                  id="holiday-details-close-btn"
                  title="Close Dialog"
                >
                  <X size={18} />
                </button>
              </div>

              <div className="space-y-4 font-sans text-xs">
                
                {/* Date & Day Segment */}
                <div className={`p-4 rounded-xl flex items-center gap-3 border ${
                  isDark ? 'bg-slate-850 border-slate-800' : 'bg-slate-50 border-slate-150'
                }`}>
                  <CalendarDays className="text-blue-500 stroke-[2]" size={20} />
                  <div>
                    <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">
                      Schedule Date
                    </span>
                    <span className="font-bold text-slate-700 dark:text-slate-200 mt-0.5 block">
                      {formattedDate}
                    </span>
                    {isPassed ? (
                      <span className="text-[9px] text-slate-400 block italic mt-0.5">
                        This holiday has passed.
                      </span>
                    ) : (
                      <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold block mt-0.5">
                        Upcoming Holiday ({selectedHoliday.dayOfWeek})
                      </span>
                    )}
                  </div>
                </div>

                {/* Significance Segment */}
                <div className="space-y-1">
                  <span className="text-[9px] font-extrabold uppercase tracking-wider text-slate-400 block">
                    Significance & Background
                  </span>
                  <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300 bg-slate-50/40 dark:bg-slate-900/20 p-3 rounded-lg border border-slate-100 dark:border-slate-850">
                    {selectedHoliday.description}
                  </p>
                </div>

                {/* Corporate Policy Segment */}
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-slate-400 uppercase tracking-wide">
                    <Building size={12} className="text-violet-500" />
                    <span className="text-[9px] font-extrabold tracking-wider">
                      Company Policy & Attendance
                    </span>
                  </div>
                  <p className="text-xs leading-relaxed text-slate-600 dark:text-slate-300 bg-slate-50/40 dark:bg-slate-900/20 p-3 rounded-lg border border-slate-100 dark:border-slate-850 font-medium">
                    {selectedHoliday.policy}
                  </p>
                </div>

              </div>

              <div className="flex justify-end gap-2.5 pt-3 border-t border-slate-150 dark:border-slate-800">
                <button
                  onClick={() => setSelectedHoliday(null)}
                  className="px-4 py-2 bg-slate-100 dark:bg-slate-800 hover:bg-slate-250 dark:hover:bg-slate-750 font-bold text-xs rounded-lg transition-all cursor-pointer text-slate-700 dark:text-slate-300"
                  id="holiday-details-ok-btn"
                >
                  Dismiss
                </button>
              </div>

            </div>
          </div>
        );
      })()}

    </div>
  );
}
