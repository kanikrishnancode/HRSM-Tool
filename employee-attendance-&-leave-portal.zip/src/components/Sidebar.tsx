/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  LayoutDashboard,
  CalendarCheck,
  CalendarDays,
  PlaneTakeoff,
  Clock,
  BarChart3,
  CalendarRange,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';
import { Employee } from '../types';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
  user: Employee;
  onLogout: () => void;
  isDark: boolean;
  viewMode: 'employee' | 'admin';
  setViewMode: (mode: 'employee' | 'admin') => void;
  mobileOpen: boolean;
  onCloseMobile: () => void;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  collapsed,
  setCollapsed,
  user,
  onLogout,
  isDark,
  viewMode,
  setViewMode,
  mobileOpen,
  onCloseMobile
}: SidebarProps) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'attendance', label: 'Attendance', icon: CalendarCheck },
    { id: 'roster', label: 'Shift Roster', icon: CalendarDays },
    { id: 'saturdays', label: 'Alternate Saturdays', icon: CalendarRange },
    { id: 'leaves', label: 'Leave Management', icon: PlaneTakeoff },
    { id: 'regularization', label: 'Regularization', icon: Clock },
    { id: 'reports', label: 'Reports & Analytics', icon: BarChart3 }
  ];

  return (
    <>
      {/* Mobile Backdrop Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-40 md:hidden animate-fade-in"
          onClick={onCloseMobile}
          id="sidebar-mobile-backdrop"
        />
      )}

      <div
        className={`h-screen flex flex-col justify-between border-r border-slate-850 transition-all duration-300 bg-slate-900 text-slate-300 fixed md:relative top-0 left-0 z-50 ${mobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'} ${collapsed ? 'w-20' : 'w-60'}`}
        id="app-sidebar"
      >
        <div>
          {/* Header containing Company Logo Branding */}
          <div className="p-[22px] flex items-center justify-between border-b border-slate-850">
            <div className="flex items-center gap-3 overflow-hidden">
              <div className="h-8 w-8 flex-shrink-0 rounded-lg bg-blue-500 flex items-center justify-center text-white font-bold text-base shadow-sm">
                HR
              </div>
              {!collapsed && (
                <span className="text-white font-bold text-xl tracking-tight">NexusLink</span>
              )}
            </div>
            <button
              onClick={() => setCollapsed(!collapsed)}
              className={`p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800/60 ${collapsed ? 'mx-auto' : ''}`}
              title={collapsed ? "Expand menu" : "Collapse menu"}
            >
              {collapsed ? <ChevronRight size={18} /> : <ChevronLeft size={18} />}
            </button>
          </div>

          {/* Portal Switcher Banner */}
          {!collapsed ? (
            <div className="mx-3 mt-4 p-1 bg-slate-850/40 rounded-xl border border-slate-800/80 flex gap-1 text-[10px] font-bold">
              <button
                onClick={() => {
                  setViewMode('employee');
                  setActiveTab('dashboard');
                  onCloseMobile();
                }}
                className={`flex-1 py-1.5 rounded-lg text-center cursor-pointer transition-colors ${
                  viewMode === 'employee' 
                    ? 'bg-blue-600 text-white' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-850/30'
                }`}
              >
                Employee Portal
              </button>
              <button
                onClick={() => {
                  setViewMode('admin');
                  setActiveTab('admin');
                  onCloseMobile();
                }}
                className={`flex-1 py-1.5 rounded-lg text-center cursor-pointer transition-colors ${
                  viewMode === 'admin' 
                    ? 'bg-blue-600 text-white' 
                    : 'text-slate-400 hover:text-white hover:bg-slate-850/30'
                }`}
                id="sidebar-btn-admin-portal"
              >
                Admin Portal
              </button>
            </div>
          ) : (
            <div className="flex justify-center my-3">
              <button
                onClick={() => {
                  const nextMode = viewMode === 'employee' ? 'admin' : 'employee';
                  setViewMode(nextMode);
                  setActiveTab(nextMode === 'employee' ? 'dashboard' : 'admin');
                  onCloseMobile();
                }}
                className="p-2 rounded-lg bg-blue-600 text-white shadow hover:bg-blue-700 transition-colors cursor-pointer text-xs font-bold"
                title={`Switch to ${viewMode === 'employee' ? 'Admin' : 'Employee'} Portal`}
              >
                {viewMode === 'employee' ? 'EMP' : 'ADM'}
              </button>
            </div>
          )}

          {/* User Mini Profile Panel on Sidebar top under logo, hidden if collapsed */}
          {!collapsed && (
            <div className="p-4 mx-3 my-4 rounded-xl flex items-center gap-3 bg-slate-850/30 border border-slate-800 text-slate-300">
              <div className="h-9 w-9 bg-slate-800 border border-slate-700 text-white rounded-lg flex items-center justify-center font-bold text-xs shadow-inner">
                {user.avatar || 'U'}
              </div>
              <div className="flex flex-col min-w-0">
                <span className="font-semibold text-xs text-white truncate">{user.name}</span>
                <span className="text-[10px] text-slate-500 truncate">{user.role}</span>
              </div>
            </div>
          )}

          {/* Navigation Items */}
          <nav className="px-3 space-y-1 mt-2">
            {viewMode === 'employee' ? (
              menuItems.map((item) => {
                const IconComponent = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      onCloseMobile();
                    }}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition-all duration-150 relative rounded-lg ${
                      isActive
                        ? 'bg-blue-600/20 text-blue-400 border-l-4 border-blue-500 pl-2 rounded-r-lg rounded-l-none'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
                    }`}
                    id={`nav-${item.id}`}
                  >
                    <IconComponent size={18} className={isActive ? 'text-blue-400' : ''} />
                    {!collapsed && <span className="truncate">{item.label}</span>}
                  </button>
                );
              })
            ) : (
              <button
                onClick={() => {
                  setActiveTab('admin');
                  onCloseMobile();
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium transition-all duration-150 relative rounded-lg bg-blue-600/20 text-blue-400 border-l-4 border-blue-500 pl-2 rounded-r-lg rounded-l-none`}
                id="nav-admin"
              >
                <ShieldAlert size={18} className="text-blue-400" />
                {!collapsed && <span>Admin Console</span>}
              </button>
            )}
          </nav>
        </div>

        {/* Footer containing Settings and Sign Out actions */}
        <div className="p-3 border-t border-slate-850">
          <button
            onClick={() => {
              setActiveTab('settings');
              onCloseMobile();
            }}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
              activeTab === 'settings'
                ? 'bg-blue-600/20 text-blue-400 border-l-4 border-blue-500 pl-2 rounded-r-lg rounded-l-none'
                : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
            }`}
            id="nav-settings"
          >
            <Settings size={18} />
            {!collapsed && <span>Settings</span>}
          </button>

          <button
            onClick={() => {
              onLogout();
              onCloseMobile();
            }}
            className="w-full mt-1 flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium text-rose-450 hover:bg-rose-950/20 hover:text-rose-400 transition-all duration-150"
            id="btn-logout"
          >
            <LogOut size={18} />
            {!collapsed && <span>Logout</span>}
          </button>
        </div>
      </div>
    </>
  );
}
