/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Settings, Shield, Bell, User, Cpu, CircleAlert } from 'lucide-react';
import { Employee } from '../types';

interface SettingsProps {
  user: Employee;
  isDark: boolean;
}

export default function SettingsComponent({ user, isDark }: SettingsProps) {
  const [emailAlerts, setEmailAlerts] = useState(true);
  const [weeklyDigest, setWeeklyDigest] = useState(true);
  const [autoClockIn, setAutoClockIn] = useState(false);

  return (
    <div className="space-y-6 animate-fade-in" id="settings-tab">
      
      {/* Title */}
      <div>
        <h2 className="text-xl md:text-2xl font-bold tracking-tight">System & Profile Preferences</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Manage your notification channels, security policies, and biometric profiles.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Profile Overview */}
        <div className={`p-6 rounded-xl border shadow-sm ${
          isDark ? 'bg-slate-800 border-slate-755' : 'bg-white border-slate-100'
        }`}>
          <h3 className="font-bold text-sm mb-4 border-b pb-3 dark:border-slate-700 flex items-center gap-2">
            <User className="text-blue-500" size={16} /> Demographic Details
          </h3>

          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="h-14 w-14 rounded-full bg-blue-100 dark:bg-blue-900/30 font-bold text-lg flex items-center justify-center text-blue-700">
                {user.avatar || 'U'}
              </div>
              <div>
                <span className="font-extrabold text-sm block">{user.name}</span>
                <span className="text-[11px] text-slate-400 block mt-0.5">{user.role}</span>
              </div>
            </div>

            <div className="space-y-2 border-t dark:border-slate-705 pt-4 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-400">Employee Identification</span>
                <span className="font-semibold">{user.id}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Assigned Department</span>
                <span className="font-semibold">{user.department}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Email Address</span>
                <span className="font-semibold text-blue-600 dark:text-blue-400">{user.email}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Configurations list */}
        <div className={`lg:col-span-2 p-6 rounded-xl border shadow-sm ${
          isDark ? 'bg-slate-800 border-slate-755' : 'bg-white border-slate-100'
        }`}>
          <h3 className="font-bold text-sm mb-4 border-b pb-3 dark:border-slate-700 flex items-center gap-2">
            <Bell className="text-blue-500" size={16} /> Notification Alerts settings
          </h3>

          <div className="space-y-4 text-xs">
            <div className="flex items-center justify-between p-3 bg-slate-50/50 dark:bg-slate-900/40 rounded-xl border border-slate-150 dark:border-slate-800">
              <div>
                <span className="font-bold block">Biometric Swipe reminder emails</span>
                <p className="text-[10px] text-slate-400">Receive email alerts if miss clocking in by 09:12 AM on working days.</p>
              </div>
              <input
                type="checkbox"
                checked={emailAlerts}
                onChange={() => setEmailAlerts(!emailAlerts)}
                className="rounded cursor-pointer h-4 w-4 text-blue-600"
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-50/50 dark:bg-slate-900/40 rounded-xl border border-slate-150 dark:border-slate-800">
              <div>
                <span className="font-bold block">Accrued Leave weekly summaries</span>
                <p className="text-[10px] text-slate-400">Obtain systematic reports summarizing dynamic leave requests and approvals.</p>
              </div>
              <input
                type="checkbox"
                checked={weeklyDigest}
                onChange={() => setWeeklyDigest(!weeklyDigest)}
                className="rounded cursor-pointer h-4 w-4 text-blue-600"
              />
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-50/50 dark:bg-slate-900/40 rounded-xl border border-slate-150 dark:border-slate-800">
              <div>
                <span className="font-bold block">IP-Based Automatic Web Login</span>
                <p className="text-[10px] text-slate-400">Automatically trigger clocked-in status upon logging in from official Corporate VLAN gates.</p>
              </div>
              <input
                type="checkbox"
                checked={autoClockIn}
                onChange={() => setAutoClockIn(!autoClockIn)}
                className="rounded cursor-pointer h-4 w-4 text-blue-600"
              />
            </div>
          </div>

          <div className="mt-6 flex gap-2.5 p-3.5 rounded-lg bg-blue-50/40 dark:bg-blue-950/20 text-[10px] text-slate-500">
            <Shield className="text-blue-600 flex-shrink-0" size={16} />
            <span>Biometric records cannot be falsified or adjusted except with authorized regularizations vetted by team directors.</span>
          </div>

        </div>

      </div>

    </div>
  );
}
