/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Clock,
  CirclePlay,
  CircleStop,
  SlidersHorizontal,
  Search,
  CheckCircle2,
  AlertTriangle,
  FileSpreadsheet,
  Workflow,
  Download
} from 'lucide-react';
import { AttendanceRecord } from '../types';

interface AttendanceProps {
  attendanceData: AttendanceRecord[];
  currentClockedState: {
    isClockedIn: boolean;
    clockInTime?: string;
    elapsedSeconds: number;
    wfh: boolean;
  };
  onClockIn: (wfh: boolean) => void;
  onClockOut: () => void;
  onInitiateRegularization: (date: string) => void;
  isDark: boolean;
}

export default function Attendance({
  attendanceData,
  currentClockedState,
  onClockIn,
  onClockOut,
  onInitiateRegularization,
  isDark
}: AttendanceProps) {
  // Filters state
  const [selectedMonth, setSelectedMonth] = useState('05'); // Default May
  const [selectedYear, setSelectedYear] = useState('2026');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Months/Years helper arrays
  const months = [
    { value: '01', label: 'January' },
    { value: '02', label: 'February' },
    { value: '03', label: 'March' },
    { value: '04', label: 'April' },
    { value: '05', label: 'May' },
    { value: '06', label: 'June' },
    { value: '07', label: 'July' },
    { value: '08', label: 'August' },
    { value: '09', label: 'September' },
    { value: '10', label: 'October' },
    { value: '11', label: 'November' },
    { value: '12', label: 'December' },
  ];

  const years = ['2025', '2026', '2027'];
  const statuses = ['All', 'Present', 'WFH', 'Late', 'Half Day', 'On Leave'];

  // Live timer calculations
  const totalSeconds = currentClockedState.elapsedSeconds;
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;

  const paddedTime = `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;

  // Filter records
  const filteredRecords = attendanceData.filter((record) => {
    // Check Month/Year
    const [year, month] = record.date.split('-');
    if (year !== selectedYear) return false;
    if (month !== selectedMonth) return false;

    // Check Status
    if (selectedStatus !== 'All' && record.status !== selectedStatus) return false;

    // Check Search (date or status or regularization text lookup)
    if (searchQuery) {
      const formattedDate = new Date(record.date).toLocaleDateString('en-US', {
        weekday: 'long',
        month: 'short',
        day: 'numeric'
      }).toLowerCase();
      const statusLower = record.status.toLowerCase();
      const queryLower = searchQuery.toLowerCase();
      return formattedDate.includes(queryLower) || statusLower.includes(queryLower);
    }

    return true;
  });

  const handleDownloadCSV = () => {
    const headers = ["Date", "Shift Type", "Clock In", "Clock Out", "Total Hours", "Status", "Regularization Status"];
    const rows = filteredRecords.map(r => {
      const formattedDate = new Date(r.date).toLocaleDateString('en-US', {
        weekday: 'short',
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      }).replace(/,/g, '');
      const shiftClean = r.shift.split('(')[0].trim();
      const clockIn = r.clockIn || "Missed Swipe";
      const clockOut = r.clockOut || (r.status !== 'On Leave' ? "Missed Swipe" : "--");
      const totalHours = r.totalHours ? r.totalHours.toFixed(2) : "0.00";
      const status = r.status || "";
      const regularization = r.regularizationStatus || "None";
      
      return [
        `"${formattedDate}"`,
        `"${shiftClean}"`,
        `"${clockIn}"`,
        `"${clockOut}"`,
        `"${totalHours}"`,
        `"${status}"`,
        `"${regularization}"`
      ].join(",");
    });
    
    const csvContent = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Attendance_Report_${selectedMonth}_${selectedYear}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="attendance-tracker-tab">
      
      {/* Attendance Module Header Title */}
      <div>
        <h2 className="text-xl md:text-2xl font-bold tracking-tight">Biometric & Attendance Monitoring</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Track your clock details, check histories, and apply for timesheet corrections.</p>
      </div>

      <div className="grid grid-cols-1 gap-6">
        
        {/* Informational Guidance Roster Snippet */}
        <div className={`p-6 rounded-xl border flex flex-col justify-between shadow-md ${
          isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'
        }`}>
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Attendance Insights & Standards</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex gap-3 p-3.5 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
                <CheckCircle2 className="text-emerald-500 flex-shrink-0 mt-0.5" size={16} />
                <div className="text-xs">
                  <p className="font-bold text-emerald-800 dark:text-emerald-400">Regular Working Policy</p>
                  <p className="text-[10px] text-slate-500 mt-1">Minimum hours expected for a full day is 8 hours. 4 hours constitutes half days.</p>
                </div>
              </div>
              
              <div className="flex gap-3 p-3.5 rounded-xl bg-amber-500/5 border border-amber-500/10">
                <AlertTriangle className="text-amber-500 flex-shrink-0 mt-0.5" size={16} />
                <div className="text-xs">
                  <p className="font-bold text-amber-800 dark:text-emerald-400">Grace Hour Allowances</p>
                  <p className="text-[10px] text-slate-500 mt-1">Late mark applies to check-ins beyond 09:15 AM. 3 occurrences per month are excused.</p>
                </div>
              </div>
            </div>

            <div className="pt-2 text-xs text-slate-500 space-y-2">
              <p className="font-semibold text-slate-700 dark:text-slate-300">Quick guidelines on missed swipes:</p>
              <ul className="list-disc list-inside space-y-1 text-[10px]">
                <li>Swipe details synchronize automatically from cloud-site hubs thrice a day.</li>
                <li>Incomplete logs must be corrected through the Attendance Regularization module within 7 working days.</li>
              </ul>
            </div>
          </div>

          <div className="flex justify-end pt-4">
            <button className="flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline">
              <FileSpreadsheet size={14} /> Download PDF Monthly Payslip Report
            </button>
          </div>
        </div>

      </div>

      {/* Main Filter panel & Attendance Log Table */}
      <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
        
        {/* Table Filter controls */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 border-b border-slate-150 dark:border-slate-800 pb-4 mb-4">
          <div className="flex items-center gap-2">
            <SlidersHorizontal size={16} className="text-slate-400" />
            <span className="font-bold text-sm">Attendance Logs Filter</span>
          </div>

          {/* Controls grid */}
          <div className="flex flex-wrap items-center gap-3">
            
            {/* Search Input */}
            <div className="relative w-full sm:w-auto">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
              <input
                type="text"
                placeholder="Search date, status..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 rounded-lg border text-xs w-full sm:w-44 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
              />
            </div>

            {/* Month select */}
            <select
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="px-2.5 py-1.5 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
            >
              {months.map(m => (
                <option key={m.value} value={m.value}>{m.label}</option>
              ))}
            </select>

            {/* Year select */}
            <select
              value={selectedYear}
              onChange={(e) => setSelectedYear(e.target.value)}
              className="px-2.5 py-1.5 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
            >
              {years.map(y => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>

            {/* Status select */}
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="px-2.5 py-1.5 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
            >
              {statuses.map(st => (
                <option key={st} value={st}>{st}</option>
              ))}
            </select>

            {/* Export Report CSV button */}
            <button
              onClick={handleDownloadCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs transition-colors shadow-sm cursor-pointer ml-auto sm:ml-0"
              title="Export current filtered attendance log to CSV file"
              id="btn-export-attendance-csv"
            >
              <Download size={14} /> Export Report
            </button>

          </div>
        </div>

        {/* Table implementation */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-150 dark:border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                <th className="pb-3 text-slate-500">Date Log</th>
                <th className="pb-3 text-slate-500">Shift Type</th>
                <th className="pb-3 text-slate-500">Clock In</th>
                <th className="pb-3 text-slate-500">Clock Out</th>
                <th className="pb-3 text-slate-500">Total Hours</th>
                <th className="pb-3 text-slate-500">Marked Status</th>
                <th className="pb-3 text-slate-500 text-center">Regularization Status</th>
                <th className="pb-3 text-slate-500 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredRecords.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-slate-400 font-medium">
                    No logs found matching specified criteria. Try another filter combination.
                  </td>
                </tr>
              ) : (
                filteredRecords.map((r) => {
                  const formattedDate = new Date(r.date).toLocaleDateString('en-US', {
                    weekday: 'short',
                    month: 'short',
                    day: 'numeric',
                    year: 'numeric'
                  });

                  // Detect incomplete swipe or missed entry
                  const isIncomplete = r.status !== 'On Leave' && (!r.clockIn || !r.clockOut);

                  return (
                    <tr key={r.id} className="hover:bg-slate-50/55 dark:hover:bg-slate-800/30">
                      <td className="py-3 font-semibold text-slate-700 dark:text-slate-300">
                        {formattedDate}
                      </td>
                      <td className="py-3 text-slate-500">
                        {r.shift.split('(')[0]}
                      </td>
                      <td className="py-3 font-mono">
                        {r.clockIn ? (
                          <span className="text-slate-700 dark:text-slate-300">{r.clockIn}</span>
                        ) : (
                          <span className="text-rose-400 font-medium font-sans">Missed Swipe</span>
                        )}
                      </td>
                      <td className="py-3 font-mono">
                        {r.clockOut ? (
                          <span className="text-slate-700 dark:text-slate-300">{r.clockOut}</span>
                        ) : (
                          r.status !== 'On Leave' ? (
                            <span className="text-rose-400 font-medium font-sans">Missed Swipe</span>
                          ) : (
                            <span className="text-slate-400 font-sans">--</span>
                          )
                        )}
                      </td>
                      <td className="py-3 font-mono">
                        {r.totalHours ? (
                          <span className={r.totalHours < 8 && r.status !== 'Half Day' ? 'text-amber-500 font-medium' : ''}>
                            {r.totalHours.toFixed(2)} Hrs
                          </span>
                        ) : (
                          <span className="text-slate-400">0.00</span>
                        )}
                      </td>
                      <td className="py-3">
                        <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-semibold leading-4 ${
                          r.status === 'Present' ? 'bg-emerald-50 dark:bg-emerald-950/30 text-emerald-600 dark:text-emerald-400' :
                          r.status === 'WFH' ? 'bg-violet-50 dark:bg-violet-950/30 text-violet-600 dark:text-violet-400' :
                          r.status === 'Late' ? 'bg-amber-50 dark:bg-amber-950/30 text-amber-600' :
                          r.status === 'Half Day' ? 'bg-orange-50 dark:bg-orange-950/30 text-orange-600' :
                          'bg-blue-50 dark:bg-blue-950/30 text-blue-600 dark:text-blue-400'
                        }`}>
                          {r.status}
                        </span>
                      </td>
                      <td className="py-3 text-center">
                        {r.regularizationStatus && r.regularizationStatus !== 'None' ? (
                          <span className={`inline-flex px-2.5 py-0.5 rounded-md text-[10px] font-bold ${
                            r.regularizationStatus === 'Approved' ? 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600' :
                            r.regularizationStatus === 'Rejected' ? 'bg-rose-100 dark:bg-rose-900/30 text-rose-600' :
                            'bg-amber-100 dark:bg-amber-900/35 text-amber-600'
                          }`}>
                            {r.regularizationStatus}
                          </span>
                        ) : (
                          <span className="text-slate-400 text-[10px]">—</span>
                        )}
                      </td>
                      <td className="py-3 text-right">
                        {isIncomplete && (!r.regularizationStatus || r.regularizationStatus === 'None') ? (
                          <button
                            onClick={() => onInitiateRegularization(r.date)}
                            className="bg-blue-50 hover:bg-blue-100 dark:bg-blue-950/30 dark:hover:bg-blue-900/40 text-blue-600 dark:text-blue-400 font-bold px-2 py-1 rounded transition-colors text-[10px] cursor-pointer"
                          >
                            Correct Log
                          </button>
                        ) : (
                          <span className="text-slate-350 dark:text-slate-600 text-[10px]">No Action</span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
}
