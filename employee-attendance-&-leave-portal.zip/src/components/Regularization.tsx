/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import { Clock, CheckSquare, AlertCircle, Info, PenTool, CheckCircle, RefreshCcw } from 'lucide-react';
import { RegularizationRequest } from '../types';

interface RegularizationProps {
  regularizationHistory: RegularizationRequest[];
  onApplyRegularization: (req: Omit<RegularizationRequest, 'id' | 'status'>) => void;
  preselectedDate?: string;
  isDark: boolean;
}

export default function Regularization({
  regularizationHistory,
  onApplyRegularization,
  preselectedDate = '',
  isDark
}: RegularizationProps) {
  const [date, setDate] = useState(preselectedDate || '');
  const [missingInTime, setMissingInTime] = useState('12:00');
  const [missingOutTime, setMissingOutTime] = useState('21:00');
  const [reason, setReason] = useState('');
  const [submitted, setSubmitted] = useState(false);

  // Synchronize incoming preselected dates
  React.useEffect(() => {
    if (preselectedDate) {
      setDate(preselectedDate);
    }
  }, [preselectedDate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!date || !missingInTime || !missingOutTime || !reason.trim()) {
      alert("Please fill in all corrections fields.");
      return;
    }

    onApplyRegularization({
      date,
      missingInTime,
      missingOutTime,
      reason
    });

    // Reset Form
    setDate('');
    setReason('');
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <div className="space-y-6" id="regularization-tab">
      
      {/* Title */}
      <div>
        <h2 className="text-xl md:text-2xl font-bold tracking-tight">Attendance Regularization (Biometric Correction)</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Correct incorrect swipes, network biometric failures, and ad-hoc client visit timesheet logs.</p>
      </div>

      {/* Main Grid: Form Left, History Right */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Correction form */}
        <div className={`p-6 rounded-xl border shadow-sm h-fit ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <h3 className="font-bold text-sm mb-4 border-b pb-3 dark:border-slate-800 flex items-center gap-2">
            <PenTool className="text-blue-600" size={16} /> Lodge Regularization Ticket
          </h3>

          {submitted && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/25 border border-emerald-150 rounded-lg text-emerald-600 mb-4 text-xs font-semibold flex gap-2">
              <CheckCircle size={16} className="flex-shrink-0" />
              <span>Correction query submitted successfully! Shalini Murthy (HR) will verify.</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Selected Date */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Attendance Date for Correction</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700 font-mono"
              />
              <p className="text-[8px] text-slate-400">Specify the day where you experienced swipe delays or biometric hardware failures.</p>
            </div>

            {/* In / Out correct values */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-400 uppercase">Correct In-Time</label>
                <input
                  type="time"
                  required
                  value={missingInTime}
                  onChange={(e) => setMissingInTime(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-400 uppercase">Correct Out-Time</label>
                <input
                  type="time"
                  required
                  value={missingOutTime}
                  onChange={(e) => setMissingOutTime(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700 font-mono"
                />
              </div>
            </div>

            {/* Justification textbox */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Reason for Correction</label>
              <textarea
                required
                rows={3}
                placeholder="Declare biological, travel, client login, or fingerprint scanner faults clearly..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
              />
            </div>

            {/* Validation information bar */}
            <div className="flex gap-2 p-3 rounded-lg bg-amber-500/5 border border-amber-500/10 text-[9px] text-slate-500 dark:text-slate-400 leading-normal">
              <AlertCircle size={14} className="text-amber-500 flex-shrink-0" />
              <span>HR monitors ip addresses and gateway checkins during correction validations to ensure strict security.</span>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 rounded-lg text-xs shadow hover:shadow-md transition-all cursor-pointer"
            >
              Submit Ticket Correct
            </button>

          </form>
        </div>

        {/* Regularization History list */}
        <div className={`col-span-1 lg:col-span-2 p-6 rounded-xl border shadow-sm ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <h3 className="font-bold text-sm mb-4 border-b pb-3 dark:border-slate-700">Correction Tickets logs</h3>
          
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="pb-3 text-slate-500">Target Date</th>
                  <th className="pb-3 text-slate-500">Expected Swipes</th>
                  <th className="pb-3 text-slate-500">Submitted Reason</th>
                  <th className="pb-3 text-slate-500">Auditor Status</th>
                  <th className="pb-3 text-slate-500 text-right">HR Review Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {regularizationHistory.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                    <td className="py-3.5 font-bold text-slate-700 dark:text-slate-200">
                      {new Date(item.date).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                    </td>
                    <td className="py-3.5 font-mono text-slate-500">
                      In: <strong className="text-slate-650">{item.missingInTime}</strong> | Out: <strong className="text-slate-650">{item.missingOutTime}</strong>
                    </td>
                    <td className="py-3.5 text-slate-600 dark:text-slate-400 max-w-xs truncate" title={item.reason}>
                      {item.reason}
                    </td>
                    <td className="py-3.5">
                      <span className={`inline-flex px-2.5 py-0.5 rounded-md text-[10px] font-extrabold ${
                        item.status === 'Approved' ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600' :
                        item.status === 'Rejected' ? 'bg-rose-50 dark:bg-rose-955/20 text-rose-600' :
                        'bg-amber-50 dark:bg-amber-955/20 text-amber-600'
                      }`}>
                        {item.status}
                      </span>
                    </td>
                    <td className="py-3.5 text-right font-medium italic text-slate-400">
                      {item.approverComments || 'Awaiting HR audit comment'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

        </div>

      </div>

    </div>
  );
}
