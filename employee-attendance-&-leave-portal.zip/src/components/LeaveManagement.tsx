/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { PlaneTakeoff, Info, Calendar, FileText, UploadCloud, CheckCircle2, AlertCircle, RefreshCw, Download } from 'lucide-react';
import { LeaveBalance, LeaveRequest } from '../types';

interface LeaveManagementProps {
  leaveBalances: LeaveBalance;
  leaveHistory: LeaveRequest[];
  onApplyLeave: (leave: Omit<LeaveRequest, 'id' | 'appliedDate' | 'status' | 'approver'> & { attachmentName?: string }) => void;
  isDark: boolean;
}

export default function LeaveManagement({
  leaveBalances,
  leaveHistory,
  onApplyLeave,
  isDark
}: LeaveManagementProps) {
  // Form State
  const [leaveType, setLeaveType] = useState<'Casual Leave' | 'Sick Leave' | 'Privilege Leave' | 'Loss of Pay'>('Casual Leave');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  const [reason, setReason] = useState('');
  const [fileAttachment, setFileAttachment] = useState<File | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [submittedMessage, setSubmittedMessage] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  // File Upload Handlers (Drag & drop support)
  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFileAttachment(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFileAttachment(e.target.files[0]);
    }
  };

  const triggerFileSelect = () => {
    fileInputRef.current?.click();
  };

  // Submit Handler
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fromDate || !toDate || !reason.trim()) {
      alert("Please fill in all required fields.");
      return;
    }

    // Days calculation simple representation
    const fDate = new Date(fromDate);
    const tDate = new Date(toDate);
    const timeDiff = tDate.getTime() - fDate.getTime();
    let calculatedDays = 1;
    if (timeDiff >= 0) {
      calculatedDays = Math.ceil(timeDiff / (1000 * 3600 * 24)) + 1;
    }

    onApplyLeave({
      leaveType,
      fromDate,
      toDate,
      days: calculatedDays,
      reason,
      attachmentName: fileAttachment ? fileAttachment.name : undefined
    });

    // Reset Form
    setFromDate('');
    setToDate('');
    setReason('');
    setFileAttachment(null);
    setSubmittedMessage("Leave application submitted successfully! It is awaiting HR approval.");
    setTimeout(() => setSubmittedMessage(null), 5000);
  };

  const handleDownloadCSV = () => {
    const headers = ["Applied Date", "Leave Type", "Duration", "From Date", "To Date", "Reason Description", "Approver / Audit", "Status"];
    const rows = leaveHistory.map(item => {
      const appDate = new Date(item.appliedDate).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' }).replace(/,/g, '');
      const leaveTypeClean = item.leaveType.replace(/,/g, '');
      const days = `${item.days} Day${item.days === 1 ? '' : 's'}`;
      const fromD = item.fromDate;
      const toD = item.toDate;
      const reasonClean = item.reason.replace(/"/g, '""').replace(/,/g, ' ');
      const approverName = item.approver.replace(/,/g, '');
      const status = item.status;
      
      return [
        `"${appDate}"`,
        `"${leaveTypeClean}"`,
        `"${days}"`,
        `"${fromD}"`,
        `"${toD}"`,
        `"${reasonClean}"`,
        `"${approverName}"`,
        `"${status}"`
      ].join(",");
    });
    
    const csvContent = [headers.join(","), ...rows].join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Leave_History_Report.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="leave-management-tab">
      
      {/* Title */}
      <div>
        <h2 className="text-xl md:text-2xl font-bold tracking-tight">Leave Balance & Leave Applications</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Submit annual leaves, monitor current accrued balances, and check status histories.</p>
      </div>

      {/* Leave Balance Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl animate-fade-in">
        
        <div className={`p-5 rounded-xl border shadow-sm relative overflow-hidden ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Casual Leave (CL)</span>
            <span className="h-6 w-6 rounded-full bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center text-emerald-600 dark:text-emerald-400 text-xs font-bold">CL</span>
          </div>
          <p className="text-3xl font-extrabold block mt-3 text-emerald-500">{leaveBalances.casualLeave} Days</p>
          <span className="text-[10px] text-slate-400 mt-1 block">Accrued monthly (1.00/m)</span>
        </div>

        <div className={`p-5 rounded-xl border shadow-sm relative overflow-hidden ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-widest">Loss of Pay (LOP)</span>
            <span className="h-6 w-6 rounded-full bg-rose-100 dark:bg-rose-900/30 flex items-center justify-center text-rose-600 dark:text-rose-400 text-xs font-bold">L</span>
          </div>
          <p className="text-3xl font-extrabold block mt-3 text-rose-500">{leaveBalances.lossOfPay} Days</p>
          <span className="text-[10px] text-slate-400 mt-1 block">Unpaid exceptional leaves</span>
        </div>

      </div>

      {/* Main Grid: Left Apply Form, Right Leave History list */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Leave Apply form (Col span 1) */}
        <div className={`p-6 rounded-xl border shadow-sm h-fit ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <h3 className="font-bold text-sm mb-4 flex items-center gap-2 border-b pb-3 dark:border-slate-700">
            <PlaneTakeoff className="text-blue-600" size={16} /> New Leave Request Form
          </h3>

          {submittedMessage && (
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/25 border border-emerald-150 rounded-lg text-emerald-600 mb-4 text-xs font-medium flex gap-2">
              <CheckCircle2 size={16} className="flex-shrink-0" />
              <span>{submittedMessage}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Leave Type Dropdown */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Leave Category</label>
              <select
                value={leaveType}
                onChange={(e) => setLeaveType(e.target.value as any)}
                className="w-full px-3 py-2 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
              >
                <option value="Casual Leave">Casual Leave (CL)</option>
                <option value="Loss of Pay">Loss of Pay (LOP)</option>
              </select>
            </div>

            {/* From & To Dates */}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-400 uppercase">From Date</label>
                <input
                  type="date"
                  required
                  value={fromDate}
                  onChange={(e) => setFromDate(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700 font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-400 uppercase">To Date</label>
                <input
                  type="date"
                  required
                  value={toDate}
                  onChange={(e) => setToDate(e.target.value)}
                  className="w-full px-3 py-2 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700 font-mono"
                />
              </div>
            </div>

            {/* Leave Reason Textbox */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Reason description</label>
              <textarea
                required
                rows={3}
                placeholder="Describe your leave requirements clearly..."
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
              />
            </div>

            {/* Custom file attachments (Drag and drop zone) */}
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-400 uppercase">Supportive Attachments (Optional)</label>
              
              <div
                onDragEnter={handleDrag}
                onDragOver={handleDrag}
                onDragLeave={handleDrag}
                onDrop={handleDrop}
                onClick={triggerFileSelect}
                className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-1.5 ${
                  dragActive
                    ? 'border-blue-500 bg-blue-50/20'
                    : fileAttachment
                      ? 'border-emerald-500 bg-emerald-50/10'
                      : 'border-slate-250 hover:border-blue-500 dark:border-slate-700 dark:hover:border-blue-500'
                }`}
              >
                <UploadCloud size={24} className={fileAttachment ? "text-emerald-500" : "text-slate-400"} />
                {fileAttachment ? (
                  <div className="text-[11px] min-w-0 px-2 w-full text-center">
                    <p className="font-semibold text-emerald-600 truncate">{fileAttachment.name}</p>
                    <p className="text-[9px] text-slate-400 mt-0.5">{(fileAttachment.size / 1024).toFixed(1)} KB - Click to swap</p>
                  </div>
                ) : (
                  <div>
                    <p className="text-[11px] font-medium text-slate-600 dark:text-slate-350">
                      Drag file here or <span className="text-blue-600 hover:underline">browse</span>
                    </p>
                    <p className="text-[8px] text-slate-400 mt-0.5">PDF, PNG, JPG standard receipts up to 2MB</p>
                  </div>
                )}
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                  accept=".pdf,.png,.jpg,.jpeg"
                />
              </div>
            </div>

            {/* Submit application button */}
            <button
              type="submit"
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-2.5 rounded-lg text-xs shadow hover:shadow-md transition-all cursor-pointer"
            >
              Submit Application
            </button>

          </form>
        </div>

        {/* Leave History List (Col span 2) */}
        <div className={`col-span-1 lg:col-span-2 p-6 rounded-xl border shadow-sm ${
          isDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'
        }`}>
          <div className="flex items-center justify-between border-b pb-3 mb-4 dark:border-slate-700">
            <h3 className="font-bold text-sm">Leave Application History</h3>
            <button
              onClick={handleDownloadCSV}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-semibold rounded-lg text-xs transition-colors shadow-sm cursor-pointer"
              title="Export complete leave history to CSV file"
              id="btn-export-leave-csv"
            >
              <Download size={14} /> Export Report
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                  <th className="pb-3 text-slate-500">Applied Date</th>
                  <th className="pb-3 text-slate-500">Leave Type</th>
                  <th className="pb-3 text-slate-500">Duration</th>
                  <th className="pb-3 text-slate-500">Reason Description</th>
                  <th className="pb-3 text-slate-500">Approver / Audit</th>
                  <th className="pb-3 text-slate-500 text-right">Approval Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {leaveHistory.map((item) => {
                  const isSingleDay = item.days === 1;
                  return (
                    <tr key={item.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                      <td className="py-3.5 font-medium text-slate-500">
                        {new Date(item.appliedDate).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </td>
                      <td className="py-3.5">
                        <span className="font-bold text-slate-700 dark:text-slate-200">{item.leaveType}</span>
                        {item.attachmentName && (
                          <span className="block text-[9px] text-blue-500 font-medium italic mt-0.5 truncate max-w-28" title={item.attachmentName}>
                            📎 {item.attachmentName}
                          </span>
                        )}
                      </td>
                      <td className="py-3.5">
                        <span className="font-semibold block">{item.days} {isSingleDay ? 'Day' : 'Days'}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{item.fromDate} to {item.toDate}</span>
                      </td>
                      <td className="py-3.5 max-w-xs truncate text-slate-600 dark:text-slate-400" title={item.reason}>
                        {item.reason}
                      </td>
                      <td className="py-3.5 text-slate-500 font-medium whitespace-nowrap">
                        {item.approver}
                      </td>
                      <td className="py-3.5 text-right">
                        <span className={`inline-flex px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                          item.status === 'Approved' ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600' :
                          item.status === 'Rejected' ? 'bg-rose-50 dark:bg-rose-950/20 text-rose-600' :
                          'bg-amber-50 dark:bg-amber-955/20 text-amber-600'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

        </div>

      </div>

    </div>
  );
}
