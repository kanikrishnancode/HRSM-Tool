/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { CalendarDays, Shield, Info, CalendarRange, Filter, Search, UserMinus } from 'lucide-react';
import { EMPLOYEE_SHIFT_DATA, TEAM_MEMBERS } from '../data';

interface ShiftRosterProps {
  isDark: boolean;
}

export default function ShiftRoster({ isDark }: ShiftRosterProps) {
  const [selectedShiftFilter, setSelectedShiftFilter] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');

  // Define global shift options
  const globalShifts = [
    { name: 'General Shift', code: 'GS', timing: '12:00 PM - 09:00 PM', hours: '9 Hours (1h break)', color: 'bg-emerald-500 hover:opacity-90', textColor: 'text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/20' },
  ];

  // Filtering rosters
  const filteredRoster = EMPLOYEE_SHIFT_DATA.filter((item) => {
    if (selectedShiftFilter !== 'All' && item.shiftName !== selectedShiftFilter) return false;
    if (searchQuery) {
      const matchName = item.employeeName.toLowerCase().includes(searchQuery.toLowerCase());
      const matchDept = item.department.toLowerCase().includes(searchQuery.toLowerCase());
      return matchName || matchDept;
    }
    return true;
  });

  // Calendar styled visual roster helpers (Weekly View: May 25, 2026 to May 31, 2026)
  const weekDates = [
    { day: 'Mon', date: '25', full: '2026-05-25' },
    { day: 'Tue', date: '26', full: '2026-05-26' },
    { day: 'Wed', date: '27', full: '2026-05-27' },
    { day: 'Thu', date: '28', full: '2026-05-28' },
    { day: 'Fri', date: '29', full: '2026-05-29' },
    { day: 'Sat', date: '30', full: '2026-05-30' },
    { day: 'Sun', date: '31', full: '2026-05-31' },
  ];

  // Map employee name to specific week day status
  const getEmployeeWeeklyRosterStatus = (employeeName: string, day: string) => {
    if (day === 'Sun') return { label: 'OFF', style: 'bg-slate-100 dark:bg-slate-800 text-slate-400 dark:text-slate-500' };
    
    // Sat Off check
    if (day === 'Sat') {
      if (employeeName === 'Kavitha Mohan' || employeeName === 'Rohan Deshmukh') {
        return { label: 'GS', style: 'bg-emerald-500 text-white font-semibold' }; // Alternate Working
      }
      return { label: 'OFF', style: 'bg-slate-100 dark:bg-slate-800 text-slate-400' };
    }

    // Weekday shifts are all General Shift (GS)
    return { label: 'GS', style: 'bg-emerald-500 text-white font-semibold' };
  };

  return (
    <div className="space-y-6" id="shift-roster-tab">
      
      {/* Title */}
      <div>
        <h2 className="text-xl md:text-2xl font-bold tracking-tight">Shift Roster & Deployment Scheduler</h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Configure operational shifts, track coverage gaps, and assign weekly off structures.</p>
      </div>

      {/* Global Shift Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {globalShifts.map((sh) => (
          <div key={sh.name} className={`p-4 rounded-xl border shadow-sm ${
            isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${sh.textColor}`}>
                {sh.code}
              </span>
              <span className="text-[10px] text-slate-400 font-mono">{sh.hours}</span>
            </div>
            <h4 className="font-bold text-sm">{sh.name}</h4>
            <p className="text-xs text-blue-600 dark:text-blue-400 font-mono font-medium mt-1">{sh.timing}</p>
          </div>
        ))}
      </div>

      {/* Calendar Style Visual Roster Visualization (Grid) */}
      <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-750 pb-4 mb-4">
          <div>
            <h3 className="font-bold text-sm flex items-center gap-2">
              <CalendarRange className="text-blue-600" size={16} /> Team Schedule Grid View
            </h3>
            <p className="text-[10px] text-slate-400 mt-0.5">Visually inspect daily coverage rosters for the current week.</p>
          </div>
          <span className="text-xs bg-slate-100 dark:bg-slate-900 px-3 py-1 rounded-md font-bold font-mono text-slate-600 dark:text-slate-400 align-middle">
            Week: 25 May - 31 May 2026
          </span>
        </div>

        {/* Visual Calendar Grid Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-center border-collapse">
            <thead>
              <tr className="border-b border-slate-150 dark:border-slate-800">
                <th className="text-left pb-3 font-semibold text-slate-500 w-44">Employee / Team</th>
                {weekDates.map((item) => (
                  <th key={item.day} className="pb-3 px-1">
                    <div className="flex flex-col items-center">
                      <span className="text-[10px] text-slate-400 uppercase tracking-wider">{item.day}</span>
                      <span className="text-xs font-bold font-mono mt-0.5">{item.date}</span>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {TEAM_MEMBERS.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                  {/* Left Employee card cells */}
                  <td className="py-3 text-left">
                    <div className="flex items-center gap-2">
                      <div className="h-6 w-6 rounded-full bg-blue-100 dark:bg-blue-900/30 font-bold text-[10px] flex items-center justify-center text-blue-700">
                        {emp.name.split(' ').map(n=>n[0]).join('')}
                      </div>
                      <div className="flex flex-col">
                        <span className="font-semibold text-xs leading-3 text-slate-800 dark:text-slate-200">{emp.name}</span>
                        <span className="text-[9px] text-slate-400 leading-2 mt-0.5 truncate">{emp.role}</span>
                      </div>
                    </div>
                  </td>

                  {/* Calendar day cells representing schedules */}
                  {weekDates.map((item) => {
                    const status = getEmployeeWeeklyRosterStatus(emp.name, item.day);
                    return (
                      <td key={item.day} className="py-2.5 px-1 align-middle">
                        <div className={`h-8 w-11 rounded-md mx-auto flex items-center justify-center text-[10px] shadow-sm tracking-wider ${status.style}`} title={`${emp.name}: ${status.label}`}>
                          {status.label}
                        </div>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Roster Calendar legend helper codes */}
        <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-4 text-[10px] text-slate-400 font-medium">
          <span className="font-bold text-slate-500 uppercase">Roster Legends:</span>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-1.5 rounded-sm bg-emerald-500" />
            <span>GS = General Shift (12:00 PM - 09:00 PM)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-1.5 rounded-sm bg-slate-100 dark:bg-slate-800 border" />
            <span>OFF = Weekly Rest Day</span>
          </div>
        </div>

      </div>

      {/* Complete Employee Shift Assignments Table List */}
      <div className={`p-5 rounded-xl border shadow-sm ${isDark ? 'bg-slate-800 border-slate-750' : 'bg-white border-slate-100'}`}>
        
        {/* Table Filters header context */}
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4 border-b border-slate-150 dark:border-slate-800 pb-4 mb-4">
          <h3 className="text-sm font-bold text-slate-550 flex items-center gap-2">
            <CalendarDays size={16} className="text-slate-400" /> Employee Assignment Registrations
          </h3>

          <div className="flex flex-wrap items-center gap-3">
            {/* Search Input */}
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" size={14} />
              <input
                type="text"
                placeholder="Search staff, dept..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-8 pr-3 py-1.5 border rounded-lg text-xs w-44 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:bg-slate-900 border-slate-250 dark:border-slate-700"
              />
            </div>
          </div>
        </div>

        {/* Assignments Table structure */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead>
              <tr className="border-b border-slate-150 dark:border-slate-800 text-slate-400 font-semibold uppercase tracking-wider">
                <th className="pb-3 text-slate-500">Employee Name</th>
                <th className="pb-3 text-slate-500">Department</th>
                <th className="pb-3 text-slate-500">Assigned Shift</th>
                <th className="pb-3 text-slate-500">Daily Timing</th>
                <th className="pb-3 text-slate-500">Weekly Off</th>
                <th className="pb-3 text-slate-500 text-right">Alternate Saturday Rule</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filteredRoster.map((item) => (
                <tr key={item.employeeId} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/20">
                  <td className="py-3 font-semibold text-slate-800 dark:text-slate-200">
                    {item.employeeName}
                  </td>
                  <td className="py-3 text-slate-500">
                    {item.department}
                  </td>
                  <td className="py-3 font-medium">
                    <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600 dark:text-emerald-400">
                      {item.shiftName}
                    </span>
                  </td>
                  <td className="py-3 font-mono text-slate-600 dark:text-slate-400">
                    {item.timing}
                  </td>
                  <td className="py-3 text-slate-550">
                    {item.weeklyOff}
                  </td>
                  <td className="py-3 text-right text-slate-500 italic">
                    {item.alternateSaturdayStatus}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

      </div>

    </div>
  );
}
