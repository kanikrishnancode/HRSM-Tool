/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';

// Models
import { Employee, AttendanceRecord, LeaveBalance, LeaveRequest, RegularizationRequest, Notification } from './types';

// Components
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import Attendance from './components/Attendance';
import ShiftRoster from './components/ShiftRoster';
import AlternativeSaturday from './components/AlternativeSaturday';
import LeaveManagement from './components/LeaveManagement';
import Regularization from './components/Regularization';
import Reports from './components/Reports';
import SettingsComponent from './components/Settings';
import AdminPanel from './components/AdminPanel';

// Mock Data seeds
import {
  DEFAULT_USER,
  INITIAL_LEAVE_BALANCES,
  INITIAL_ATTENDANCE_DATA,
  INITIAL_LEAVE_HISTORY,
  INITIAL_REGULARIZATION_HISTORY,
  INITIAL_NOTIFICATIONS,
  TEAM_MEMBERS
} from './data';

export default function App() {
  // Session authentication states
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<Employee>(DEFAULT_USER);
  const [viewMode, setViewMode] = useState<'employee' | 'admin'>('employee');
  const [activeTab, setActiveTab] = useState('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [isDark, setIsDark] = useState(false);

  // States mirroring dynamic databases
  const [employeesList, setEmployeesList] = useState<Employee[]>(TEAM_MEMBERS);
  const [attendanceData, setAttendanceData] = useState<AttendanceRecord[]>(INITIAL_ATTENDANCE_DATA);
  const [leaveBalances, setLeaveBalances] = useState<LeaveBalance>(INITIAL_LEAVE_BALANCES);
  const [leaveHistory, setLeaveHistory] = useState<LeaveRequest[]>(INITIAL_LEAVE_HISTORY);
  const [regularizationHistory, setRegularizationHistory] = useState<RegularizationRequest[]>(INITIAL_REGULARIZATION_HISTORY);
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFICATIONS);

  // Live clock tracker states
  const [currentClockedState, setCurrentClockedState] = useState<{
    isClockedIn: boolean;
    clockInTime?: string;
    elapsedSeconds: number;
    wfh: boolean;
  }>({
    isClockedIn: false,
    elapsedSeconds: 0,
    wfh: false
  });

  const [preselectedRegularizationDate, setPreselectedRegularizationDate] = useState<string>('');
  const [currentTime, setCurrentTime] = useState(new Date());

  // Interval timers
  const clockIntervalRef = useRef<number | null>(null);

  // Live time ticker
  useEffect(() => {
    const timeTimer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timeTimer);
  }, []);

  // Sync elapsed seconds when logged in
  useEffect(() => {
    if (currentClockedState.isClockedIn) {
      const interval = setInterval(() => {
        setCurrentClockedState(prev => ({
          ...prev,
          elapsedSeconds: prev.elapsedSeconds + 1
        }));
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [currentClockedState.isClockedIn]);

  // Sync dark class on raw document root
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDark]);

  // Auth actions
  const handleLogin = (loggedInUser: Employee) => {
    setUser(loggedInUser);
    setIsLoggedIn(true);
    // Add positive entry notification
    const newNotif: Notification = {
      id: `N-LOGIN-${Date.now()}`,
      title: 'Session Started',
      message: `Successfully authenticated as ${loggedInUser.name}. Good day!`,
      time: 'Just now',
      unread: true,
      type: 'success'
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    // Reset tracker if active
    if (currentClockedState.isClockedIn) {
      handleClockOut();
    }
  };

  // Clock in operations
  const handleClockIn = (wfh: boolean) => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
    const todayStr = now.toISOString().split('T')[0];

    setCurrentClockedState({
      isClockedIn: true,
      clockInTime: timeStr,
      elapsedSeconds: 0,
      wfh
    });

    // Check if record exists for today, else prepend one representing checking in
    const alreadyRecorded = attendanceData.find(r => r.date === todayStr);
    if (!alreadyRecorded) {
      const isLateStr = now.getHours() > 12 || (now.getHours() === 12 && now.getMinutes() > 15);
      const statusValue = wfh ? 'WFH' : (isLateStr ? 'Late' : 'Present');

      const record: AttendanceRecord = {
        id: `A-${Date.now()}`,
        date: todayStr,
        shift: 'General Shift (12:00 PM - 09:00 PM)',
        clockIn: timeStr,
        status: statusValue,
        regularizationStatus: 'None'
      };
      setAttendanceData(prev => [record, ...prev]);
    }

    // Push notification
    const checkInNotif: Notification = {
      id: `NCl-${Date.now()}`,
      title: 'Attendance Swiped In',
      message: `Clocked in successfully at ${timeStr} with ${wfh ? 'WFH' : 'Office Biometrics'} mode.`,
      time: 'Just now',
      unread: true,
      type: 'success'
    };
    setNotifications(prev => [checkInNotif, ...prev]);
  };

  // Clock out sessions
  const handleClockOut = () => {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
    const todayStr = now.toISOString().split('T')[0];

    // Calculate final hours worked
    const calculatedHours = currentClockedState.elapsedSeconds / 3600;

    setAttendanceData(prev => prev.map(rec => {
      if (rec.date === todayStr) {
        return {
          ...rec,
          clockOut: timeStr,
          totalHours: calculatedHours > 0 ? calculatedHours : 8.0 // default reasonable shift helper if quick clicked
        };
      }
      return rec;
    }));

    setCurrentClockedState(prev => ({
      ...prev,
      isClockedIn: false
    }));

    const checkOutNotif: Notification = {
      id: `NCR-${Date.now()}`,
      title: 'Attendance Clocked Out',
      message: `Your tracking session ended at ${timeStr}. Attendance is securely synchronized.`,
      time: 'Just now',
      unread: true,
      type: 'info'
    };
    setNotifications(prev => [checkOutNotif, ...prev]);
  };

  // Initiate Timesheet Regularizations
  const handleInitiateRegularization = (dateStr: string) => {
    setPreselectedRegularizationDate(dateStr);
    setActiveTab('regularization');
  };

  // Submit leave applications
  const handleApplyLeave = (leave: Omit<LeaveRequest, 'id' | 'appliedDate' | 'status' | 'approver'> & { attachmentName?: string }) => {
    // Check balances before deduction
    const cost = leave.days;
    let valid = true;

    setLeaveBalances(prev => {
      const next = { ...prev };
      if (leave.leaveType === 'Casual Leave') {
        if (prev.casualLeave >= cost) next.casualLeave -= cost;
        else valid = false;
      } else if (leave.leaveType === 'Sick Leave') {
        if (prev.sickLeave >= cost) next.sickLeave -= cost;
        else valid = false;
      } else if (leave.leaveType === 'Privilege Leave') {
        if (prev.privilegeLeave >= cost) next.privilegeLeave -= cost;
        else valid = false;
      } else {
        next.lossOfPay += cost; // Unpaid LOP increases
      }
      return next;
    });

    if (!valid && leave.leaveType !== 'Loss of Pay') {
      alert("Insufficient Leave Balances. The leave will be processed as 'Loss of Pay' (LOP).");
      leave.leaveType = 'Loss of Pay';
    }

    const newRequest: LeaveRequest = {
      ...leave,
      id: `L-${Math.floor(Math.random() * 900) + 100}`,
      appliedDate: new Date().toISOString().split('T')[0],
      status: 'Pending',
      approver: 'Shalini Murthy (Pending Vetting)'
    };

    setLeaveHistory(prev => [newRequest, ...prev]);

    // Add notification
    const leaveNotif: Notification = {
      id: `NL-${Date.now()}`,
      title: 'Leave Requested',
      message: `Applied for ${leave.days} Day(s) of ${leave.leaveType} starting ${leave.fromDate}.`,
      time: 'A moment ago',
      unread: true,
      type: 'info'
    };
    setNotifications(prev => [leaveNotif, ...prev]);
  };

  // Submit timesheet correction regularizations
  const handleApplyRegularization = (correction: Omit<RegularizationRequest, 'id' | 'status'>) => {
    const newReq: RegularizationRequest = {
      ...correction,
      id: `R-${Math.floor(Math.random() * 100) + 200}`,
      status: 'Pending'
    };

    setRegularizationHistory(prev => [newReq, ...prev]);

    // Also update raw attendance record's regularization status to "Pending"
    setAttendanceData(prev => prev.map(rec => {
      if (rec.date === correction.date) {
        return {
          ...rec,
          regularizationStatus: 'Pending'
        };
      }
      return rec;
    }));

    const regNotif: Notification = {
      id: `NRG-${Date.now()}`,
      title: 'Correction Ticket Raised',
      message: `Attendance correction raised for ${correction.date}. Awaiting management review.`,
      time: 'Just now',
      unread: true,
      type: 'warning'
    };
    setNotifications(prev => [regNotif, ...prev]);
  };

  // Notification management callbacks
  const handleMarkNotificationRead = (id: string) => {
    setNotifications(prev => prev.map(notif => {
      if (notif.id === id) return { ...notif, unread: false };
      return notif;
    }));
  };

  const handleClearNotifications = () => {
    setNotifications([]);
  };

  // Routing manager
  const renderActiveSubView = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <Dashboard
            user={user}
            attendanceData={attendanceData}
            leaveBalances={leaveBalances}
            currentClockedState={currentClockedState}
            onClockIn={handleClockIn}
            onClockOut={handleClockOut}
            setActiveTab={setActiveTab}
            isDark={isDark}
          />
        );
      case 'attendance':
        return (
          <Attendance
            attendanceData={attendanceData}
            currentClockedState={currentClockedState}
            onClockIn={handleClockIn}
            onClockOut={handleClockOut}
            onInitiateRegularization={handleInitiateRegularization}
            isDark={isDark}
          />
        );
      case 'roster':
        return <ShiftRoster isDark={isDark} />;
      case 'saturdays':
        return <AlternativeSaturday isDark={isDark} />;
      case 'leaves':
        return (
          <LeaveManagement
            leaveBalances={leaveBalances}
            leaveHistory={leaveHistory}
            onApplyLeave={handleApplyLeave}
            isDark={isDark}
          />
        );
      case 'regularization':
        return (
          <Regularization
            regularizationHistory={regularizationHistory}
            onApplyRegularization={handleApplyRegularization}
            preselectedDate={preselectedRegularizationDate}
            isDark={isDark}
          />
        );
      case 'reports':
        return <Reports isDark={isDark} />;
      case 'settings':
        return <SettingsComponent user={user} isDark={isDark} />;
      case 'admin':
        return (
          <AdminPanel
            employees={employeesList}
            setEmployees={setEmployeesList}
            attendanceData={attendanceData}
            setAttendanceData={setAttendanceData}
            leaveHistory={leaveHistory}
            setLeaveHistory={setLeaveHistory}
            regularizationHistory={regularizationHistory}
            setRegularizationHistory={setRegularizationHistory}
            isDark={isDark}
            onSendNotification={(title, message, type) => {
              const newNotif = {
                id: `N-ADMIN-${Date.now()}`,
                title,
                message,
                time: 'Just now',
                unread: true,
                type
              };
              setNotifications(prev => [newNotif, ...prev]);
            }}
          />
        );
      default:
        return (
          <div className="p-8 text-center text-slate-400 font-medium font-sans">
            Under active migration.
          </div>
        );
    }
  };

  // Guard: if not authenticated, force login render
  if (!isLoggedIn) {
    return <Login onLoginSuccess={handleLogin} />;
  }

  return (
    <div className={`min-h-screen flex transition-colors duration-200 ${
      isDark ? 'dark bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-800'
    }`} id="portal-frame-wrapper">
      
      {/* Sidebar collapsible menu */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          // Auto clear select parameters if moving away from corrigenda
          if (tab !== 'regularization') setPreselectedRegularizationDate('');
        }}
        collapsed={sidebarCollapsed}
        setCollapsed={setSidebarCollapsed}
        user={user}
        onLogout={handleLogout}
        isDark={isDark}
        viewMode={viewMode}
        setViewMode={setViewMode}
        mobileOpen={mobileSidebarOpen}
        onCloseMobile={() => setMobileSidebarOpen(false)}
      />

      {/* Main page canvas */}
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* Navbar */}
        <Navbar
          user={user}
          notifications={notifications}
          onMarkNotificationRead={handleMarkNotificationRead}
          onClearNotifications={handleClearNotifications}
          isDark={isDark}
          setIsDark={setIsDark}
          onLogout={handleLogout}
          currentTime={currentTime}
          onToggleMobileSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
        />

        {/* Dynamic sub-view canvas frame */}
        <main className="p-6 overflow-y-auto flex-1 h-[calc(100vh-4rem)]">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="max-w-7xl mx-auto h-full"
            >
              {renderActiveSubView()}
            </motion.div>
          </AnimatePresence>
        </main>

      </div>

    </div>
  );
}
