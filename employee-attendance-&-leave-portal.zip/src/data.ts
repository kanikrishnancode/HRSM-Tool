/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Employee,
  AttendanceRecord,
  EmployeeShift,
  SaturdayConfig,
  LeaveBalance,
  LeaveRequest,
  RegularizationRequest,
  Notification,
  CompanyHoliday
} from './types';

// Multi-user dataset representing a real project team
export const DEFAULT_USER: Employee = {
  id: 'EMP-2026-1045',
  name: 'Kavitha Mohan',
  email: 'kavithamohanofficial@gmail.com',
  role: 'Tech Lead - Core Engineering',
  department: 'Software Engineering',
  avatar: 'KM'
};

export const TEAM_MEMBERS: Employee[] = [
  { id: 'EMP-2026-1045', name: 'Kavitha Mohan', email: 'kavithamohanofficial@gmail.com', role: 'Tech Lead', department: 'Software Engineering' },
  { id: 'EMP-2026-0321', name: 'Arjun Sharma', email: 'arjun.sharma@company.com', role: 'Frontend Engineer', department: 'Software Engineering' },
  { id: 'EMP-2026-0812', name: 'Priya Patel', email: 'priya.patel@company.com', role: 'UI/UX Designer', department: 'Design & Product' },
  { id: 'EMP-2026-0104', name: 'Rohan Deshmukh', email: 'rohan.d@company.com', role: 'Backend Dev', department: 'Software Engineering' },
  { id: 'EMP-2026-1191', name: 'Meera Iyer', email: 'meera.iyer@company.com', role: 'QA Automation Engineer', department: 'Quality Assurance' },
  { id: 'EMP-2026-0562', name: 'Vikram Singh', email: 'vikram.s@company.com', role: 'DevOps Engineer', department: 'Cloud Operations' }
];

export const INITIAL_LEAVE_BALANCES: LeaveBalance = {
  casualLeave: 8,
  sickLeave: 12,
  privilegeLeave: 15,
  lossOfPay: 0
};

// Seed 3 months of mock attendance data (March, April, May 2026) for Kavitha Mohan
export const INITIAL_ATTENDANCE_DATA: AttendanceRecord[] = [
  // May 2026
  { id: 'A1', date: '2026-05-29', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:52', clockOut: '21:04', totalHours: 9.2, status: 'Present', regularizationStatus: 'None' },
  { id: 'A2', date: '2026-05-28', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '12:05', clockOut: '21:10', totalHours: 9.08, status: 'Present', regularizationStatus: 'None' },
  { id: 'A3', date: '2026-05-27', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '12:12', clockOut: '21:01', totalHours: 8.82, status: 'Present', regularizationStatus: 'None' },
  { id: 'A4', date: '2026-05-26', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:45', clockOut: '20:50', totalHours: 9.08, status: 'Present', regularizationStatus: 'None' },
  { id: 'A5', date: '2026-05-25', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '12:35', clockOut: '21:05', totalHours: 8.5, status: 'Late', regularizationStatus: 'None' },
  // Alternate Saturday Working on May 23rd
  { id: 'A6', date: '2026-05-23', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '12:02', clockOut: '17:30', totalHours: 5.47, status: 'Half Day', regularizationStatus: 'None' },
  { id: 'A7', date: '2026-05-22', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:58', clockOut: '21:15', totalHours: 9.28, status: 'Present', regularizationStatus: 'None' },
  { id: 'A8', date: '2026-05-21', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:50', clockOut: '21:00', totalHours: 9.17, status: 'Present', regularizationStatus: 'None' },
  { id: 'A9', date: '2026-05-20', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '12:01', clockOut: '21:02', totalHours: 9.02, status: 'Present', regularizationStatus: 'None' },
  { id: 'A10', date: '2026-05-19', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:55', clockOut: '21:12', totalHours: 9.28, status: 'Present', regularizationStatus: 'None' },
  { id: 'A11', date: '2026-05-18', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:48', clockOut: '21:00', totalHours: 9.2, status: 'Present', regularizationStatus: 'None' },
  // 16-17 Weekend Off
  { id: 'A12', date: '2026-05-15', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:53', clockOut: '21:03', totalHours: 9.17, status: 'Present', regularizationStatus: 'None' },
  { id: 'A13', date: '2026-05-14', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:59', clockOut: '21:00', totalHours: 9.02, status: 'Present', regularizationStatus: 'None' },
  { id: 'A14', date: '2026-05-13', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '12:15', clockOut: '21:10', totalHours: 8.92, status: 'Present', regularizationStatus: 'None' },
  { id: 'A15', date: '2026-05-12', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:47', clockOut: '21:01', totalHours: 9.23, status: 'Present', regularizationStatus: 'None' },
  { id: 'A16', date: '2026-05-11', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:56', clockOut: '21:00', totalHours: 9.07, status: 'Present', regularizationStatus: 'None' },
  // Sick Leave on May 8th
  { id: 'A17', date: '2026-05-08', shift: 'General Shift (12:00 PM - 09:00 PM)', status: 'On Leave', regularizationStatus: 'None' },
  { id: 'A18', date: '2026-05-07', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:52', clockOut: '21:05', totalHours: 9.22, status: 'Present', regularizationStatus: 'None' },
  { id: 'A19', date: '2026-05-06', shift: 'General Shift (12:00 PM - 09:00 PM)', status: 'WFH', clockIn: '12:00', clockOut: '21:00', totalHours: 9.0, regularizationStatus: 'None' },
  { id: 'A20', date: '2026-05-05', shift: 'General Shift (12:00 PM - 09:00 PM)', status: 'WFH', clockIn: '12:02', clockOut: '21:01', totalHours: 8.98, regularizationStatus: 'None' },
  { id: 'A21', date: '2026-05-04', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:49', clockOut: '21:06', totalHours: 9.28, status: 'Present', regularizationStatus: 'None' },
  { id: 'A22', date: '2026-05-01', shift: 'General Shift (12:00 PM - 09:00 PM)', status: 'On Leave', regularizationStatus: 'None' },

  // April 2026
  { id: 'A30', date: '2026-04-30', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:50', clockOut: '21:00', totalHours: 9.17, status: 'Present' },
  { id: 'A31', date: '2026-04-29', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:55', clockOut: '21:05', totalHours: 9.17, status: 'Present' },
  { id: 'A32', date: '2026-04-28', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '12:40', clockOut: '21:10', totalHours: 8.5, status: 'Late' },
  { id: 'A33', date: '2026-04-27', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:52', clockOut: '21:00', totalHours: 9.13, status: 'Present' },
  { id: 'A34', date: '2026-04-24', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '12:02', clockOut: '21:00', totalHours: 8.97, status: 'Present' },
  { id: 'A35', date: '2026-04-23', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:44', clockOut: '21:02', totalHours: 9.3, status: 'Present' },
  { id: 'A36', date: '2026-04-22', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:53', clockOut: '17:10', totalHours: 5.28, status: 'Half Day' },
  { id: 'A37', date: '2026-04-21', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '12:01', clockOut: '21:05', totalHours: 9.07, status: 'Present' },
  { id: 'A38', date: '2026-04-20', shift: 'General Shift (12:00 PM - 09:00 PM)', clockIn: '11:58', clockOut: '21:12', totalHours: 9.23, status: 'Present' }
];

// Employee Shift list (Shift Roster module)
export const EMPLOYEE_SHIFT_DATA: EmployeeShift[] = [
  { employeeId: 'EMP-2026-1045', employeeName: 'Kavitha Mohan', department: 'Software Engineering', shiftName: 'General Shift', timing: '12:00 PM - 09:00 PM', weeklyOff: 'Sunday', alternateSaturdayStatus: '1st & 3rd Support Working, 2nd & 4th Off' },
  { employeeId: 'EMP-2026-0321', employeeName: 'Arjun Sharma', department: 'Software Engineering', shiftName: 'General Shift', timing: '12:00 PM - 09:00 PM', weeklyOff: 'Sunday', alternateSaturdayStatus: '2nd & 4th Support Working, 1st & 3rd Off' },
  { employeeId: 'EMP-2026-0812', employeeName: 'Priya Patel', department: 'Design & Product', shiftName: 'General Shift', timing: '12:00 PM - 09:00 PM', weeklyOff: 'Sunday', alternateSaturdayStatus: 'All Saturdays Off' },
  { employeeId: 'EMP-2026-0104', employeeName: 'Rohan Deshmukh', department: 'Software Engineering', shiftName: 'General Shift', timing: '12:00 PM - 09:00 PM', weeklyOff: 'Sunday', alternateSaturdayStatus: '1st & 3rd Support Working, 2nd & 4th Off' },
  { employeeId: 'EMP-2026-1191', employeeName: 'Meera Iyer', department: 'Quality Assurance', shiftName: 'General Shift', timing: '12:00 PM - 09:00 PM', weeklyOff: 'Sunday', alternateSaturdayStatus: 'All Saturdays Off' },
  { employeeId: 'EMP-2026-0562', employeeName: 'Vikram Singh', department: 'Cloud Operations', shiftName: 'General Shift', timing: '12:00 PM - 09:00 PM', weeklyOff: 'Saturday & Sunday', alternateSaturdayStatus: 'All Saturdays Off' }
];

// Alternate Saturdays setup
export const INITIAL_SATURDAY_CONFIG: SaturdayConfig = {
  firstThirdWorking: true,
  secondFourthOff: true,
  teamSchedules: [
    { teamName: 'Core Engineering (Kavitha\'s Team)', description: 'Primary production coverage', supportSaturdays: '1st & 3rd' },
    { teamName: 'Support & Escalation Team', description: 'Real-time client assistance', supportSaturdays: '2nd & 4th' },
    { teamName: 'Product & Design Division', description: 'Product specs and feedback', supportSaturdays: 'None' },
    { teamName: 'Cloud & System Infrastructure', description: '24/7 backup deployments', supportSaturdays: '1st & 3rd' }
  ]
};

// Leave history
export const INITIAL_LEAVE_HISTORY: LeaveRequest[] = [
  {
    id: 'L-504',
    appliedDate: '2026-05-02',
    leaveType: 'Sick Leave',
    fromDate: '2026-05-08',
    toDate: '2026-05-08',
    days: 1,
    reason: 'Suffering from dental injection fever and consultation.',
    status: 'Approved',
    approver: 'Shalini Murthy (HR Director)',
    attachmentName: 'dental_prescription.pdf'
  },
  {
    id: 'L-501',
    appliedDate: '2026-04-20',
    leaveType: 'Casual Leave',
    fromDate: '2026-05-01',
    toDate: '2026-05-01',
    days: 1,
    reason: 'Family shifting, settling household items.',
    status: 'Approved',
    approver: 'Shalini Murthy (HR Director)'
  },
  {
    id: 'L-482',
    appliedDate: '2026-03-12',
    leaveType: 'Privilege Leave',
    fromDate: '2026-03-23',
    toDate: '2026-03-27',
    days: 5,
    reason: 'Annual family continuous travel and native visit.',
    status: 'Approved',
    approver: 'Shalini Murthy (HR Director)'
  },
  {
    id: 'L-520',
    appliedDate: '2026-05-28',
    leaveType: 'Casual Leave',
    fromDate: '2026-06-15',
    toDate: '2026-06-16',
    days: 2,
    reason: 'Attending sibling\'s graduation ceremony and dinner.',
    status: 'Pending',
    approver: 'Shalini Murthy (Pending)'
  }
];

// Attendance Regularization history
export const INITIAL_REGULARIZATION_HISTORY: RegularizationRequest[] = [
  {
    id: 'R-193',
    date: '2026-05-13',
    missingInTime: '12:00',
    missingOutTime: '21:12',
    reason: 'Active client login immediately from home, forgot biometric log upon entering site late.',
    status: 'Approved',
    approverComments: 'Verified with team manager. Request approved.'
  },
  {
    id: 'R-200',
    date: '2026-05-25',
    missingInTime: '11:52',
    missingOutTime: '21:00',
    reason: 'Biometric fingerprint reader was experiencing network failure.',
    status: 'Pending'
  }
];

// Seed app notifications
export const INITIAL_NOTIFICATIONS: Notification[] = [
  {
    id: 'N1',
    title: 'Regularization Request Approved',
    message: 'Your attendance regularization for 13th May has been approved by Shalini Murthy.',
    time: '2 hours ago',
    unread: true,
    type: 'success'
  },
  {
    id: 'N2',
    title: 'Leave Apply Status',
    message: 'Your Privilege Leave application for June 15-16 is awaiting manager approval.',
    time: '1 day ago',
    unread: false,
    type: 'info'
  },
  {
    id: 'N3',
    title: 'New Shift Schedule',
    message: 'Engineering Team Shift roster for next week has been generated.',
    time: '2 days ago',
    unread: false,
    type: 'info'
  }
];

// Rich datasets for charts (Analytics Dashboard)
export const ATTENDANCE_MOCK_STATS = {
  averageAttendancePercentage: 94.6,
  lateArrivalsThisMonth: 2,
  wfhCountThisMonth: 3,
  lopDays: 0,
  teamDistribution: [
    { name: 'Core Eng', present: 19, absent: 1, wfh: 3, late: 1 },
    { name: 'Support', present: 14, absent: 2, wfh: 0, late: 2 },
    { name: 'Product', present: 8, absent: 0, wfh: 2, late: 0 },
    { name: 'QA Team', present: 11, absent: 1, wfh: 1, late: 1 },
    { name: 'Cloud Ops', present: 6, absent: 0, wfh: 1, late: 0 }
  ]
};

// Monthly Attendance Trend
export const MONTHLY_TREND_DATA = [
  { month: 'Jan', percentage: 95 },
  { month: 'Feb', percentage: 92 },
  { month: 'Mar', percentage: 96 },
  { month: 'Apr', percentage: 93 },
  { month: 'May', percentage: 94.6 }
];

// Leave utilization categories
export const LEAVE_UTILIZATION_DATA = [
  { name: 'Sick Leave', allocated: 12, used: 1, remaining: 11 },
  { name: 'Casual Leave', allocated: 8, used: 1, remaining: 7 },
  { name: 'Privilege Leave', allocated: 15, used: 5, remaining: 10 }
];

// WFH vs In-Office monthly trend
export const WFH_TREND_DATA = [
  { name: 'Week 1', Office: 4, WFH: 1 },
  { name: 'Week 2', Office: 5, WFH: 0 },
  { name: 'Week 3', Office: 3, WFH: 2 },
  { name: 'Week 4', Office: 4, WFH: 1 }
];

// Late arrivals trend
export const LATE_TREND_DATA = [
  { week: 'Week 1', count: 1 },
  { week: 'Week 2', count: 0 },
  { week: 'Week 3', count: 2 },
  { week: 'Week 4', count: 0 }
];

// Company Holidays list for 2026
export const HOLIDAYS_2026: CompanyHoliday[] = [
  { 
    id: 'H1', 
    name: "New Year's Day", 
    date: '2026-01-01', 
    type: 'Public', 
    dayOfWeek: 'Thursday',
    description: "Celebrates the beginning of the Gregorian calendar year globally.",
    policy: "All global offices closed. Standard full-pay holiday. Scheduled technical on-call shifts are active with premium compensation."
  },
  { 
    id: 'H2', 
    name: 'Republic Day', 
    date: '2026-01-26', 
    type: 'National', 
    dayOfWeek: 'Monday',
    description: "Commemorates the adoption of the Constitution of India and national transition to a sovereign republic.",
    policy: "Mandatory national holiday. All domestic offices and operations closed. Only emergency server support is active on holiday pay rates."
  },
  { 
    id: 'H3', 
    name: 'Maha Shivratri', 
    date: '2026-02-15', 
    type: 'Restricted', 
    dayOfWeek: 'Sunday',
    description: "A major Hindu festival observed in reverence of Lord Shiva, symbolizing mindfulness and overcoming darkness.",
    policy: "Restricted / optional holiday. Employees intending to take this leave must apply on the leave portal in advance to adjust work schedules."
  },
  { 
    id: 'H4', 
    name: 'Holi Festival', 
    date: '2026-03-04', 
    type: 'Public', 
    dayOfWeek: 'Wednesday',
    description: "The traditional festival of colors celebrating the arrival of spring and the triumph of good over evil.",
    policy: "Public holiday. Non-essential operations suspended. Flexible remote alignment allowed for continuous critical clients."
  },
  { 
    id: 'H5', 
    name: 'Good Friday', 
    date: '2026-04-03', 
    type: 'Public', 
    dayOfWeek: 'Friday',
    description: "Christian holiday commemorating the crucifixion of Jesus Christ, observed with solemn reflection worldwide.",
    policy: "Declared public holiday. All support channels operate with minimum skeleton teams. General offices closed."
  },
  { 
    id: 'H6', 
    name: 'May Day / Labour Day', 
    date: '2026-05-01', 
    type: 'Public', 
    dayOfWeek: 'Friday',
    description: "Honors the historical achievements, contributions, and rights of the workforce and global labor movement.",
    policy: "Public holiday. No physical office attendance required. Annual workforce appreciation greetings sent by HR."
  },
  { 
    id: 'H7', 
    name: 'Eid-ul-Fitr', 
    date: '2026-05-27', 
    type: 'Public', 
    dayOfWeek: 'Wednesday',
    description: "Celebrations marking the culmination of the holy fast of Ramadan, denoting charity and brotherhood.",
    policy: "Declared public holiday (subject to crescent moon visibility). All collaborative client engagements deferred by 24 hours."
  },
  { 
    id: 'H8', 
    name: 'Independence Day', 
    date: '2026-08-15', 
    type: 'National', 
    dayOfWeek: 'Saturday',
    description: "Commemorates the nation's independence from colonial rule in 1947.",
    policy: "Mandatory national holiday. Flag hoisting and community morning tea hosted at the corporate headquarters. Attendance is voluntary."
  },
  { 
    id: 'H9', 
    name: 'Ganesh Chaturthi', 
    date: '2026-09-15', 
    type: 'Restricted', 
    dayOfWeek: 'Tuesday',
    description: "Celebrating the birth anniversary of Hindu deity Ganesha, the patron of new beginnings and wisdom.",
    policy: "Restricted holiday. Employees swap with regular working Saturdays or other restricted leaves with line manager approval."
  },
  { 
    id: 'H10', 
    name: 'Gandhi Jayanti', 
    date: '2026-10-02', 
    type: 'National', 
    dayOfWeek: 'Friday',
    description: "Honors the birth of Mahatma Gandhi, leader of national independence movement and pioneer of non-violence philosophy.",
    policy: "Mandatory national holiday. Non-working day across all regional units. Code change block and production systems freeze active."
  },
  { 
    id: 'H11', 
    name: 'Dussehra', 
    date: '2026-10-20', 
    type: 'Public', 
    dayOfWeek: 'Tuesday',
    description: "Signifies the triumph of righteousness over evil, widely celebrated with cultural plays and pageantry.",
    policy: "Public holiday. Regular operations closed. Salary disbursement for this month is scheduled to release one business day early."
  },
  { 
    id: 'H12', 
    name: 'Diwali (Deepavali)', 
    date: '2026-11-08', 
    type: 'Company', 
    dayOfWeek: 'Sunday',
    description: "The prominent festival of lights representing good fortune, corporate bonding, and absolute inclusion.",
    policy: "Special Company Paid Holiday. Diwali Gift hampers and appreciation letter from the Leadership team will be dispatched to residences."
  },
  { 
    id: 'H13', 
    name: 'Guru Nanak Jayanti', 
    date: '2026-11-24', 
    type: 'Restricted', 
    dayOfWeek: 'Tuesday',
    description: "Birth anniversary of Guru Nanak, celebrating harmony, meditation, and equal dignity of all human beings.",
    policy: "Restricted holiday. Can be availed by any employee by checking the option on the portal at least 3 days prior."
  },
  { 
    id: 'H14', 
    name: 'Christmas Day', 
    date: '2026-12-25', 
    type: 'Public', 
    dayOfWeek: 'Friday',
    description: "Traditional festival commemorating the birth of Jesus Christ, celebrated as a cheerful holiday season.",
    policy: "Annual corporate winter closure. Global core offices completely locked. Essential maintenance duty receives a 1.5x shift pay bonus."
  },
  { 
    id: 'H15', 
    name: 'Year-End Corporate Holiday', 
    date: '2026-12-31', 
    type: 'Company', 
    dayOfWeek: 'Thursday',
    description: "An exclusive company-wide corporate holiday to wind down, reflect on the past year, and welcome the upcoming year.",
    policy: "Special Company-paid Year-End day. Maximum server change freeze active (no deployments or critical system reconfigurations allowed)."
  }
];

